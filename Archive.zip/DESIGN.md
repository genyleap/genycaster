---
version: beta
name: "Genycaster"
description: "A calm, native social client where local-first resilience is visible but content stays primary."
colors:
  background: "#F6F7FB"
  surface: "#FFFFFF"
  surface-muted: "#EEF1F6"
  surface-hover: "#F7F5FE"
  ink: "#161925"
  ink-muted: "#687083"
  ink-subtle: "#8B93A5"
  primary: "#635BFF"
  primary-pressed: "#4F46E5"
  primary-surface: "#F0EFFF"
  focus: "#2C73D2"
  warning: "#B4532A"
  warning-surface: "#FFF0E8"
  success: "#1F7A5A"
  success-surface: "#EAF7F1"
  border: "#DDE2EA"
  border-strong: "#C7CEDA"
  overlay: "#5C617066"
typography:
  sans:
    fontFamily: "system-ui, sans-serif"
  utility:
    fontFamily: "system-ui, sans-serif"
rounded:
  sm: "0.375rem"
  md: "0.75rem"
  lg: "1.125rem"
  xl: "1.5rem"
  pill: "999px"
spacing:
  xs: "0.25rem"
  sm: "0.5rem"
  md: "0.75rem"
  lg: "1rem"
  xl: "1.5rem"
  xxl: "2rem"
  xxxl: "2.5rem"
components:
  app-shell: { }
  side-navigation: { }
  bottom-navigation: { }
  identity-picker: { }
  action-button: { }
  feed-header: { }
  cast-row: { }
  profile-row: { }
  status-strip: { }
  detail-surface: { }
---

# Genycaster Design System

## Overview

### Creative North Star

Genycaster should feel like a focused native social client first and a local-first system second. Casts, people, and conversation hierarchy are visually primary; cache and network state remain continuously understandable through a restrained status strip. It is not a crypto terminal, a developer console, or a soft card-grid lifestyle app.

### Product context and register

- **Audience and primary job:** Farcaster users who want to open previously seen social data instantly, move between feeds and identities, and understand whether what they see is cached, refreshing, live, or offline.
- **Target market and evidence:** Global protocol users across mobile and desktop, based on the product intent in `README.md` and `docs/14-performance-and-ui-runtime.md`; no locale-specific market behavior is inferred.
- **Locale and language policy:** Phase 4 ships translation-ready English strings. Layout and controls must tolerate longer translations and mixed-direction content; native-language review is required before claiming another locale.
- **Usage scene:** Frequent, glanceable mobile use plus adaptive desktop reading. Content is primary; system status must remain visible without becoming a modal interruption.
- **Register:** Product.
- **Memorable signature:** A compact status strip communicates the local-first lifecycle: Cached, Refreshing, Live, or Offline without displacing readable content.
- **Restraint:** Cast text, profile identity, navigation, focus, and recovery actions remain quiet and familiar. Local-first state uses semantic color sparingly rather than becoming the product aesthetic.
- **Anti-references:** No neon-on-black crypto dashboard, generic equal-weight rounded-card grid, glass blur, oversized marketing hero, or decorative protocol imagery.
- **Token ownership/runtime mapping:** This file owns the accepted Phase 4 visual tokens. `ui/theme/Theme.qml` is the hand-maintained Qt runtime adapter; `DESIGN.md` lint plus QML lint and rendered screenshot review are the drift gates.

The attempted 12ui hosted exploration was unavailable because its account authorization was not connected. The direction above is grounded in the repository's local-first behavior contract and the installed frontend design guidance rather than a generated reference image.

## Colors

The default daylight canvas uses `background`; reading surfaces use `surface`, while secondary controls use `surface-muted` and restrained pointer feedback uses `surface-hover`. `ink`, `ink-muted`, and `ink-subtle` establish the text hierarchy. `primary` is reserved for selected navigation and safe primary actions. `warning`, `primary`, and `success` pair with their matching semantic surfaces and always appear with text. `focus` is dedicated to keyboard focus. Ordinary structure uses `border`/`border-strong`; overlays use the single semantic `overlay` token rather than ad-hoc translucency.

Phase 4 verifies one daylight appearance. A future dark theme must remap semantic roles without changing status meaning; it must not invert warning/success semantics or scatter raw colors through pages.

## Typography

Qt's platform-resolved application font is canonical. No unbundled family name is forced. Body text is 15–16 px equivalent with comfortable line height; cast text may grow to 17 px on wide detail views. Utility/status labels use the same family at smaller size and medium weight rather than an unverified monospace face. Sentence case is standard. Identifiers may elide only when their full value remains available in detail context.

## Layout

- Compact: 360–599 px, one content column, 16 px outer insets, bottom/top navigation kept inside safe bounds.
- Standard: 600–999 px, a bounded 680 px reading column with persistent context controls.
- Wide: 1000 px and above, persistent navigation plus a reading column; the primary feed never stretches beyond 720 px.
- Spacing follows the frontmatter scale. Feed rows share a 16 px inner inset and 12 px vertical rhythm.
- Identity controls, status line, tabs, and content share the same left/right alignment anchors.
- One scroll owner exists per screen: the content list. Headers/status controls keep intrinsic height and do not derive implicit size from the viewport.
- Loading, stale, error, and pagination controls reserve stable geometry; background refresh never replaces usable content.

## Elevation & Depth

Depth is tonal and structural. Static feed content is flat with borders/dividers. Raised elevation is limited to modal overlays or a wide-layout navigation surface and uses a small, low-opacity shadow. Status changes must not add banners that push the list after first paint.

## Shapes

Fields and ordinary controls use `rounded.md`; larger contained empty/error states use `rounded.lg`; compact status chips may use `rounded.pill`. Feed rows are not each wrapped in a floating card. Icons use consistent 20–24 px boxes and one stroke weight. Focus rings stay outside control content without clipping.

## Components

### Foundational visual states

Every interactive component defines default, pointer hover, keyboard focus, pressed, disabled, and busy treatment. Selected/current state uses color plus text/indicator. Loading uses a compact indeterminate indicator in a reserved slot. Stale/offline/error states preserve content and add explicit status plus Retry. Skeletons are not selected for Phase 4.

### Buttons and actions

Safe primary actions use solid `primary`; secondary actions use a bordered or tonal surface. Retry is a labeled action, not an icon alone. Busy state preserves button dimensions and blocks duplicate activation. All important touch controls target at least 44 px height.

### Navigation and data display

Home is the identity-scoped Following feed; Explore is the explicit network-wide Trending surface. Channel is an explicit feed context rather than an implicit third global provider. Wide layouts use persistent navigation; compact and standard layouts use a bottom navigation bar for Home, Explore, and Profile. Feed rows emphasize avatar, author, time, and cast text; metadata remains secondary. Cast, profile, followers, and following use consistent Back behavior. Pagination uses an explicit Load more control so continuation and failure states stay understandable.

### Forms and overlays

Identity opening lives in a focused modal picker rather than occupying permanent header space. The field has a visible purpose, clear affordance, Enter/open behavior, input preservation on failure, and a stable inline error area. Phase 4 does not require secrets, date pickers, selects, destructive dialogs, or toasts. Errors needing action remain inline or in the status line.

### Iconography

Use simple Qt-drawn/text-supported symbols only when their meaning is conventional; otherwise keep a text label. No invented Farcaster or Genycaster brand mark is introduced.

### Motion

Motion explains state: 120–180 ms opacity/color transitions for selection and refresh status, interruptible immediately. Lists do not replay entrance animation after every refresh. Reduced-motion mode removes translation and repeated animation; the busy indicator remains perceivable without a sweeping effect.

### Content and data visualization

Copy is direct and user-sided: “Refreshing cached posts”, “You’re offline — showing saved posts”, “Live source unavailable”, “Load more”, and “Retry”. Offline is reserved for OS-reported disconnection; provider timeout/5xx/transport failures are source/data issues. Provider names, raw cursors, endpoint details, and backend errors never appear in release UI copy; debug builds may expose diagnostics behind an explicit Details control.

## Do's and Don'ts

- **Do:** Make cache freshness and recovery continuously understandable without blocking reading.
- **Do:** Keep every read screen aligned to the same content column, status vocabulary, and explicit Load more behavior.
- **Don't:** Blank cached content during refresh or replace it with a full-screen spinner.
- **Don't:** use repeated floating cards, neon protocol aesthetics, raw provider terminology, or color-only state communication.
