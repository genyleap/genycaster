pragma Singleton
import QtQuick

QtObject {
    readonly property color background: "#F6F7FB"
    readonly property color surface: "#FFFFFF"
    readonly property color surfaceMuted: "#EEF1F6"
    readonly property color surfaceHover: "#F7F5FE"
    readonly property color ink: "#161925"
    readonly property color inkMuted: "#687083"
    readonly property color inkSubtle: "#8B93A5"
    readonly property color primary: "#635BFF"
    readonly property color primaryPressed: "#4F46E5"
    readonly property color primarySurface: "#F0EFFF"
    readonly property color focus: "#2C73D2"
    readonly property color warning: "#B4532A"
    readonly property color warningSurface: "#FFF0E8"
    readonly property color success: "#1F7A5A"
    readonly property color successSurface: "#EAF7F1"
    readonly property color border: "#DDE2EA"
    readonly property color borderStrong: "#C7CEDA"
    readonly property color overlay: "#5C617066"

    readonly property int radiusSmall: 6
    readonly property int radiusMedium: 12
    readonly property int radiusLarge: 18
    readonly property int radiusXLarge: 24

    readonly property int space1: 4
    readonly property int space2: 8
    readonly property int space3: 12
    readonly property int space4: 16
    readonly property int space5: 24
    readonly property int space6: 32
    readonly property int space7: 40

    readonly property int controlHeight: 44
    readonly property int compactControlHeight: 44
    readonly property int navigationWidth: 252
    readonly property int readingWidth: 720
    readonly property int contentGutter: 24
    readonly property int mobileGutter: 16
}
