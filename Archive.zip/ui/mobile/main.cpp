#include <QCoreApplication>
#include <QDateTime>
#include <QDesktopServices>
#include <QDebug>
#include <QGuiApplication>
#include <QMetaObject>
#include <QNetworkInformation>
#include <QObject>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QQuickStyle>
#include <QQuickWindow>
#include <QSettings>
#include <QStandardPaths>
#include <QString>
#include <QStringList>
#include <QVariantList>
#include <QVariantMap>
#include <QTimer>
#include <QTimeZone>
#include <QThread>
#include <QUrl>

#include <algorithm>
#include <atomic>
#include <cstdint>
#include <expected>
#include <filesystem>
#include <functional>
#include <memory>
#include <mutex>
#include <optional>
#include <string>
#include <system_error>
#include <thread>
#include <utility>
#include <vector>

#include "presentation_bridge.hpp"

import farcaster.application.configuration;
import farcaster.application.read.model;
import farcaster.application.read.service;
import farcaster.application.session;
import farcaster.application.signer;
import farcaster.application.write;
import farcaster.capability.catalog;
import farcaster.capability.feed;
import farcaster.capability.model;
import farcaster.capability.pagination;
import farcaster.capability.auth;
import farcaster.capability.signer;
import farcaster.capability.signer_attestation;
import farcaster.capability.write;
import farcaster.capability.write_submit;
import farcaster.domain.cast;
import farcaster.domain.channel;
import farcaster.domain.identity;
import farcaster.domain.profile;
import farcaster.domain.session;
import farcaster.domain.signer;
import farcaster.domain.write;
import farcaster.execution.serial;
import farcaster.foundation.error;
import farcaster.foundation.result;
import farcaster.foundation.time;
import farcaster.local.read;
import farcaster.local.session;
import farcaster.local.signer;
import farcaster.local.write;
import farcaster.provider.model;
import farcaster.routing.health;
import farcaster.routing.policy;
import farcaster.routing.read.gateway;
import farcaster.routing.registry;
import farcaster.routing.router;
import farcaster.storage.read;
import farcaster.storage.session;
import farcaster.storage.signer;
import farcaster.transport.http;
import farcaster.transport.qtnetwork;

#if FARCASTER_HAS_HYPERSNAP_PROVIDER
import farcaster.provider.hypersnap.cast;
import farcaster.provider.hypersnap.config;
import farcaster.provider.hypersnap.feed;
import farcaster.provider.hypersnap.identity;
import farcaster.provider.hypersnap.profile;
import farcaster.provider.hypersnap.registration;
import farcaster.provider.hypersnap.social;
import farcaster.storage.continuation;
#endif

#if FARCASTER_HAS_FARCASTER_AUTH
import farcaster.provider.compatibility.auth;
#endif

#if FARCASTER_HAS_PROTOCOL_SIGNING
import farcaster.platform.signer_vault;
import farcaster.protocol.write;
import farcaster.storage.write;
#endif

#if FARCASTER_HAS_SNAPCHAIN_SIGNER
import farcaster.provider.snapchain.signer;
#endif

#if FARCASTER_HAS_SNAPCHAIN_WRITE
import farcaster.provider.snapchain.write;
#endif

#if FARCASTER_HAS_BROWSER_WALLET_AUTHORIZER
import farcaster.provider.compatibility.browser_wallet.authorizer;
#endif

#if FARCASTER_HAS_SIGNER_ATTESTATION
import farcaster.provider.compatibility.signer_attestation;
#endif

namespace {

namespace application = farcaster::application;
namespace capability = farcaster::capability;
namespace domain = farcaster::domain;
namespace foundation = farcaster::foundation;
namespace routing = farcaster::routing;

struct Runtime final {
    std::unique_ptr<farcaster::execution::serial::SerialExecutor> executor{};
    std::unique_ptr<farcaster::local::read::IReadStore> store{};
    std::unique_ptr<farcaster::local::session::IClientSessionStore> sessionStore{};
    std::unique_ptr<farcaster::transport::http::IHttpTransport> transport{};
#if FARCASTER_HAS_FARCASTER_AUTH
    std::unique_ptr<farcaster::capability::auth::ICompatibilityAuthentication> authentication{};
#endif
    std::unique_ptr<application::session::SessionService> sessionService{};
    std::unique_ptr<farcaster::execution::serial::SerialExecutor> signerExecutor{};
    std::unique_ptr<farcaster::local::signer::ISignerMetadataStore> signerMetadataStore{};
    std::unique_ptr<farcaster::capability::signer::ISignerVault> signerVault{};
    std::unique_ptr<farcaster::capability::signer::ISignerRegistry> signerRegistry{};
    std::unique_ptr<farcaster::capability::signer::ICustodyAuthorizer> custodyAuthorizer{};
    std::unique_ptr<farcaster::capability::signer_attestation::ISignedKeyRequestAttestor> signerAttestor{};
    std::unique_ptr<application::signer::SignerService> signerService{};
    std::unique_ptr<farcaster::local::write::IOutboxStore> writeOutbox{};
    std::unique_ptr<farcaster::capability::write::ICanonicalWriteCodec> writeCodec{};
    std::unique_ptr<farcaster::capability::write::IWriteSubmitter> writeSubmitter{};
    std::unique_ptr<application::write::WriteService> writeService{};
    std::optional<foundation::error::Error> signerSetupError{};
    std::optional<foundation::error::Error> writeSetupError{};
    std::mutex sessionMutex{};
    std::optional<domain::session::ClientSession> currentSession{};
    std::atomic_bool authenticationPollInFlight{false};
    routing::registry::CapabilityRegistry registry{};
    routing::health::HealthRegistry health{};
    std::unique_ptr<routing::router::CapabilityRouter> router{};
#if FARCASTER_HAS_HYPERSNAP_PROVIDER
    std::optional<farcaster::storage::continuation::ContinuationStore> continuations{};
    std::unique_ptr<farcaster::provider::hypersnap::identity::IdentityResolver> identity{};
    std::unique_ptr<farcaster::provider::hypersnap::profile::ProfileSource> profile{};
    std::unique_ptr<farcaster::provider::hypersnap::cast::CastSource> cast{};
    std::unique_ptr<farcaster::provider::hypersnap::feed::FeedSource> feed{};
    std::unique_ptr<farcaster::provider::hypersnap::social::SocialGraphSource> social{};
#endif
    std::unique_ptr<routing::read::gateway::RoutedReadGateway> gateway{};
    std::unique_ptr<application::read::service::ReadService> service{};
    std::mutex requestMutex{};
    std::optional<application::read::service::ReadRequest> activeRequest{};

    ~Runtime()
    {
        cancelActiveRequest();
        // Drain durable write + protocol-signing work and read/session work while
        // their borrowed providers/stores are still alive. Wallet approval and
        // network submission never block the read executor.
        signerExecutor.reset();
        writeService.reset();
        signerService.reset();
        executor.reset();
    }

    void setCurrentSession(std::optional<domain::session::ClientSession> session)
    {
        std::scoped_lock lock{sessionMutex};
        currentSession = std::move(session);
    }

    [[nodiscard]] std::optional<domain::session::ClientSession> currentSessionSnapshot()
    {
        std::scoped_lock lock{sessionMutex};
        return currentSession;
    }

    void cancelActiveRequest()
    {
        std::scoped_lock lock{requestMutex};
        if (activeRequest) { activeRequest->cancel(); }
        activeRequest.reset();
    }

    void keepRequest(application::read::service::ReadRequest request)
    {
        std::scoped_lock lock{requestMutex};
        activeRequest = std::move(request);
    }
};

[[nodiscard]] foundation::result::Result<std::unique_ptr<Runtime>> makeRuntime(
    const std::filesystem::path& databasePath,
    const farcaster::transport::qtnetwork::ProxyPolicy networkProxyPolicy,
    [[maybe_unused]] const std::optional<std::string>& providerBaseUrl,
    [[maybe_unused]] const std::optional<std::string>& authRelayUrl,
    [[maybe_unused]] const std::optional<std::string>& optimismRpcUrl,
    [[maybe_unused]] const std::optional<std::string>& snapchainBaseUrl,
    [[maybe_unused]] const std::optional<std::string>& snapchainAuthorizationHeader,
    [[maybe_unused]] const std::optional<std::string>& snapchainAuthorizationValue,
    [[maybe_unused]] const std::optional<std::uint64_t> appFid,
    [[maybe_unused]] const std::optional<std::string>& signerAttestationUrl,
    [[maybe_unused]] std::function<foundation::result::Status(const std::string&)> approvalLauncher)
{
    std::error_code directoryError{};
    std::filesystem::create_directories(databasePath.parent_path(), directoryError);
    if (directoryError) {
        return std::unexpected(foundation::error::Error::make(
            foundation::error::ErrorCode::StorageFailure,
            "Failed to create application data directory: " + directoryError.message()));
    }

    auto runtime = std::make_unique<Runtime>();
    runtime->executor = std::make_unique<farcaster::execution::serial::SerialExecutor>();
    auto store = farcaster::storage::read::openReadStore(databasePath);
    if (!store) {
        return std::unexpected(std::move(store.error()));
    }
    runtime->store = std::move(*store);
    auto sessionStore = farcaster::storage::session::openSessionStore(databasePath);
    if (!sessionStore) {
        return std::unexpected(std::move(sessionStore.error()));
    }
    runtime->sessionStore = std::move(*sessionStore);

    auto transport = farcaster::transport::qtnetwork::makeTransport(networkProxyPolicy);
    if (!transport) {
        return std::unexpected(std::move(transport.error()));
    }
    runtime->transport = std::move(*transport);

#if FARCASTER_HAS_FARCASTER_AUTH
    farcaster::provider::compatibility::auth::Config authConfig{};
    if (authRelayUrl) { authConfig.relayBaseUrl = *authRelayUrl; }
    if (optimismRpcUrl) { authConfig.optimismRpcUrl = *optimismRpcUrl; }
    auto authentication = farcaster::provider::compatibility::auth::makeAuthentication(
        *runtime->transport, std::move(authConfig));
    if (!authentication) {
        return std::unexpected(std::move(authentication.error()));
    }
    runtime->authentication = std::move(*authentication);
#endif
    runtime->sessionService = std::make_unique<application::session::SessionService>(
        *runtime->executor,
        *runtime->sessionStore,
#if FARCASTER_HAS_FARCASTER_AUTH
        runtime->authentication.get()
#else
        nullptr
#endif
    );

#if FARCASTER_HAS_PROTOCOL_SIGNING
    runtime->signerExecutor = std::make_unique<farcaster::execution::serial::SerialExecutor>();
    auto signerMetadataStore = farcaster::storage::signer::openSignerMetadataStore(databasePath);
    if (!signerMetadataStore) {
        runtime->signerSetupError = std::move(signerMetadataStore.error());
    } else {
        runtime->signerMetadataStore = std::move(*signerMetadataStore);
    }

    auto signerVault = farcaster::platform::signer_vault::open("org.genycaster.protocol-signer");
    if (!signerVault) {
        if (!runtime->signerSetupError) runtime->signerSetupError = std::move(signerVault.error());
    } else {
        runtime->signerVault = std::move(*signerVault);
    }

#if FARCASTER_HAS_SNAPCHAIN_SIGNER
    auto signerRegistryConfig = farcaster::provider::snapchain::signer::Config{};
    if (snapchainBaseUrl && !snapchainBaseUrl->empty()) {
        signerRegistryConfig.baseUrl = *snapchainBaseUrl;
    }
    if (snapchainAuthorizationHeader && snapchainAuthorizationValue) {
        signerRegistryConfig.authorizationHeaderName = *snapchainAuthorizationHeader;
        signerRegistryConfig.authorizationHeaderValue = *snapchainAuthorizationValue;
    }
    runtime->signerRegistry = farcaster::provider::snapchain::signer::makeRegistry(
        *runtime->transport,
        std::move(signerRegistryConfig));
#endif

#if FARCASTER_HAS_BROWSER_WALLET_AUTHORIZER
    if (approvalLauncher) {
        auto authorizer =
            farcaster::provider::compatibility::browser_wallet::authorizer::makeAuthorizer(
                farcaster::provider::compatibility::browser_wallet::authorizer::Config{
                    .launch = std::move(approvalLauncher),
                });
        if (!authorizer) {
            if (!runtime->signerSetupError) runtime->signerSetupError = std::move(authorizer.error());
        } else {
            runtime->custodyAuthorizer = std::move(*authorizer);
        }
    }
#endif

    const bool hasAppFid = appFid.has_value();
    const bool hasAttestationUrl = signerAttestationUrl.has_value() && !signerAttestationUrl->empty();
    if (hasAppFid != hasAttestationUrl) {
        if (!runtime->signerSetupError) {
            runtime->signerSetupError = foundation::error::Error::make(
                foundation::error::ErrorCode::InvalidArgument,
                "Production App-FID authorization requires both GENYCASTER_APP_FID and "
                "GENYCASTER_SIGNER_ATTESTATION_URL.");
        }
    }
#if FARCASTER_HAS_SIGNER_ATTESTATION
    if (hasAppFid && hasAttestationUrl) {
        auto attestor = farcaster::provider::compatibility::signer_attestation::makeAttestor(
            *runtime->transport,
            farcaster::provider::compatibility::signer_attestation::Config{
                .endpointUrl = *signerAttestationUrl,
            });
        if (!attestor) {
            if (!runtime->signerSetupError) runtime->signerSetupError = std::move(attestor.error());
        } else {
            runtime->signerAttestor = std::move(*attestor);
        }
    }
#else
    if (hasAppFid && hasAttestationUrl && !runtime->signerSetupError) {
        runtime->signerSetupError = foundation::error::Error::make(
            foundation::error::ErrorCode::Unsupported,
            "App-FID signer attestation is configured but this build excluded the attestation provider.");
    }
#endif

    if (runtime->signerExecutor && runtime->signerMetadataStore && runtime->signerVault) {
        application::signer::SignerPolicy signerPolicy{};
        if (appFid) {
            signerPolicy.requestFid = domain::identity::Fid{*appFid};
        }
        runtime->signerService = std::make_unique<application::signer::SignerService>(
            *runtime->signerExecutor,
            *runtime->signerVault,
            *runtime->signerMetadataStore,
            runtime->signerRegistry.get(),
            runtime->custodyAuthorizer.get(),
            runtime->signerAttestor.get(),
            std::move(signerPolicy));
    }

    auto writeOutbox = farcaster::storage::write::openOutboxStore(databasePath);
    if (!writeOutbox) {
        runtime->writeSetupError = std::move(writeOutbox.error());
    } else {
        runtime->writeOutbox = std::move(*writeOutbox);
    }
    runtime->writeCodec = farcaster::protocol::write::makeCanonicalWriteCodec();

#if FARCASTER_HAS_SNAPCHAIN_WRITE
    auto writeSubmitterConfig = farcaster::provider::snapchain::write::Config{};
    if (snapchainBaseUrl && !snapchainBaseUrl->empty()) {
        writeSubmitterConfig.baseUrl = *snapchainBaseUrl;
    }
    if (snapchainAuthorizationHeader && snapchainAuthorizationValue) {
        writeSubmitterConfig.authorizationHeaderName = *snapchainAuthorizationHeader;
        writeSubmitterConfig.authorizationHeaderValue = *snapchainAuthorizationValue;
    }
    runtime->writeSubmitter = farcaster::provider::snapchain::write::makeSubmitter(
        *runtime->transport,
        std::move(writeSubmitterConfig));
#endif

    if (runtime->signerExecutor && runtime->signerService && runtime->writeOutbox && runtime->writeCodec) {
        runtime->writeService = std::make_unique<application::write::WriteService>(
            *runtime->signerExecutor,
            *runtime->signerService,
            *runtime->writeCodec,
            *runtime->writeOutbox,
            runtime->writeSubmitter.get(),
            application::write::WritePolicy{});
    } else if (!runtime->writeSetupError) {
        runtime->writeSetupError = foundation::error::Error::make(
            foundation::error::ErrorCode::Unsupported,
            "Durable PublishCast composition is unavailable because secure signer or outbox setup failed.");
    }
#endif

    std::vector<routing::read::gateway::SourceBinding> bindings{};
#if FARCASTER_HAS_HYPERSNAP_PROVIDER
    const farcaster::provider::model::ProviderDescriptor descriptor{
        .id = farcaster::provider::model::ProviderId{"hypersnap-v2"},
        .displayName = "Hypersnap v2",
        .deployment = farcaster::provider::model::ProviderDeployment::PublicManaged,
        .privacy = farcaster::provider::model::ProviderPrivacy::Standard,
        .priority = 10,
    };
    auto registration = runtime->registry.registerProvider(
        routing::registry::ProviderRegistration{
            .provider = descriptor,
            .capabilities = farcaster::provider::hypersnap::registration::capabilities(),
        });
    if (!registration) {
        return std::unexpected(std::move(registration.error()));
    }
    auto continuationStore = farcaster::storage::continuation::openContinuationStore(databasePath);
    if (!continuationStore) {
        return std::unexpected(std::move(continuationStore.error()));
    }
    runtime->continuations.emplace(std::move(*continuationStore));
    farcaster::provider::hypersnap::config::Config providerConfig{
        .provider = descriptor,
    };
    if (providerBaseUrl) {
        providerConfig.baseUrl = *providerBaseUrl;
    }
    runtime->identity = std::make_unique<farcaster::provider::hypersnap::identity::IdentityResolver>(
        *runtime->transport, providerConfig);
    runtime->profile = std::make_unique<farcaster::provider::hypersnap::profile::ProfileSource>(
        *runtime->transport, providerConfig);
    runtime->cast = std::make_unique<farcaster::provider::hypersnap::cast::CastSource>(
        *runtime->transport, providerConfig);
    runtime->feed = std::make_unique<farcaster::provider::hypersnap::feed::FeedSource>(
        *runtime->transport, *runtime->continuations, providerConfig);
    runtime->social = std::make_unique<farcaster::provider::hypersnap::social::SocialGraphSource>(
        *runtime->transport, *runtime->continuations, providerConfig);
    bindings.push_back(routing::read::gateway::SourceBinding{
        .providerId = descriptor.id,
        .identity = runtime->identity.get(),
        .profile = runtime->profile.get(),
        .cast = runtime->cast.get(),
        .feed = runtime->feed.get(),
        .social = runtime->social.get(),
    });
#endif

    const bool strict = application::configuration::configuredDeploymentProfile()
        == application::configuration::DeploymentProfile::StrictSelfHosted;
    runtime->router = std::make_unique<routing::router::CapabilityRouter>(
        runtime->registry,
        runtime->health,
        routing::policy::RoutingPolicy{
            .mode = strict ? routing::policy::RoutingMode::StrictSelfHosted
                           : routing::policy::RoutingMode::Standard,
            .allowManagedProviders = !strict,
            .minimumQuality = farcaster::capability::model::CapabilityQuality::Experimental,
        });

    const auto identityRoute = runtime->router->resolve(routing::policy::CapabilityRequest{
        .capabilityId = capability::catalog::identityFidResolve(),
        .requiredAccess = capability::model::CapabilityAccess::Read,
        .minimumQuality = capability::model::CapabilityQuality::Experimental,
    });
    if (!identityRoute) {
        return std::unexpected(foundation::error::Error::make(
            foundation::error::ErrorCode::Unavailable,
            "Live-read runtime composition is incomplete. " + identityRoute.error().message));
    }

    runtime->gateway = std::make_unique<routing::read::gateway::RoutedReadGateway>(
        *runtime->router, runtime->health, std::move(bindings));
    runtime->service = std::make_unique<application::read::service::ReadService>(
        *runtime->executor, *runtime->store, *runtime->gateway);
    return runtime;
}

[[nodiscard]] bool isBusy(const application::read::model::ReadMetadata& metadata)
{
    return metadata.phase == application::read::model::ReadPhase::LoadingCache ||
        metadata.phase == application::read::model::ReadPhase::Refreshing;
}

[[nodiscard]] QString statusText(const application::read::model::ReadMetadata& metadata)
{
    if (metadata.phase == application::read::model::ReadPhase::Refreshing) {
        return metadata.isStale ? QStringLiteral("Saved data · refreshing")
                                : QStringLiteral("Loading live data…");
    }
    if (metadata.phase == application::read::model::ReadPhase::Ready) {
        return QStringLiteral("Up to date");
    }
    if (!metadata.error) {
        return QStringLiteral("Refresh did not complete");
    }

    using foundation::error::ErrorCode;
    const QString prefix = metadata.isStale ? QStringLiteral("Saved data · ") : QString{};
    switch (metadata.error->code) {
    case ErrorCode::Timeout:
        return prefix + QStringLiteral("live read timed out");
    case ErrorCode::Unavailable:
        return prefix + QStringLiteral("live source unavailable");
    case ErrorCode::TransportFailure:
        return prefix + QStringLiteral("could not reach live source");
    case ErrorCode::ProtocolFailure:
        return prefix + QStringLiteral("live format mismatch");
    default:
        return prefix + QStringLiteral("refresh failed");
    }
}

[[nodiscard]] QString errorText(const application::read::model::ReadMetadata& metadata)
{
    if (!metadata.error) { return {}; }
    using foundation::error::ErrorCode;
    switch (metadata.error->code) {
    case ErrorCode::InvalidArgument:
        return QStringLiteral("That read request is not valid.");
    case ErrorCode::NotFound:
        return QStringLiteral("Nothing was found for that identity or item.");
    case ErrorCode::Unauthorized:
        return QStringLiteral("The selected source rejected this read.");
    case ErrorCode::RateLimited:
        return QStringLiteral("The live source is rate limited. Saved data remains available.");
    case ErrorCode::Timeout:
        return QStringLiteral("The live source did not answer in time. This does not mean your device is offline.");
    case ErrorCode::Unavailable:
        return QStringLiteral("The selected live source is temporarily unavailable. Your connection may still be fine.");
    case ErrorCode::TransportFailure:
        return QStringLiteral("Genycaster could not reach the selected live source. Check the source or connection and retry.");
    case ErrorCode::Conflict:
        return QStringLiteral("This saved page cannot continue on the current route. Refresh from the start.");
    case ErrorCode::StorageFailure:
        return QStringLiteral("The local cache could not be updated.");
    case ErrorCode::ProtocolFailure:
        return QStringLiteral("The live source returned data this build cannot decode yet.");
    case ErrorCode::Unsupported:
        return QStringLiteral("This read is not available in the current build.");
    case ErrorCode::InternalFailure:
        return QStringLiteral("The read could not be completed.");
    }
    return QStringLiteral("The read could not be completed.");
}

[[nodiscard]] QString diagnosticText(const application::read::model::ReadMetadata& metadata)
{
    if (!metadata.error) { return {}; }
    using foundation::error::ErrorCode;
    QString code{};
    switch (metadata.error->code) {
    case ErrorCode::InvalidArgument: code = QStringLiteral("InvalidArgument"); break;
    case ErrorCode::NotFound: code = QStringLiteral("NotFound"); break;
    case ErrorCode::Unavailable: code = QStringLiteral("Unavailable"); break;
    case ErrorCode::Unauthorized: code = QStringLiteral("Unauthorized"); break;
    case ErrorCode::RateLimited: code = QStringLiteral("RateLimited"); break;
    case ErrorCode::Timeout: code = QStringLiteral("Timeout"); break;
    case ErrorCode::Conflict: code = QStringLiteral("Conflict"); break;
    case ErrorCode::Unsupported: code = QStringLiteral("Unsupported"); break;
    case ErrorCode::StorageFailure: code = QStringLiteral("StorageFailure"); break;
    case ErrorCode::TransportFailure: code = QStringLiteral("TransportFailure"); break;
    case ErrorCode::ProtocolFailure: code = QStringLiteral("ProtocolFailure"); break;
    case ErrorCode::InternalFailure: code = QStringLiteral("InternalFailure"); break;
    }
    return code + QStringLiteral(" · ") + QString::fromStdString(metadata.error->message);
}

[[nodiscard]] QString relativeTime(const foundation::time::Timestamp timestamp)
{
    const qint64 timestampMs = static_cast<qint64>(timestamp.time_since_epoch().count());
    const qint64 nowMs = QDateTime::currentDateTimeUtc().toMSecsSinceEpoch();
    const qint64 elapsedSeconds = std::max<qint64>(0, (nowMs - timestampMs) / 1000);
    if (elapsedSeconds < 60) { return QStringLiteral("now"); }
    if (elapsedSeconds < 3600) { return QString::number(elapsedSeconds / 60) + QStringLiteral("m"); }
    if (elapsedSeconds < 86'400) { return QString::number(elapsedSeconds / 3600) + QStringLiteral("h"); }
    if (elapsedSeconds < 604'800) { return QString::number(elapsedSeconds / 86'400) + QStringLiteral("d"); }
    return QDateTime::fromMSecsSinceEpoch(timestampMs, QTimeZone::UTC)
        .toString(QStringLiteral("MMM d"));
}

[[nodiscard]] QString firstUrlEmbed(const domain::cast::Cast& cast)
{
    for (const auto& embed : cast.embeds) {
        if (embed.kind == domain::cast::EmbedKind::Url) {
            return QString::fromStdString(embed.value);
        }
    }
    return {};
}

[[nodiscard]] QVariantList embedItems(const domain::cast::Cast& cast)
{
    QVariantList items{};
    for (const auto& embed : cast.embeds) {
        if (embed.kind != domain::cast::EmbedKind::Url) { continue; }
        const QString url = QString::fromStdString(embed.value);
        const QString lower = url.toLower();
        const bool media = lower.endsWith(QStringLiteral(".jpg")) || lower.endsWith(QStringLiteral(".jpeg")) ||
            lower.endsWith(QStringLiteral(".png")) || lower.endsWith(QStringLiteral(".webp")) ||
            lower.endsWith(QStringLiteral(".gif")) || lower.endsWith(QStringLiteral(".mp4")) ||
            lower.endsWith(QStringLiteral(".mov")) || lower.endsWith(QStringLiteral(".webm"));
        items.push_back(QVariantMap{
            {QStringLiteral("kind"), media ? QStringLiteral("media") : QStringLiteral("url")},
            {QStringLiteral("url"), url},
        });
    }
    return items;
}

[[nodiscard]] const domain::cast::Cast* findCast(
    const application::read::model::FeedState& state,
    const domain::cast::CastId& id)
{
    for (const auto& cast : state.casts) {
        if (cast.id.value == id.value) { return &cast; }
    }
    return nullptr;
}

[[nodiscard]] const domain::profile::Profile* findProfile(
    const application::read::model::FeedState& state,
    const domain::identity::Fid fid)
{
    for (const auto& profile : state.profiles) {
        if (profile.fid.value == fid.value) { return &profile; }
    }
    return nullptr;
}

[[nodiscard]] QString username(const domain::profile::Profile* profile)
{
    return profile != nullptr && profile->username
        ? QString::fromStdString(profile->username->value) : QString{};
}

[[nodiscard]] QString displayName(const domain::profile::Profile* profile)
{
    return profile != nullptr && profile->displayName
        ? QString::fromStdString(profile->displayName->value) : username(profile);
}

[[nodiscard]] QString avatarUrl(const domain::profile::Profile* profile)
{
    return profile != nullptr && profile->avatarUrl
        ? QString::fromStdString(*profile->avatarUrl) : QString{};
}

void applyFeedState(PresentationBridge& bridge, application::read::model::FeedState state)
{
    QVariantList rows{};
    for (const auto& entry : state.entries) {
        const auto* cast = findCast(state, entry.castId);
        if (cast == nullptr) { continue; }
        const auto* profile = findProfile(state, cast->author);
        rows.push_back(QVariantMap{
            {QStringLiteral("castId"), QString::fromStdString(cast->id.value)},
            {QStringLiteral("authorFid"), static_cast<qulonglong>(cast->author.value)},
            {QStringLiteral("author"), username(profile)},
            {QStringLiteral("displayName"), displayName(profile)},
            {QStringLiteral("avatarUrl"), avatarUrl(profile)},
            {QStringLiteral("text"), QString::fromStdString(cast->text)},
            {QStringLiteral("time"), relativeTime(cast->createdAt)},
            {QStringLiteral("isReply"), cast->parent.has_value()},
            {QStringLiteral("parentCastId"), cast->parent ? QString::fromStdString(cast->parent->value) : QString{}},
            {QStringLiteral("parentUrl"), cast->parentUrl ? QString::fromStdString(*cast->parentUrl) : QString{}},
            {QStringLiteral("embedUrl"), firstUrlEmbed(*cast)},
            {QStringLiteral("embedCount"), static_cast<qulonglong>(cast->embeds.size())},
            {QStringLiteral("embeds"), embedItems(*cast)},
            {QStringLiteral("replyCount"), static_cast<qulonglong>(cast->engagement.replies)},
            {QStringLiteral("recastCount"), static_cast<qulonglong>(cast->engagement.recasts)},
            {QStringLiteral("likeCount"), static_cast<qulonglong>(cast->engagement.likes)},
        });
    }
    const QString selector = state.query.kind == application::read::model::FeedQuery::Kind::Following
        ? QStringLiteral("following")
        : state.query.kind == application::read::model::FeedQuery::Kind::Channel
            ? QStringLiteral("channel") : QStringLiteral("trending");
    bridge.applyList(
        QStringLiteral("feed"), selector, std::move(rows),
        state.next ? QString::fromStdString(state.next->value) : QString{},
        statusText(state.metadata), errorText(state.metadata), diagnosticText(state.metadata), isBusy(state.metadata),
        state.metadata.isStale, state.metadata.isSourceUnavailable);
}

void applySocialState(PresentationBridge& bridge, application::read::model::SocialState state)
{
    QVariantList rows{};
    for (const auto& profile : state.profiles) {
        rows.push_back(QVariantMap{
            {QStringLiteral("author"), username(&profile)},
            {QStringLiteral("displayName"), displayName(&profile)},
            {QStringLiteral("avatarUrl"), avatarUrl(&profile)},
        });
    }
    const QString view = state.query.kind == application::read::model::SocialQuery::Kind::Followers
        ? QStringLiteral("followers") : QStringLiteral("following");
    bridge.applyList(view, view, std::move(rows),
        state.next ? QString::fromStdString(state.next->value) : QString{},
        statusText(state.metadata), errorText(state.metadata), diagnosticText(state.metadata), isBusy(state.metadata),
        state.metadata.isStale, state.metadata.isSourceUnavailable);
}

[[nodiscard]] QString sessionPhaseText(const application::session::SessionPhase phase)
{
    switch (phase) {
    case application::session::SessionPhase::Guest:
        return QStringLiteral("guest");
    case application::session::SessionPhase::Starting:
        return QStringLiteral("starting");
    case application::session::SessionPhase::AwaitingApproval:
        return QStringLiteral("awaiting-approval");
    case application::session::SessionPhase::Authenticated:
        return QStringLiteral("authenticated");
    case application::session::SessionPhase::Failed:
        return QStringLiteral("failed");
    }
    return QStringLiteral("failed");
}

[[nodiscard]] QString authenticationErrorText(const application::session::SessionState& state)
{
    if (!state.error) {
        return {};
    }
    using foundation::error::ErrorCode;
    QString summary{};
    switch (state.error->code) {
    case ErrorCode::Unauthorized:
        summary = QStringLiteral("Farcaster could not verify this sign-in. Start a new request and approve the matching account.");
        break;
    case ErrorCode::RateLimited:
        summary = QStringLiteral("Sign in is temporarily rate limited. Guest reading is still available.");
        break;
    case ErrorCode::Timeout:
        summary = QStringLiteral("The sign-in request timed out. Guest reading is still available.");
        break;
    case ErrorCode::Unavailable:
    case ErrorCode::TransportFailure:
        summary = QStringLiteral("The sign-in service is temporarily unavailable. Guest reading is still available.");
        break;
    case ErrorCode::Unsupported:
        summary = QStringLiteral("Sign in is not available in this build. Guest reading is still available.");
        break;
    case ErrorCode::InvalidArgument:
        summary = QStringLiteral("This build is missing valid Sign-In With Farcaster app configuration.");
        break;
    case ErrorCode::StorageFailure:
        summary = QStringLiteral("The local account session could not be saved.");
        break;
    case ErrorCode::ProtocolFailure:
    case ErrorCode::Conflict:
    case ErrorCode::NotFound:
    case ErrorCode::InternalFailure:
        summary = QStringLiteral("The sign-in proof could not be validated safely.");
        break;
    }
#ifndef NDEBUG
    // Provider-owned tokens, signatures and proof bodies never enter Error::message.
    // Debug builds may therefore expose the normalized failure reason without
    // weakening the release UI or persisting transient authentication material.
    summary += QStringLiteral("\n\nDebug: ");
    summary += QString::fromStdString(state.error->message);
#endif
    return summary.isEmpty() ? QStringLiteral("Sign in could not be completed.") : summary;
}

[[nodiscard]] QString signerPhaseText(const application::signer::SignerPhase phase)
{
    using application::signer::SignerPhase;
    switch (phase) {
    case SignerPhase::SignedOut: return QStringLiteral("signed-out");
    case SignerPhase::Checking: return QStringLiteral("checking");
    case SignerPhase::Missing: return QStringLiteral("missing");
    case SignerPhase::AuthorizationRequired: return QStringLiteral("authorization-required");
    case SignerPhase::Provisioning: return QStringLiteral("provisioning");
    case SignerPhase::Ready: return QStringLiteral("ready");
    case SignerPhase::Revoked: return QStringLiteral("revoked");
    case SignerPhase::Expired: return QStringLiteral("expired");
    case SignerPhase::Unavailable: return QStringLiteral("unavailable");
    case SignerPhase::Failed: return QStringLiteral("failed");
    }
    return QStringLiteral("failed");
}

[[nodiscard]] QString signerStatusText(const application::signer::SignerState& state)
{
    using application::signer::SignerPhase;
    switch (state.phase) {
    case SignerPhase::SignedOut:
        return QStringLiteral("Sign in before enabling interactions.");
    case SignerPhase::Checking:
        return QStringLiteral("Checking the protocol signer against the network…");
    case SignerPhase::Missing:
        return QStringLiteral("Interaction signer is not enabled yet.");
    case SignerPhase::AuthorizationRequired:
        return QStringLiteral("Custody wallet approval is required to enable interactions.");
    case SignerPhase::Provisioning:
        return QStringLiteral("Waiting for custody approval and network confirmation…");
    case SignerPhase::Ready:
        return QStringLiteral("Interaction signing is ready.");
    case SignerPhase::Revoked:
        return QStringLiteral("The protocol signer has been revoked.");
    case SignerPhase::Expired:
        return QStringLiteral("The protocol signer expired. Enable interactions again to continue.");
    case SignerPhase::Unavailable:
        return QStringLiteral("Interaction signing is temporarily unavailable. Reading is unaffected.");
    case SignerPhase::Failed:
        return QStringLiteral("Interaction signing could not be verified safely. Reading is unaffected.");
    }
    return QStringLiteral("Interaction signing is unavailable.");
}

[[nodiscard]] QString signerErrorText(const application::signer::SignerState& state)
{
    if (!state.error) return {};
    using foundation::error::ErrorCode;
    QString text{};
    switch (state.error->code) {
    case ErrorCode::Unauthorized:
        text = QStringLiteral("The custody wallet did not authorize this signer request.");
        break;
    case ErrorCode::Timeout:
        text = QStringLiteral("The custody approval or network confirmation timed out.");
        break;
    case ErrorCode::Unavailable:
    case ErrorCode::TransportFailure:
        text = QStringLiteral("The secure signer, wallet, or Snapchain endpoint is currently unavailable.");
        break;
    case ErrorCode::Unsupported:
        text = QStringLiteral("This build is missing a required signer capability or endpoint configuration.");
        break;
    case ErrorCode::StorageFailure:
        text = QStringLiteral("The platform secure store or signer metadata could not be accessed.");
        break;
    case ErrorCode::ProtocolFailure:
    case ErrorCode::Conflict:
        text = QStringLiteral("Snapchain rejected or contradicted the signer authorization state.");
        break;
    case ErrorCode::InvalidArgument:
        text = QStringLiteral("The signer authorization configuration is invalid.");
        break;
    case ErrorCode::NotFound:
    case ErrorCode::RateLimited:
    case ErrorCode::InternalFailure:
        text = QStringLiteral("The signer operation could not be completed safely.");
        break;
    }
#ifndef NDEBUG
    text += QStringLiteral("\n\nDebug: ");
    text += QString::fromStdString(state.error->message);
#endif
    return text;
}

void applySignerState(PresentationBridge& bridge, application::signer::SignerState state)
{
#ifndef NDEBUG
    if (state.error) {
        qInfo().noquote() << "Genycaster signer failure:"
                          << QString::fromStdString(state.error->message);
    }
#endif
    const bool busy = state.phase == application::signer::SignerPhase::Checking ||
        state.phase == application::signer::SignerPhase::Provisioning;
    const bool ready = state.phase == application::signer::SignerPhase::Ready;
    bridge.applySignerState(
        signerPhaseText(state.phase),
        busy,
        ready,
        signerStatusText(state),
        signerErrorText(state));
}

[[nodiscard]] QString writePhaseText(const application::write::WritePhase phase)
{
    switch (phase) {
    case application::write::WritePhase::Queued: return QStringLiteral("queued");
    case application::write::WritePhase::Submitting: return QStringLiteral("submitting");
    case application::write::WritePhase::RetryScheduled: return QStringLiteral("retry-scheduled");
    case application::write::WritePhase::Confirmed: return QStringLiteral("confirmed");
    case application::write::WritePhase::Failed: return QStringLiteral("failed");
    case application::write::WritePhase::Blocked: return QStringLiteral("blocked");
    }
    return QStringLiteral("failed");
}

[[nodiscard]] QString writeRowState(const application::write::WritePhase phase)
{
    switch (phase) {
    case application::write::WritePhase::Queued:
    case application::write::WritePhase::Submitting:
        return QStringLiteral("pending");
    case application::write::WritePhase::RetryScheduled:
        return QStringLiteral("retry");
    case application::write::WritePhase::Confirmed:
        return QStringLiteral("confirmed");
    case application::write::WritePhase::Failed:
        return QStringLiteral("failed");
    case application::write::WritePhase::Blocked:
        return QStringLiteral("blocked");
    }
    return QStringLiteral("failed");
}

[[nodiscard]] QString operationPresentationKind(const application::write::OperationKind kind)
{
    using application::write::OperationKind;
    switch (kind) {
    case OperationKind::PublishCast: return QStringLiteral("publish-cast");
    case OperationKind::RemoveCast: return QStringLiteral("remove-cast");
    case OperationKind::Like: return QStringLiteral("like");
    case OperationKind::Unlike: return QStringLiteral("unlike");
    case OperationKind::Recast: return QStringLiteral("recast");
    case OperationKind::UndoRecast: return QStringLiteral("undo-recast");
    case OperationKind::Follow: return QStringLiteral("follow");
    case OperationKind::Unfollow: return QStringLiteral("unfollow");
    }
    return QStringLiteral("protocol-write");
}

[[nodiscard]] QString operationLabel(const application::write::WriteState& state)
{
    if (!state.record) return QStringLiteral("Protocol write");
    using application::write::OperationKind;
    switch (state.record->kind) {
    case OperationKind::PublishCast:
        return state.record->optimisticCast && state.record->optimisticCast->parent
            ? QStringLiteral("Reply") : QStringLiteral("Cast");
    case OperationKind::RemoveCast: return QStringLiteral("Cast deletion");
    case OperationKind::Like: return QStringLiteral("Like");
    case OperationKind::Unlike: return QStringLiteral("Unlike");
    case OperationKind::Recast: return QStringLiteral("Recast");
    case OperationKind::UndoRecast: return QStringLiteral("Recast removal");
    case OperationKind::Follow: return QStringLiteral("Follow");
    case OperationKind::Unfollow: return QStringLiteral("Unfollow");
    }
    return QStringLiteral("Protocol write");
}

[[nodiscard]] QString writeStatusText(const application::write::WriteState& state)
{
    const QString label = operationLabel(state);
    switch (state.phase) {
    case application::write::WritePhase::Queued:
        if (state.error && state.error->code == foundation::error::ErrorCode::Unsupported) {
            return label + QStringLiteral(" saved locally. Network submission is not configured in this runtime.");
        }
        return label + QStringLiteral(" saved locally before network submission.");
    case application::write::WritePhase::Submitting:
        return QStringLiteral("Submitting %1 to Farcaster…").arg(label.toLower());
    case application::write::WritePhase::RetryScheduled:
        return label + QStringLiteral(" is saved locally. A bounded network retry is scheduled.");
    case application::write::WritePhase::Confirmed:
        return label + QStringLiteral(" confirmed by authoritative Farcaster state.");
    case application::write::WritePhase::Failed:
        return label + QStringLiteral(" failed. The signed operation remains recorded locally.");
    case application::write::WritePhase::Blocked:
        return label + QStringLiteral(" is paused until the verified signer is available again.");
    }
    return {};
}

[[nodiscard]] QString writeErrorText(const application::write::WriteState& state)
{
    if (!state.error) return {};
    using foundation::error::ErrorCode;
    switch (state.error->code) {
    case ErrorCode::Unauthorized:
        return QStringLiteral("This interaction needs the current verified Farcaster signer and exact required scope.");
    case ErrorCode::RateLimited:
        return QStringLiteral("Farcaster is rate limiting this write. It is saved locally for retry.");
    case ErrorCode::Timeout:
    case ErrorCode::Unavailable:
    case ErrorCode::TransportFailure:
        return QStringLiteral("The network is temporarily unavailable. The write is saved locally for retry.");
    case ErrorCode::Conflict:
        return QStringLiteral("The network reported authoritative state that conflicts with this write.");
    case ErrorCode::Unsupported:
        return QStringLiteral("This runtime has no compatible Snapchain write endpoint. The signed write remains queued locally.");
    case ErrorCode::InvalidArgument:
        return QStringLiteral("This interaction does not satisfy the current Farcaster protocol contract.");
    case ErrorCode::ProtocolFailure:
        return QStringLiteral("Farcaster rejected the canonical protocol message.");
    case ErrorCode::StorageFailure:
        return QStringLiteral("The write could not be saved safely to the durable outbox.");
    case ErrorCode::NotFound:
    case ErrorCode::InternalFailure:
        return QStringLiteral("The protocol write could not be completed safely.");
    }
    return QStringLiteral("The protocol write could not be completed safely.");
}

[[nodiscard]] QVariantMap writePresentation(
    const application::write::WriteState& state,
    const std::optional<domain::session::ClientSession>& session)
{
    if (!state.record) return {};
    const auto& record = *state.record;
    QVariantMap presentation{
        {QStringLiteral("operationKind"), operationPresentationKind(record.kind)},
        {QStringLiteral("writeState"), writeRowState(state.phase)},
    };
    if (record.optimisticCast) {
        const auto& cast = *record.optimisticCast;
        QString author = QStringLiteral("you");
        QString display = QStringLiteral("You");
        QString avatar{};
        if (session) {
            if (session->username) author = QString::fromStdString(*session->username);
            if (session->displayName) display = QString::fromStdString(*session->displayName);
            else if (session->username) display = QString::fromStdString(*session->username);
            if (session->avatarUrl) avatar = QString::fromStdString(*session->avatarUrl);
        }
        presentation.insert(QStringLiteral("castId"), QString::fromStdString(cast.id.value));
        presentation.insert(QStringLiteral("authorFid"), static_cast<qulonglong>(cast.author.value));
        presentation.insert(QStringLiteral("author"), author);
        presentation.insert(QStringLiteral("displayName"), display);
        presentation.insert(QStringLiteral("avatarUrl"), avatar);
        presentation.insert(QStringLiteral("text"), QString::fromStdString(cast.text));
        presentation.insert(QStringLiteral("time"), relativeTime(cast.createdAt));
        presentation.insert(QStringLiteral("isReply"), cast.parent.has_value());
        presentation.insert(QStringLiteral("parentCastId"), cast.parent ? QString::fromStdString(cast.parent->value) : QString{});
        presentation.insert(QStringLiteral("parentUrl"), cast.parentUrl ? QString::fromStdString(*cast.parentUrl) : QString{});
        presentation.insert(QStringLiteral("embedUrl"), firstUrlEmbed(cast));
        presentation.insert(QStringLiteral("embedCount"), static_cast<qulonglong>(cast.embeds.size()));
        presentation.insert(QStringLiteral("embeds"), embedItems(cast));
        presentation.insert(QStringLiteral("replyCount"), static_cast<qulonglong>(cast.engagement.replies));
        presentation.insert(QStringLiteral("recastCount"), static_cast<qulonglong>(cast.engagement.recasts));
        presentation.insert(QStringLiteral("likeCount"), static_cast<qulonglong>(cast.engagement.likes));
    }
    if (record.target.cast) {
        presentation.insert(QStringLiteral("targetCastId"), QString::fromStdString(record.target.cast->id.value));
        presentation.insert(QStringLiteral("targetAuthorFid"), static_cast<qulonglong>(record.target.cast->author.value));
    }
    if (record.target.fid) {
        presentation.insert(QStringLiteral("targetFid"), static_cast<qulonglong>(record.target.fid->value));
    }
    return presentation;
}

void applyWriteState(
    PresentationBridge& bridge,
    application::write::WriteState state,
    const std::optional<domain::session::ClientSession>& session)
{
    if (state.record) {
        const auto authorFid = state.record->author.value;
        if (!bridge.isAuthenticated() || bridge.accountFid() != authorFid) {
            return;
        }
    }
#ifndef NDEBUG
    if (state.error) {
        qInfo().noquote() << "Genycaster write failure:"
                          << QString::fromStdString(state.error->message);
    }
#endif
    const bool busy = state.phase == application::write::WritePhase::Submitting;
    bridge.applyWriteState(
        writePhaseText(state.phase),
        busy,
        writeStatusText(state),
        writeErrorText(state),
        writePresentation(state, session));
}

void applySessionState(
    PresentationBridge& bridge,
    application::session::SessionState state,
    const bool authenticationAvailable)
{
#ifndef NDEBUG
    if (state.error) {
        qInfo().noquote() << "Genycaster authentication failure:"
                          << QString::fromStdString(state.error->message);
    }
#endif
    qulonglong fid = 0;
    QString username{};
    QString displayName{};
    QString avatarUrl{};
    if (state.session) {
        fid = static_cast<qulonglong>(state.session->fid.value);
        if (state.session->username) {
            username = QString::fromStdString(*state.session->username);
        }
        if (state.session->displayName) {
            displayName = QString::fromStdString(*state.session->displayName);
        }
        if (state.session->avatarUrl) {
            avatarUrl = QString::fromStdString(*state.session->avatarUrl);
        }
    }
    bridge.applyAuthenticationState(
        authenticationAvailable,
        sessionPhaseText(state.phase),
        fid,
        std::move(username),
        std::move(displayName),
        std::move(avatarUrl),
        QString::fromStdString(state.approvalUrl),
        authenticationErrorText(state));
}

void connectRuntime(
    PresentationBridge& bridge,
    const std::shared_ptr<Runtime>& runtime,
    const bool authenticationAvailable,
    std::string siwfDomain,
    std::string siwfUri)
{
    const auto writeObserver = [&bridge, runtime](application::write::WriteState state) {
        const auto session = runtime->currentSessionSnapshot();
        QMetaObject::invokeMethod(
            &bridge,
            [&bridge, state = std::move(state), session]() mutable {
                applyWriteState(bridge, std::move(state), session);
            },
            Qt::QueuedConnection);
    };

    const auto signerObserver = [&bridge, runtime, writeObserver](application::signer::SignerState state) {
        const bool ready = state.phase == application::signer::SignerPhase::Ready;
        QMetaObject::invokeMethod(
            &bridge,
            [&bridge, state = std::move(state)]() mutable {
                applySignerState(bridge, std::move(state));
            },
            Qt::QueuedConnection);
        if (ready && runtime->writeService) {
            (void)runtime->writeService->resume(runtime->currentSessionSnapshot(), writeObserver);
        }
    };

    const auto sessionObserver = [&bridge, runtime, authenticationAvailable, signerObserver]
        (application::session::SessionState state) mutable {
            const auto signerSession = state.session;
            runtime->setCurrentSession(signerSession);
            QMetaObject::invokeMethod(
                &bridge,
                [&bridge, runtime, state = std::move(state), authenticationAvailable]() mutable {
                    applySessionState(bridge, std::move(state), authenticationAvailable);
                    runtime->authenticationPollInFlight.store(false, std::memory_order_release);
                },
                Qt::QueuedConnection);

            if (runtime->signerService) {
                (void)runtime->signerService->restore(signerSession, signerObserver);
            } else if (signerSession) {
                application::signer::SignerState signerState{
                    .phase = application::signer::SignerPhase::Unavailable,
                    .error = runtime->signerSetupError.value_or(foundation::error::Error::make(
                        foundation::error::ErrorCode::Unsupported,
                        "Protocol signer composition is not available in this build.")),
                };
                signerObserver(std::move(signerState));
            } else {
                signerObserver(application::signer::SignerState{
                    .phase = application::signer::SignerPhase::SignedOut,
                });
            }
        };

    QObject::connect(&bridge, &PresentationBridge::signInRequested, &bridge,
        [&bridge, runtime, sessionObserver, siwfDomain, siwfUri] {
            auto status = runtime->sessionService->beginSignIn(
                capability::auth::SignInRequest{
                    .domain = siwfDomain,
                    .siweUri = siwfUri,
                },
                sessionObserver);
            if (!status) {
                bridge.applyAuthenticationError(
                    QStringLiteral("The authentication worker is unavailable."));
            }
        });

    QObject::connect(&bridge, &PresentationBridge::signInCancelRequested, &bridge,
        [runtime, sessionObserver] {
            (void)runtime->sessionService->cancelSignIn(sessionObserver);
        });

    QObject::connect(&bridge, &PresentationBridge::signOutRequested, &bridge,
        [runtime, sessionObserver] {
            (void)runtime->sessionService->signOut(sessionObserver);
        });

    QObject::connect(&bridge, &PresentationBridge::signerProvisionRequested, &bridge,
        [&bridge, runtime, signerObserver] {
            if (!runtime->signerService) {
                application::signer::SignerState state{
                    .phase = application::signer::SignerPhase::Unavailable,
                    .error = runtime->signerSetupError.value_or(foundation::error::Error::make(
                        foundation::error::ErrorCode::Unsupported,
                        "Protocol signer composition is not available in this build.")),
                };
                applySignerState(bridge, std::move(state));
                return;
            }
            auto status = runtime->signerService->provision(
                runtime->currentSessionSnapshot(), signerObserver);
            if (!status) {
                application::signer::SignerState state{
                    .phase = application::signer::SignerPhase::Unavailable,
                    .error = std::move(status.error()),
                };
                applySignerState(bridge, std::move(state));
            }
        });

    QObject::connect(&bridge, &PresentationBridge::signerRevokeRequested, &bridge,
        [&bridge, runtime, signerObserver] {
            if (!runtime->signerService) { return; }
            auto status = runtime->signerService->revoke(
                runtime->currentSessionSnapshot(), signerObserver);
            if (!status) {
                application::signer::SignerState state{
                    .phase = application::signer::SignerPhase::Unavailable,
                    .error = std::move(status.error()),
                };
                applySignerState(bridge, std::move(state));
            }
        });

    QObject::connect(&bridge, &PresentationBridge::publishCastRequested, &bridge,
        [&bridge, runtime, writeObserver](const QString& text) {
            if (!runtime->writeService) {
                bridge.applyWriteState(
                    QStringLiteral("blocked"),
                    false,
                    QStringLiteral("Publishing is unavailable in this runtime."),
                    runtime->writeSetupError
                        ? QString::fromStdString(runtime->writeSetupError->message)
                        : QStringLiteral("Durable PublishCast composition is not available."));
                return;
            }
            auto status = runtime->writeService->publish(
                runtime->currentSessionSnapshot(),
                application::write::PublishCastRequest{.text = text.toStdString()},
                writeObserver);
            if (!status) {
                bridge.applyWriteState(
                    QStringLiteral("failed"),
                    false,
                    QStringLiteral("Publish could not be scheduled."),
                    QString::fromStdString(status.error().message));
            }
        });

    QObject::connect(&bridge, &PresentationBridge::publishReplyRequested, &bridge,
        [&bridge, runtime, writeObserver](
            const QString& text, const qulonglong parentAuthorFid, const QString& parentCastId) {
            if (!runtime->writeService) {
                bridge.applyWriteState(
                    QStringLiteral("blocked"),
                    false,
                    QStringLiteral("Replying is unavailable in this runtime."),
                    runtime->writeSetupError
                        ? QString::fromStdString(runtime->writeSetupError->message)
                        : QStringLiteral("Durable CAST_ADD composition is not available."));
                return;
            }
            auto status = runtime->writeService->publish(
                runtime->currentSessionSnapshot(),
                application::write::PublishCastRequest{
                    .text = text.toStdString(),
                    .parent = domain::cast::CastReference{
                        .author = domain::identity::Fid{static_cast<std::uint64_t>(parentAuthorFid)},
                        .id = domain::cast::CastId{parentCastId.toStdString()},
                    },
                },
                writeObserver);
            if (!status) {
                bridge.applyWriteState(
                    QStringLiteral("failed"),
                    false,
                    QStringLiteral("Reply could not be scheduled."),
                    QString::fromStdString(status.error().message));
            }
        });

    QObject::connect(&bridge, &PresentationBridge::reactionRequested, &bridge,
        [&bridge, runtime, writeObserver](const QString& kind, const qulonglong targetAuthorFid,
            const QString& targetCastId, const bool active) {
            if (!runtime->writeService) {
                bridge.applyWriteState(
                    QStringLiteral("blocked"),
                    false,
                    QStringLiteral("Reactions are unavailable in this runtime."),
                    runtime->writeSetupError
                        ? QString::fromStdString(runtime->writeSetupError->message)
                        : QStringLiteral("Durable reaction composition is not available."));
                return;
            }
            const auto reaction = kind == QStringLiteral("like")
                ? application::write::ReactionKind::Like
                : application::write::ReactionKind::Recast;
            auto status = runtime->writeService->setReaction(
                runtime->currentSessionSnapshot(),
                domain::cast::CastReference{
                    .author = domain::identity::Fid{static_cast<std::uint64_t>(targetAuthorFid)},
                    .id = domain::cast::CastId{targetCastId.toStdString()},
                },
                reaction,
                active,
                writeObserver);
            if (!status) {
                bridge.applyWriteState(
                    QStringLiteral("failed"),
                    false,
                    QStringLiteral("Reaction could not be scheduled."),
                    QString::fromStdString(status.error().message));
            }
        });

    QObject::connect(&bridge, &PresentationBridge::followingMutationRequested, &bridge,
        [&bridge, runtime, writeObserver](const qulonglong targetFid, const bool following) {
            if (!runtime->writeService) {
                bridge.applyWriteState(
                    QStringLiteral("blocked"),
                    false,
                    QStringLiteral("Follow changes are unavailable in this runtime."),
                    runtime->writeSetupError
                        ? QString::fromStdString(runtime->writeSetupError->message)
                        : QStringLiteral("Durable follow composition is not available."));
                return;
            }
            auto status = runtime->writeService->setFollowing(
                runtime->currentSessionSnapshot(),
                domain::identity::Fid{static_cast<std::uint64_t>(targetFid)},
                following,
                writeObserver);
            if (!status) {
                bridge.applyWriteState(
                    QStringLiteral("failed"),
                    false,
                    QStringLiteral("Follow change could not be scheduled."),
                    QString::fromStdString(status.error().message));
            }
        });

    QObject::connect(&bridge, &PresentationBridge::removeCastRequested, &bridge,
        [&bridge, runtime, writeObserver](const qulonglong authorFid, const QString& castId) {
            if (!runtime->writeService) {
                bridge.applyWriteState(
                    QStringLiteral("blocked"),
                    false,
                    QStringLiteral("Cast deletion is unavailable in this runtime."),
                    runtime->writeSetupError
                        ? QString::fromStdString(runtime->writeSetupError->message)
                        : QStringLiteral("Durable CAST_REMOVE composition is not available."));
                return;
            }
            auto status = runtime->writeService->removeCast(
                runtime->currentSessionSnapshot(),
                domain::cast::CastReference{
                    .author = domain::identity::Fid{static_cast<std::uint64_t>(authorFid)},
                    .id = domain::cast::CastId{castId.toStdString()},
                },
                writeObserver);
            if (!status) {
                bridge.applyWriteState(
                    QStringLiteral("failed"),
                    false,
                    QStringLiteral("Cast deletion could not be scheduled."),
                    QString::fromStdString(status.error().message));
            }
        });

    auto* const writeResumeTimer = new QTimer(&bridge);
    writeResumeTimer->setInterval(15'000);
    QObject::connect(writeResumeTimer, &QTimer::timeout, &bridge,
        [&bridge, runtime, writeObserver] {
            if (!runtime->writeService || !bridge.writeReady() || bridge.writeBusy()) return;
            (void)runtime->writeService->resume(runtime->currentSessionSnapshot(), writeObserver);
        });
    writeResumeTimer->start();

    auto* const authenticationPollTimer = new QTimer(&bridge);
    authenticationPollTimer->setInterval(1'000);
    QObject::connect(authenticationPollTimer, &QTimer::timeout, &bridge,
        [&bridge, runtime, sessionObserver] {
            if (bridge.authenticationPhase() != QStringLiteral("awaiting-approval")) {
                return;
            }
            bool expected = false;
            if (!runtime->authenticationPollInFlight.compare_exchange_strong(
                    expected, true, std::memory_order_acq_rel)) {
                return;
            }
            auto status = runtime->sessionService->pollSignIn(sessionObserver);
            if (!status) {
                runtime->authenticationPollInFlight.store(false, std::memory_order_release);
            }
        });
    authenticationPollTimer->start();

    (void)runtime->sessionService->restore(sessionObserver);
    QObject::connect(&bridge, &PresentationBridge::identityRequested, &bridge,
        [&bridge, runtime](const QString& requestedUsername, const bool allowRecoveryProbe) {
            runtime->cancelActiveRequest();
            auto request = runtime->service->openIdentity(requestedUsername.toStdString(),
                [&bridge](application::read::model::IdentityState state) {
                    QMetaObject::invokeMethod(&bridge, [&bridge, state = std::move(state)]() mutable {
                        const auto* profile = state.profile ? &*state.profile : nullptr;
                        bridge.applyIdentity(
                            state.fid ? static_cast<qulonglong>(state.fid->value) : 0,
                            displayName(profile), username(profile), statusText(state.metadata),
                            errorText(state.metadata), diagnosticText(state.metadata), isBusy(state.metadata),
                            state.metadata.isStale, state.metadata.isSourceUnavailable);
                    }, Qt::QueuedConnection);
                }, application::read::model::ReadOptions{
                    .allowRecoveryProbe = allowRecoveryProbe,
                });
            if (request) { runtime->keepRequest(std::move(*request)); }
            else { bridge.applyRuntimeState(false, QStringLiteral("The read worker is unavailable.")); }
        });

    QObject::connect(&bridge, &PresentationBridge::feedRequested, &bridge,
        [&bridge, runtime](const QString& feed, const qulonglong fid,
            const QString& channel, const QString& continuation,
            const bool allowRecoveryProbe) {
            runtime->cancelActiveRequest();
            application::read::model::FeedQuery query{};
            query.kind = feed == QStringLiteral("following")
                ? application::read::model::FeedQuery::Kind::Following
                : feed == QStringLiteral("channel")
                    ? application::read::model::FeedQuery::Kind::Channel
                    : application::read::model::FeedQuery::Kind::Trending;
            if (query.kind == application::read::model::FeedQuery::Kind::Following) {
                query.fid = domain::identity::Fid{static_cast<std::uint64_t>(fid)};
            }
            if (query.kind == application::read::model::FeedQuery::Kind::Channel) {
                query.channel = domain::channel::ChannelId{channel.toStdString()};
            }
            if (!continuation.isEmpty()) {
                query.continuation = capability::pagination::ContinuationToken{continuation.toStdString()};
            }
            auto request = runtime->service->openFeed(std::move(query),
                [&bridge](application::read::model::FeedState state) {
                    QMetaObject::invokeMethod(&bridge, [&bridge, state = std::move(state)]() mutable {
                        applyFeedState(bridge, std::move(state));
                    }, Qt::QueuedConnection);
                }, application::read::model::ReadOptions{
                    .allowRecoveryProbe = allowRecoveryProbe,
                });
            if (request) { runtime->keepRequest(std::move(*request)); }
            else { bridge.applyRuntimeState(false, QStringLiteral("The read worker is unavailable.")); }
        });

    QObject::connect(&bridge, &PresentationBridge::castRequested, &bridge,
        [&bridge, runtime](const QString& castId, const bool allowRecoveryProbe) {
            runtime->cancelActiveRequest();
            auto request = runtime->service->openCast(domain::cast::CastId{castId.toStdString()},
                [&bridge](application::read::model::CastState state) {
                    QMetaObject::invokeMethod(&bridge, [&bridge, state = std::move(state)]() mutable {
                        QVariantMap detail{{QStringLiteral("castId"), QString::fromStdString(state.castId.value)}};
                        if (state.cast) {
                            detail.insert(QStringLiteral("authorFid"), static_cast<qulonglong>(state.cast->author.value));
                            detail.insert(QStringLiteral("text"), QString::fromStdString(state.cast->text));
                            detail.insert(QStringLiteral("time"), relativeTime(state.cast->createdAt));
                            detail.insert(QStringLiteral("embedUrl"), firstUrlEmbed(*state.cast));
                            detail.insert(QStringLiteral("embeds"), embedItems(*state.cast));
                            detail.insert(QStringLiteral("replyCount"), static_cast<qulonglong>(state.cast->engagement.replies));
                            detail.insert(QStringLiteral("recastCount"), static_cast<qulonglong>(state.cast->engagement.recasts));
                            detail.insert(QStringLiteral("likeCount"), static_cast<qulonglong>(state.cast->engagement.likes));
                            detail.insert(QStringLiteral("parentCastId"), state.cast->parent
                                ? QString::fromStdString(state.cast->parent->value) : QString{});
                            detail.insert(QStringLiteral("parentUrl"), state.cast->parentUrl
                                ? QString::fromStdString(*state.cast->parentUrl) : QString{});
                        }
                        if (state.author) {
                            detail.insert(QStringLiteral("author"), displayName(&*state.author));
                            detail.insert(QStringLiteral("username"), username(&*state.author));
                            detail.insert(QStringLiteral("avatarUrl"), avatarUrl(&*state.author));
                        }
                        bridge.applyDetail(QStringLiteral("cast"), std::move(detail),
                            statusText(state.metadata), errorText(state.metadata), diagnosticText(state.metadata), isBusy(state.metadata),
                            state.metadata.isStale, state.metadata.isSourceUnavailable);
                    }, Qt::QueuedConnection);
                }, application::read::model::ReadOptions{
                    .allowRecoveryProbe = allowRecoveryProbe,
                });
            if (request) { runtime->keepRequest(std::move(*request)); }
            else { bridge.applyRuntimeState(false, QStringLiteral("The read worker is unavailable.")); }
        });

    QObject::connect(&bridge, &PresentationBridge::profileRequested, &bridge,
        [&bridge, runtime](const qulonglong fid, const bool allowRecoveryProbe) {
            runtime->cancelActiveRequest();
            auto request = runtime->service->openProfile(
                domain::identity::Fid{static_cast<std::uint64_t>(fid)},
                [&bridge](application::read::model::ProfileState state) {
                    QMetaObject::invokeMethod(&bridge, [&bridge, state = std::move(state)]() mutable {
                        QVariantMap detail{};
                        if (state.profile) {
                            detail.insert(QStringLiteral("displayName"), displayName(&*state.profile));
                            detail.insert(QStringLiteral("username"), username(&*state.profile));
                            detail.insert(QStringLiteral("avatarUrl"), avatarUrl(&*state.profile));
                            detail.insert(QStringLiteral("bio"), QString::fromStdString(state.profile->bio));
                            detail.insert(QStringLiteral("fid"), static_cast<qulonglong>(state.profile->fid.value));
                        }
                        bridge.applyDetail(QStringLiteral("profile"), std::move(detail),
                            statusText(state.metadata), errorText(state.metadata), diagnosticText(state.metadata), isBusy(state.metadata),
                            state.metadata.isStale, state.metadata.isSourceUnavailable);
                    }, Qt::QueuedConnection);
                }, application::read::model::ReadOptions{
                    .allowRecoveryProbe = allowRecoveryProbe,
                });
            if (request) { runtime->keepRequest(std::move(*request)); }
            else { bridge.applyRuntimeState(false, QStringLiteral("The read worker is unavailable.")); }
        });

    QObject::connect(&bridge, &PresentationBridge::socialRequested, &bridge,
        [&bridge, runtime](const QString& kind, const qulonglong fid,
            const QString& continuation, const bool allowRecoveryProbe) {
            runtime->cancelActiveRequest();
            application::read::model::SocialQuery query{
                .kind = kind == QStringLiteral("followers")
                    ? application::read::model::SocialQuery::Kind::Followers
                    : application::read::model::SocialQuery::Kind::Following,
                .fid = domain::identity::Fid{static_cast<std::uint64_t>(fid)},
            };
            if (!continuation.isEmpty()) {
                query.continuation = capability::pagination::ContinuationToken{continuation.toStdString()};
            }
            auto request = runtime->service->openSocial(std::move(query),
                [&bridge](application::read::model::SocialState state) {
                    QMetaObject::invokeMethod(&bridge, [&bridge, state = std::move(state)]() mutable {
                        applySocialState(bridge, std::move(state));
                    }, Qt::QueuedConnection);
                }, application::read::model::ReadOptions{
                    .allowRecoveryProbe = allowRecoveryProbe,
                });
            if (request) { runtime->keepRequest(std::move(*request)); }
            else { bridge.applyRuntimeState(false, QStringLiteral("The read worker is unavailable.")); }
        });
}

[[nodiscard]] QString optionValue(const QStringList& arguments, const QString& prefix)
{
    for (const QString& argument : arguments) {
        if (argument.startsWith(prefix)) {
            return argument.sliced(prefix.size()).trimmed();
        }
    }
    return {};
}

[[nodiscard]] std::function<foundation::result::Status(const std::string&)>
makeWalletApprovalLauncher(QString launchTemplate)
{
    return [launchTemplate = std::move(launchTemplate)](const std::string& approvalUrl)
        -> foundation::result::Status {
        const QString rawUrl = QString::fromStdString(approvalUrl);
        QString target = rawUrl;
        if (!launchTemplate.isEmpty()) {
            if (!launchTemplate.contains(QStringLiteral("{url}")) &&
                !launchTemplate.contains(QStringLiteral("{rawUrl}"))) {
                return std::unexpected(foundation::error::Error::make(
                    foundation::error::ErrorCode::InvalidArgument,
                    "Wallet launch URL template must contain {url} or {rawUrl}."));
            }
            target = launchTemplate;
            target.replace(
                QStringLiteral("{url}"),
                QString::fromLatin1(QUrl::toPercentEncoding(rawUrl)));
            target.replace(QStringLiteral("{rawUrl}"), rawUrl);
        }

        const QUrl parsed{target};
        const QString scheme = parsed.scheme().toLower();
        if (!parsed.isValid() || scheme.isEmpty() ||
            scheme == QStringLiteral("javascript") ||
            scheme == QStringLiteral("data") ||
            scheme == QStringLiteral("file")) {
            return std::unexpected(foundation::error::Error::make(
                foundation::error::ErrorCode::InvalidArgument,
                "Wallet approval launcher produced an invalid or unsafe URL."));
        }

        bool opened{false};
        const auto open = [&opened, parsed] { opened = QDesktopServices::openUrl(parsed); };
        if (auto* app = QCoreApplication::instance(); app != nullptr &&
            QThread::currentThread() != app->thread()) {
            if (!QMetaObject::invokeMethod(app, open, Qt::BlockingQueuedConnection)) {
                return std::unexpected(foundation::error::Error::make(
                    foundation::error::ErrorCode::Unavailable,
                    "Could not dispatch wallet approval URL opening to the Qt application thread."));
            }
        } else {
            open();
        }
        if (!opened) {
            return std::unexpected(foundation::error::Error::make(
                foundation::error::ErrorCode::Unavailable,
                "The platform could not open a browser or wallet for custody approval."));
        }
        return {};
    };
}

}

int main(int argc, char* argv[])
{
    QGuiApplication application(argc, argv);
    QCoreApplication::setOrganizationName(QStringLiteral("Genycaster"));
    QCoreApplication::setApplicationName(QStringLiteral("Genycaster"));
    QQuickStyle::setStyle(QStringLiteral(FARCASTER_QT_QUICK_CONTROLS_STYLE));

    const QStringList arguments = QCoreApplication::arguments();
    const bool isSmokeTest = arguments.contains(QStringLiteral("--smoke-test"));
    const bool isVisualTest = arguments.contains(QStringLiteral("--visual-test"));
    const bool isRuntimeSmokeTest = arguments.contains(QStringLiteral("--runtime-smoke-test"));
    const qsizetype snapshotIndex = arguments.indexOf(QStringLiteral("--snapshot"));
    const QString snapshotPath = snapshotIndex >= 0 && snapshotIndex + 1 < arguments.size()
        ? arguments[snapshotIndex + 1] : QString{};
    const auto deploymentEndpoints =
        application::configuration::configuredDeploymentEndpoints();

    QString networkProxyText = optionValue(arguments, QStringLiteral("--network-proxy="));
    if (networkProxyText.isEmpty()) {
        networkProxyText = qEnvironmentVariable("GENYCASTER_NETWORK_PROXY").trimmed();
    }
    if (networkProxyText.isEmpty()) {
        networkProxyText = QStringLiteral("system");
    }
    networkProxyText = networkProxyText.toLower();
    farcaster::transport::qtnetwork::ProxyPolicy networkProxyPolicy{};
    if (networkProxyText == QStringLiteral("direct")) {
        networkProxyPolicy = farcaster::transport::qtnetwork::ProxyPolicy::Direct;
    } else if (networkProxyText == QStringLiteral("system")) {
        networkProxyPolicy = farcaster::transport::qtnetwork::ProxyPolicy::System;
    } else {
        qCritical().noquote()
            << "GENYCASTER_NETWORK_PROXY/--network-proxy must be 'system' or 'direct'.";
        return 2;
    }

    QString providerBaseUrlText = optionValue(
        arguments, QStringLiteral("--hypersnap-base-url="));
    if (providerBaseUrlText.isEmpty()) {
        providerBaseUrlText = qEnvironmentVariable("GENYCASTER_HYPERSNAP_BASE_URL").trimmed();
    }
    const std::optional<std::string> providerBaseUrl = providerBaseUrlText.isEmpty()
        ? std::nullopt : std::optional<std::string>{providerBaseUrlText.toStdString()};

    QString snapchainBaseUrlText = optionValue(arguments, QStringLiteral("--snapchain-base-url="));
    if (snapchainBaseUrlText.isEmpty()) {
        snapchainBaseUrlText = qEnvironmentVariable("GENYCASTER_SNAPCHAIN_BASE_URL").trimmed();
    }
    if (snapchainBaseUrlText.isEmpty()) {
        snapchainBaseUrlText = QString::fromStdString(
            std::string{deploymentEndpoints.snapchainBaseUrl});
    }
    const std::optional<std::string> snapchainBaseUrl{snapchainBaseUrlText.toStdString()};

    QString snapchainAuthorizationHeaderText = optionValue(
        arguments, QStringLiteral("--snapchain-auth-header="));
    if (snapchainAuthorizationHeaderText.isEmpty()) {
        snapchainAuthorizationHeaderText =
            qEnvironmentVariable("GENYCASTER_SNAPCHAIN_AUTH_HEADER").trimmed();
    }
    QString snapchainAuthorizationValueText = optionValue(
        arguments, QStringLiteral("--snapchain-auth-value="));
    if (snapchainAuthorizationValueText.isEmpty()) {
        snapchainAuthorizationValueText =
            qEnvironmentVariable("GENYCASTER_SNAPCHAIN_AUTH_VALUE").trimmed();
    }
    const std::optional<std::string> snapchainAuthorizationHeader =
        snapchainAuthorizationHeaderText.isEmpty()
            ? std::nullopt
            : std::optional<std::string>{snapchainAuthorizationHeaderText.toStdString()};
    const std::optional<std::string> snapchainAuthorizationValue =
        snapchainAuthorizationValueText.isEmpty()
            ? std::nullopt
            : std::optional<std::string>{snapchainAuthorizationValueText.toStdString()};
    if (snapchainAuthorizationHeader.has_value() != snapchainAuthorizationValue.has_value()) {
        qCritical().noquote()
            << "Snapchain advanced authorization requires both --snapchain-auth-header/"
               "GENYCASTER_SNAPCHAIN_AUTH_HEADER and --snapchain-auth-value/"
               "GENYCASTER_SNAPCHAIN_AUTH_VALUE.";
        return 2;
    }

    QString appFidText = optionValue(arguments, QStringLiteral("--app-fid="));
    if (appFidText.isEmpty()) {
        appFidText = qEnvironmentVariable("GENYCASTER_APP_FID").trimmed();
    }
    std::optional<std::uint64_t> appFid{};
    if (!appFidText.isEmpty()) {
        bool ok{false};
        const qulonglong parsed = appFidText.toULongLong(&ok);
        if (!ok || parsed == 0U) {
            qCritical().noquote() << "GENYCASTER_APP_FID/--app-fid must be a non-zero unsigned integer.";
            return 2;
        }
        appFid = static_cast<std::uint64_t>(parsed);
    }

    QString signerAttestationUrlText = optionValue(
        arguments, QStringLiteral("--signer-attestation-url="));
    if (signerAttestationUrlText.isEmpty()) {
        signerAttestationUrlText =
            qEnvironmentVariable("GENYCASTER_SIGNER_ATTESTATION_URL").trimmed();
    }
    const std::optional<std::string> signerAttestationUrl = signerAttestationUrlText.isEmpty()
        ? std::nullopt : std::optional<std::string>{signerAttestationUrlText.toStdString()};

    QString walletLaunchTemplate = optionValue(
        arguments, QStringLiteral("--wallet-launch-url-template="));
    if (walletLaunchTemplate.isEmpty()) {
        walletLaunchTemplate =
            qEnvironmentVariable("GENYCASTER_WALLET_LAUNCH_URL_TEMPLATE").trimmed();
    }

    QString siwfDomainText = optionValue(arguments, QStringLiteral("--siwf-domain="));
    if (siwfDomainText.isEmpty()) {
        siwfDomainText = qEnvironmentVariable("GENYCASTER_SIWF_DOMAIN").trimmed();
    }
    if (siwfDomainText.isEmpty()) {
        siwfDomainText = QString::fromStdString(std::string{deploymentEndpoints.siwfDomain});
    }
    QString siwfUriText = optionValue(arguments, QStringLiteral("--siwf-uri="));
    if (siwfUriText.isEmpty()) {
        siwfUriText = qEnvironmentVariable("GENYCASTER_SIWF_URI").trimmed();
    }
    if (siwfUriText.isEmpty()) {
        siwfUriText = QString::fromStdString(std::string{deploymentEndpoints.siwfUri});
    }
    QString authRelayUrlText = optionValue(arguments, QStringLiteral("--farcaster-auth-relay="));
    if (authRelayUrlText.isEmpty()) {
        authRelayUrlText = qEnvironmentVariable("GENYCASTER_FARCASTER_AUTH_RELAY").trimmed();
    }
    QString optimismRpcUrlText = optionValue(arguments, QStringLiteral("--optimism-rpc-url="));
    if (optimismRpcUrlText.isEmpty()) {
        optimismRpcUrlText = qEnvironmentVariable("GENYCASTER_OPTIMISM_RPC_URL").trimmed();
    }
    const std::optional<std::string> authRelayUrl = authRelayUrlText.isEmpty()
        ? std::nullopt : std::optional<std::string>{authRelayUrlText.toStdString()};
    const std::optional<std::string> optimismRpcUrl = optimismRpcUrlText.isEmpty()
        ? std::nullopt : std::optional<std::string>{optimismRpcUrlText.toStdString()};
    const std::string siwfDomain = siwfDomainText.toStdString();
    const std::string siwfUri = siwfUriText.toStdString();
#if FARCASTER_HAS_FARCASTER_AUTH
    const bool authenticationAvailable = !siwfDomain.empty() && !siwfUri.empty();
#else
    const bool authenticationAvailable = false;
#endif

    // Optional dev/demo hook. Outside test runs, the last successfully requested
    // identity is also restored so the reliable Following surface can come back
    // without forcing the user through onboarding on every launch.
    QString startupIdentity = optionValue(arguments, QStringLiteral("--auto-open-identity="));
    if (startupIdentity.isEmpty()) {
        startupIdentity = qEnvironmentVariable("GENYCASTER_DEMO_IDENTITY").trimmed();
    }

    const QString settingsPath = optionValue(arguments, QStringLiteral("--settings-path="));
    auto settingsStorage = settingsPath.isEmpty()
        ? std::make_unique<QSettings>()
        : std::make_unique<QSettings>(settingsPath, QSettings::IniFormat);
    QSettings& settings = *settingsStorage;
    const bool canUseRememberedIdentity = !isSmokeTest && !isVisualTest
        && (!isRuntimeSmokeTest || !settingsPath.isEmpty());
    if (startupIdentity.isEmpty() && canUseRememberedIdentity) {
        startupIdentity = settings.value(QStringLiteral("identity/username")).toString().trimmed();
    }

    QString pendingIdentityUsername{};
    PresentationBridge presentationBridge{};
    QObject::connect(&presentationBridge, &PresentationBridge::identityRequested,
        &presentationBridge, [&pendingIdentityUsername](const QString& username, const bool) {
            pendingIdentityUsername = username.trimmed();
        });
    QObject::connect(&presentationBridge, &PresentationBridge::stateChanged,
        &presentationBridge, [&presentationBridge, &settings, &pendingIdentityUsername,
                             canUseRememberedIdentity] {
            if (pendingIdentityUsername.isEmpty() || presentationBridge.identityFid() == 0
                    || presentationBridge.isBusy() || !presentationBridge.errorText().isEmpty()
                    || !canUseRememberedIdentity) {
                return;
            }
            settings.setValue(QStringLiteral("identity/username"), pendingIdentityUsername);
            pendingIdentityUsername.clear();
        });
    if (!isSmokeTest && !isVisualTest) {
        QNetworkInformation::loadDefaultBackend();
        if (auto* networkInformation = QNetworkInformation::instance()) {
            const auto initialReachability = networkInformation->reachability();
            const auto applyReachability = [&presentationBridge](const QNetworkInformation::Reachability reachability) {
                const bool known = reachability != QNetworkInformation::Reachability::Unknown;
                const bool online = reachability != QNetworkInformation::Reachability::Disconnected;
                presentationBridge.applyNetworkReachability(known, online);
            };
            applyReachability(initialReachability);
            QObject::connect(networkInformation, &QNetworkInformation::reachabilityChanged,
                &presentationBridge,
                [&presentationBridge, previousReachability = initialReachability, applyReachability]
                (const QNetworkInformation::Reachability reachability) mutable {
                    const bool reconnected = previousReachability == QNetworkInformation::Reachability::Disconnected
                        && reachability != QNetworkInformation::Reachability::Disconnected
                        && reachability != QNetworkInformation::Reachability::Unknown;
                    previousReachability = reachability;
                    applyReachability(reachability);
                    if (reconnected && presentationBridge.runtimeReady() && !presentationBridge.isBusy()) {
                        QTimer::singleShot(350, &presentationBridge, [&presentationBridge] {
                            if (!presentationBridge.isBusy() && !presentationBridge.isOffline()) {
                                presentationBridge.retryAutomatically();
                            }
                        });
                    }
                });
        } else {
            presentationBridge.applyNetworkReachability(false, true);
        }
    }
    if (isSmokeTest || isVisualTest) {
        presentationBridge.applyVerificationFixture();
    }
    QQmlApplicationEngine engine{};
    engine.rootContext()->setContextProperty(QStringLiteral("presentationBridge"), &presentationBridge);
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreationFailed, &application,
        [] { QCoreApplication::exit(1); }, Qt::QueuedConnection);
    engine.loadFromModule(QStringLiteral("Farcaster.Client"), QStringLiteral("Main"));
    if (engine.rootObjects().isEmpty()) { return 1; }

    std::shared_ptr<Runtime> runtime{};
    std::jthread bootstrap{};
    if (!isSmokeTest && !isVisualTest) {
        const QString databasePathText = optionValue(
            arguments, QStringLiteral("--database-path="));
        const std::filesystem::path databasePath = databasePathText.isEmpty()
            ? std::filesystem::path{
                  QStandardPaths::writableLocation(QStandardPaths::AppLocalDataLocation).toStdString()}
                  / "genycaster.sqlite3"
            : std::filesystem::path{databasePathText.toStdString()};
        bootstrap = std::jthread([&presentationBridge, &runtime, databasePath, networkProxyPolicy,
                                  providerBaseUrl, authRelayUrl, optimismRpcUrl, snapchainBaseUrl,
                                  snapchainAuthorizationHeader, snapchainAuthorizationValue, appFid,
                                  signerAttestationUrl, walletLaunchTemplate,
                                  siwfDomain, siwfUri, authenticationAvailable, startupIdentity,
                                  isRuntimeSmokeTest] {
            auto made = makeRuntime(
                databasePath,
                networkProxyPolicy,
                providerBaseUrl,
                authRelayUrl,
                optimismRpcUrl,
                snapchainBaseUrl,
                snapchainAuthorizationHeader,
                snapchainAuthorizationValue,
                appFid,
                signerAttestationUrl,
                makeWalletApprovalLauncher(walletLaunchTemplate));
            if (!made) {
                const QString message = QString::fromStdString(made.error().message);
                QMetaObject::invokeMethod(&presentationBridge,
                    [&presentationBridge, message] { presentationBridge.applyRuntimeState(false, message); },
                    Qt::QueuedConnection);
                return;
            }
            auto readyRuntime = std::shared_ptr<Runtime>{std::move(*made)};
            QMetaObject::invokeMethod(&presentationBridge,
                [&presentationBridge, &runtime, readyRuntime = std::move(readyRuntime),
                 siwfDomain, siwfUri, authenticationAvailable, startupIdentity, isRuntimeSmokeTest]() mutable {
                    runtime = std::move(readyRuntime);
                    connectRuntime(
                        presentationBridge, runtime, authenticationAvailable, siwfDomain, siwfUri);
                    presentationBridge.applyRuntimeState(true);
                    if (startupIdentity.isEmpty()) {
                        if (isRuntimeSmokeTest) {
                            presentationBridge.selectFeed(QStringLiteral("trending"));
                        }
                        // A network-wide derived feed must not gate normal application
                        // startup. Home becomes immediately interactive; the user can
                        // open an identity for Following or explicitly browse Trending.
                        return;
                    }
                    // PresentationBridge owns the identity-to-Home transition for both
                    // restored and manually opened identities. This keeps Trending an
                    // explicit Explore capability and avoids startup-only orchestration.
                    presentationBridge.openIdentity(startupIdentity);
                }, Qt::QueuedConnection);
        });
    }

    if (isSmokeTest) {
        QObject* const rootObject = engine.rootObjects().constFirst();
        bool ready = rootObject != nullptr
            && rootObject->objectName() == QStringLiteral("rootWindow")
            && rootObject->property("isReady").toBool()
            && rootObject->findChild<QObject*>(QStringLiteral("appShell")) != nullptr
            && rootObject->findChild<QObject*>(QStringLiteral("readList")) != nullptr;
        const QStringList sidebarActions{
            QStringLiteral("trending"),
            QStringLiteral("following"),
            QStringLiteral("profile"),
            QStringLiteral("followers"),
            QStringLiteral("following-list"),
        };
        for (const QString& action : sidebarActions) {
            QObject* const button = rootObject == nullptr ? nullptr
                : rootObject->findChild<QObject*>(QStringLiteral("sidebarAction-") + action);
            ready = ready && button != nullptr
                && QMetaObject::invokeMethod(button, "clicked", Qt::DirectConnection);
        }
        if (!ready) { return 2; }
        QMetaObject::invokeMethod(&application, [] { QCoreApplication::exit(0); }, Qt::QueuedConnection);
    }
    if (isRuntimeSmokeTest) {
        auto* const poller = new QTimer(&application);
        poller->setInterval(25);
        QObject::connect(poller, &QTimer::timeout, &application,
            [&presentationBridge] {
                if (!presentationBridge.runtimeReady()) { return; }
                if (!presentationBridge.errorText().isEmpty()) {
                    qWarning().noquote() << "Read diagnostic:" << presentationBridge.diagnosticText();
                    QCoreApplication::exit(5);
                } else if (!presentationBridge.rows().isEmpty() && !presentationBridge.isBusy()) {
                    QCoreApplication::exit(0);
                }
            });
        poller->start();
        QTimer::singleShot(10'000, &application, [] { QCoreApplication::exit(6); });
    }
    if (isVisualTest && !snapshotPath.isEmpty()) {
        auto* const window = qobject_cast<QQuickWindow*>(engine.rootObjects().constFirst());
        if (window == nullptr) { return 3; }
        for (const QString& argument : arguments) {
            if (argument.startsWith(QStringLiteral("--width="))) {
                window->setWidth(argument.sliced(8).toInt());
            } else if (argument.startsWith(QStringLiteral("--height="))) {
                window->setHeight(argument.sliced(9).toInt());
            }
        }
        QTimer::singleShot(600, &application, [window, snapshotPath] {
            const bool saved = window->grabWindow().save(snapshotPath);
            QCoreApplication::exit(saved ? 0 : 4);
        });
    }
    const QString snapshotLivePath = optionValue(arguments, QStringLiteral("--snapshot-live="));
    if (!snapshotLivePath.isEmpty()) {
        // Grab a screenshot of the real running app (live data, not the fixture)
        // once the demo feed has rendered. Used to visually verify real content.
        if (auto* const window = qobject_cast<QQuickWindow*>(engine.rootObjects().constFirst())) {
            window->resize(1280, 900);
        }
        QTimer::singleShot(5'000, &application, [&engine, snapshotLivePath] {
            auto* const window = qobject_cast<QQuickWindow*>(engine.rootObjects().constFirst());
            if (window == nullptr) {
                QCoreApplication::exit(3);
                return;
            }
            const bool saved = window->grabWindow().save(snapshotLivePath);
            QCoreApplication::exit(saved ? 0 : 4);
        });
    }
    return application.exec();
}
