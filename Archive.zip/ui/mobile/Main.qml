import QtQuick
import QtQuick.Controls

ApplicationWindow {
    id: rootWindow
    objectName: "rootWindow"

    width: 430
    height: 860
    minimumWidth: 360
    minimumHeight: 640
    visible: true
    color: Theme.background
    title: qsTr("Genycaster")

    palette.window: Theme.background
    palette.windowText: Theme.ink
    palette.base: Theme.surface
    palette.alternateBase: Theme.surfaceMuted
    palette.text: Theme.ink
    palette.button: Theme.surface
    palette.buttonText: Theme.ink
    palette.highlight: Theme.primary
    palette.highlightedText: Theme.surface
    palette.placeholderText: Theme.inkMuted

    readonly property bool isReady: appShell.isReady

    AppShell {
        id: appShell
        anchors.fill: parent
    }
}
