set(farcasterQmlFiles
    mobile/Main.qml
    components/ActionButton.qml
    components/AppHeader.qml
    components/AppShell.qml
    components/Avatar.qml
    components/BottomNavButton.qml
    components/BottomNavigation.qml
    components/CastItem.qml
    components/CastSkeleton.qml
    components/EmbedCard.qml
    components/EngagementBar.qml
    components/DetailSurface.qml
    components/EmptyState.qml
    components/FeedHeader.qml
    components/FeedSurface.qml
    components/NavItem.qml
    components/ProfileListItem.qml
    components/SectionHeader.qml
    components/SideNavigation.qml
    components/StatusStrip.qml
    theme/Theme.qml
)

set_source_files_properties(theme/Theme.qml PROPERTIES QT_QML_SINGLETON_TYPE TRUE)

foreach(qmlFile IN LISTS farcasterQmlFiles)
    if(qmlFile MATCHES "^mobile/(.+)$")
        set(qmlResourceAlias "${CMAKE_MATCH_1}")
    else()
        set(qmlResourceAlias "${qmlFile}")
    endif()

    set_source_files_properties(
        "${qmlFile}"
        PROPERTIES
            QT_RESOURCE_ALIAS "${qmlResourceAlias}"
    )
endforeach()

aimcpp_reject_final_qml_creatable_types(
    SOURCES
        "${CMAKE_SOURCE_DIR}/src/presentation/qt/presentation_bridge.hpp"
)

qt_add_executable(farcaster_client
    mobile/main.cpp
)

set_target_properties(farcaster_client
    PROPERTIES
        RUNTIME_OUTPUT_DIRECTORY "${CMAKE_CURRENT_BINARY_DIR}/../bin"
)

target_compile_definitions(farcaster_client
    PRIVATE
        FARCASTER_QT_QUICK_CONTROLS_STYLE="Basic"
)

target_link_libraries(farcaster_client
    PRIVATE
        farcaster::presentation
        farcaster::application
        farcaster::application_write
        Qt6::Quick
        Qt6::Qml
        Qt6::QuickControls2
        Qt6::Network
        farcaster::execution
        farcaster::routing
        farcaster::storage
        farcaster::transport
        farcaster::transport_qt_network
)

if(FARCASTER_ENABLE_HYPERSNAP_PROVIDER)
    target_compile_definitions(farcaster_client PRIVATE FARCASTER_HAS_HYPERSNAP_PROVIDER=1)
    target_link_libraries(farcaster_client PRIVATE farcaster::provider_hypersnap)
else()
    target_compile_definitions(farcaster_client PRIVATE FARCASTER_HAS_HYPERSNAP_PROVIDER=0)
endif()

if(FARCASTER_ENABLE_COMPATIBILITY_PROVIDERS)
    target_compile_definitions(farcaster_client PRIVATE FARCASTER_HAS_FARCASTER_AUTH=1)
    target_link_libraries(farcaster_client PRIVATE farcaster::provider_compatibility_auth)
else()
    target_compile_definitions(farcaster_client PRIVATE FARCASTER_HAS_FARCASTER_AUTH=0)
endif()

if(FARCASTER_ENABLE_PROTOCOL_SIGNING)
    target_compile_definitions(farcaster_client PRIVATE FARCASTER_HAS_PROTOCOL_SIGNING=1)
    target_link_libraries(farcaster_client PRIVATE
        farcaster::platform_signer
        farcaster::protocol_write
        farcaster::storage_write
    )
else()
    target_compile_definitions(farcaster_client PRIVATE FARCASTER_HAS_PROTOCOL_SIGNING=0)
endif()

if(FARCASTER_ENABLE_SNAPCHAIN_SIGNER_PROVIDER)
    target_compile_definitions(farcaster_client PRIVATE FARCASTER_HAS_SNAPCHAIN_SIGNER=1)
    target_link_libraries(farcaster_client PRIVATE farcaster::provider_snapchain_signer)
else()
    target_compile_definitions(farcaster_client PRIVATE FARCASTER_HAS_SNAPCHAIN_SIGNER=0)
endif()

if(FARCASTER_ENABLE_SNAPCHAIN_WRITE_PROVIDER)
    target_compile_definitions(farcaster_client PRIVATE FARCASTER_HAS_SNAPCHAIN_WRITE=1)
    target_link_libraries(farcaster_client PRIVATE farcaster::provider_snapchain_write)
else()
    target_compile_definitions(farcaster_client PRIVATE FARCASTER_HAS_SNAPCHAIN_WRITE=0)
endif()

if(FARCASTER_ENABLE_BROWSER_WALLET_AUTHORIZER)
    target_compile_definitions(farcaster_client PRIVATE FARCASTER_HAS_BROWSER_WALLET_AUTHORIZER=1)
    target_link_libraries(farcaster_client PRIVATE farcaster::provider_compatibility_browser_wallet)
else()
    target_compile_definitions(farcaster_client PRIVATE FARCASTER_HAS_BROWSER_WALLET_AUTHORIZER=0)
endif()

if(FARCASTER_ENABLE_SIGNER_ATTESTATION_PROVIDER)
    target_compile_definitions(farcaster_client PRIVATE FARCASTER_HAS_SIGNER_ATTESTATION=1)
    target_link_libraries(farcaster_client PRIVATE farcaster::provider_compatibility_signer_attestation)
else()
    target_compile_definitions(farcaster_client PRIVATE FARCASTER_HAS_SIGNER_ATTESTATION=0)
endif()

target_compile_features(farcaster_client PRIVATE cxx_std_26)
set_property(TARGET farcaster_client PROPERTY CXX_SCAN_FOR_MODULES ON)
farcaster_enable_warnings(farcaster_client)

qt_add_qml_module(farcaster_client
    URI Farcaster.Client
    VERSION 1.0
    QML_FILES
        ${farcasterQmlFiles}
)

set(farcasterQmlLintOptions --bare)
if(Qt6_VERSION VERSION_GREATER_EQUAL 6.8)
    list(APPEND farcasterQmlLintOptions --max-warnings 0)
endif()

add_custom_target(farcaster_client_qmllint_strict
    COMMAND Qt6::qmllint
        ${farcasterQmlLintOptions}
        -I "${QT_QML_OUTPUT_DIRECTORY}"
        -I "${CMAKE_CURRENT_BINARY_DIR}"
        -I "${QT6_INSTALL_PREFIX}/${QT6_INSTALL_QML}"
        -M Farcaster.Client
    DEPENDS farcaster_client
    WORKING_DIRECTORY "${CMAKE_SOURCE_DIR}"
    VERBATIM
)

if(FARCASTER_BUILD_TESTS AND BUILD_TESTING)
    set(farcasterHeadlessPlatform "offscreen")
    if(APPLE)
        # Qt 6.11's macOS offscreen plugin emits a fatal generic-font alias
        # warning before project QML loads; the minimal plugin is warning-clean.
        set(farcasterHeadlessPlatform "minimal")
    endif()

    add_test(NAME ui.smoke COMMAND farcaster_client --smoke-test)
    set_tests_properties(ui.smoke PROPERTIES
        LABELS "ui;smoke"
        ENVIRONMENT
            "QT_QPA_PLATFORM=${farcasterHeadlessPlatform};QT_QUICK_CONTROLS_STYLE=Basic;QT_FATAL_WARNINGS=1"
        TIMEOUT 30
    )

    if(FARCASTER_ENABLE_HYPERSNAP_PROVIDER)
        find_package(Python3 REQUIRED COMPONENTS Interpreter)
        add_test(
            NAME ui.runtime_smoke
            COMMAND
                "${Python3_EXECUTABLE}"
                "${CMAKE_SOURCE_DIR}/tests/ui/runtime_smoke.py"
                "$<TARGET_FILE:farcaster_client>"
        )
        set_tests_properties(ui.runtime_smoke PROPERTIES
            LABELS "ui;smoke;integration"
            ENVIRONMENT
                "QT_QPA_PLATFORM=${farcasterHeadlessPlatform};QT_QUICK_CONTROLS_STYLE=Basic;QT_FATAL_WARNINGS=1"
            TIMEOUT 30
        )
    endif()
endif()
