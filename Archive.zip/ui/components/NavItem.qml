import QtQuick
import QtQuick.Controls

Button {
    id: control

    property bool selected: false

    implicitHeight: 48
    leftPadding: Theme.space4
    rightPadding: Theme.space4
    topPadding: 0
    bottomPadding: 0
    flat: true

    Accessible.name: text

    contentItem: Label {
        text: control.text
        color: control.enabled
               ? control.selected ? Theme.primary : Theme.ink
               : Theme.inkSubtle
        font.pixelSize: 15
        font.weight: control.selected ? Font.DemiBold : Font.Medium
        horizontalAlignment: Text.AlignLeft
        verticalAlignment: Text.AlignVCenter
        elide: Text.ElideRight
    }

    background: Rectangle {
        radius: Theme.radiusMedium
        color: control.selected
               ? Theme.primarySurface
               : control.hovered || control.down ? Theme.surfaceMuted : "transparent"
        border.width: control.activeFocus ? 1 : 0
        border.color: Theme.focus
    }
}
