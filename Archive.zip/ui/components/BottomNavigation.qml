import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Rectangle {
    id: root

    property string activeView: "feed"
    property string activeFeed: "following"
    property bool identityAvailable: false

    signal trendingRequested()
    signal followingRequested()
    signal profileRequested()
    signal identityRequested()

    implicitHeight: 62
    color: Theme.surface

    Rectangle {
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.top: parent.top
        height: 1
        color: Theme.border
    }

    RowLayout {
        anchors.fill: parent
        spacing: 0

        BottomNavButton {
            Layout.fillWidth: true
            text: qsTr("Home")
            selected: root.activeView === "feed" && root.activeFeed === "following"
            onClicked: {
                if (root.identityAvailable) {
                    root.followingRequested()
                } else {
                    root.identityRequested()
                }
            }
        }

        BottomNavButton {
            Layout.fillWidth: true
            text: qsTr("Explore")
            selected: root.activeView === "feed" && root.activeFeed === "trending"
            onClicked: root.trendingRequested()
        }

        BottomNavButton {
            Layout.fillWidth: true
            text: qsTr("Profile")
            selected: root.activeView === "profile"
            onClicked: {
                if (root.identityAvailable) {
                    root.profileRequested()
                } else {
                    root.identityRequested()
                }
            }
        }
    }
}
