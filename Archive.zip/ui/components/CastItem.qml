import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Rectangle {
    id: root

    property var modelData
    property bool interactionsAvailable: false
    property double accountFid: 0
    signal openRequested(string castId)
    signal replyRequested(var cast)
    signal reactionRequested(string kind, var cast, bool active)
    signal removeRequested(var cast)
    signal externalRequested(string url)

    implicitHeight: content.implicitHeight + Theme.space4 * 2
    color: hoverHandler.hovered ? Theme.surfaceHover : Theme.surface

    Behavior on color { ColorAnimation { duration: 100 } }

    ColumnLayout {
        id: content
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.top: parent.top
        anchors.margins: Theme.space4
        spacing: Theme.space3

        RowLayout {
            Layout.fillWidth: true
            spacing: Theme.space3

            Avatar {
                avatarSize: 44
                sourceUrl: root.modelData.avatarUrl || ""
                displayName: root.modelData.displayName || root.modelData.author || ""
            }

            ColumnLayout {
                Layout.fillWidth: true
                spacing: 1

                RowLayout {
                    Layout.fillWidth: true
                    spacing: Theme.space2

                    Label {
                        Layout.fillWidth: true
                        text: root.modelData.displayName || root.modelData.author || qsTr("Unknown")
                        color: Theme.ink
                        font.pixelSize: 14
                        font.weight: Font.DemiBold
                        elide: Text.ElideRight
                    }

                    Label {
                        text: root.modelData.time || ""
                        color: Theme.inkSubtle
                        font.pixelSize: 11
                    }
                }

                Label {
                    Layout.fillWidth: true
                    text: root.modelData.author ? "@" + root.modelData.author : ""
                    color: Theme.inkMuted
                    font.pixelSize: 12
                    elide: Text.ElideRight
                }
            }
        }

        Label {
            visible: root.modelData.writeState !== undefined && root.modelData.writeState !== ""
            Layout.fillWidth: true
            text: root.modelData.writeState === "confirmed"
                  ? (root.modelData.isReply ? qsTr("Reply published") : qsTr("Published"))
                  : root.modelData.writeState === "failed"
                    ? (root.modelData.isReply ? qsTr("Reply failed · saved locally") : qsTr("Publish failed · saved locally"))
                    : root.modelData.writeState === "retry"
                      ? qsTr("Queued for retry · saved locally")
                      : root.modelData.writeState === "blocked"
                        ? qsTr("Waiting for write authority · saved locally")
                        : (root.modelData.isReply ? qsTr("Replying · saved locally") : qsTr("Publishing · saved locally"))
            color: root.modelData.writeState === "confirmed" ? Theme.success
                   : root.modelData.writeState === "failed" ? Theme.warning
                   : Theme.primary
            font.pixelSize: 11
            font.weight: Font.DemiBold
            wrapMode: Text.Wrap
        }

        Label {
            visible: Boolean(root.modelData.isReply) || Boolean(root.modelData.parentUrl)
            Layout.fillWidth: true
            text: root.modelData.parentUrl
                  ? qsTr("Channel / parent context") + "  ·  " + root.modelData.parentUrl
                  : qsTr("Reply in a conversation")
            color: Theme.primary
            font.pixelSize: 11
            font.weight: Font.Medium
            elide: Text.ElideRight
        }

        Label {
            visible: root.modelData.text !== undefined
            Layout.fillWidth: true
            text: root.modelData.text || ""
            color: Theme.ink
            font.pixelSize: 15
            lineHeight: 1.35
            wrapMode: Text.Wrap
        }

        Repeater {
            model: root.modelData.embeds || []
            delegate: EmbedCard {
                required property var modelData
                embed: modelData
                onOpenRequested: url => root.externalRequested(url)
            }
        }

        EngagementBar {
            Layout.fillWidth: true
            replyCount: Number(root.modelData.replyCount || 0)
            recastCount: Number(root.modelData.recastCount || 0)
            likeCount: Number(root.modelData.likeCount || 0)
            replyInteractive: root.interactionsAvailable
                              && root.modelData.castId !== undefined
                              && String(root.modelData.castId).length > 0
            recastInteractive: replyInteractive
            likeInteractive: replyInteractive
            recastedByMe: Boolean(root.modelData.recastedByMe || false)
            likedByMe: Boolean(root.modelData.likedByMe || false)
            onReplyRequested: root.replyRequested(root.modelData)
            onRecastRequested: active => root.reactionRequested("recast", root.modelData, active)
            onLikeRequested: active => root.reactionRequested("like", root.modelData, active)
        }

        RowLayout {
            Layout.fillWidth: true

            Label {
                visible: root.modelData.castId !== undefined
                text: qsTr("View conversation") + "  →"
                color: Theme.primary
                font.pixelSize: 12
                font.weight: Font.DemiBold
            }

            Item { Layout.fillWidth: true }

            ToolButton {
                visible: root.interactionsAvailable
                         && Number(root.modelData.authorFid || 0) === Number(root.accountFid)
                         && Boolean(root.modelData.castId)
                text: qsTr("Delete")
                flat: true
                font.pixelSize: 11
                Accessible.name: qsTr("Delete this cast")
                onClicked: root.removeRequested(root.modelData)
            }

            Label {
                visible: Number(root.modelData.embedCount || 0) > 1
                text: qsTr("%1 embeds").arg(root.modelData.embedCount)
                color: Theme.inkSubtle
                font.pixelSize: 10
            }
        }
    }

    HoverHandler { id: hoverHandler }

    TapHandler {
        enabled: root.modelData.castId !== undefined
        onTapped: root.openRequested(root.modelData.castId)
    }

    Rectangle {
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        height: 1
        color: Theme.border
    }
}
