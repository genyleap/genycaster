import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Rectangle {
    id: root

    property string activeView: "feed"
    property string activeFeed: "following"
    property string identityName: ""
    property bool identityAvailable: false
    property string accountName: ""
    property bool isAuthenticated: false

    signal trendingRequested()
    signal followingRequested()
    signal profileRequested()
    signal followersRequested()
    signal followingListRequested()
    signal identityRequested()
    signal accountRequested()

    implicitWidth: Theme.navigationWidth
    color: Theme.surface

    Rectangle {
        anchors.top: parent.top
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        width: 1
        color: Theme.border
    }

    ColumnLayout {
        anchors.fill: parent
        anchors.margins: Theme.space5
        spacing: Theme.space2

        Label {
            text: qsTr("Genycaster")
            color: Theme.ink
            font.pixelSize: 22
            font.weight: Font.Bold
        }

        Label {
            text: qsTr("Your Farcaster, available locally")
            color: Theme.inkMuted
            font.pixelSize: 12
            wrapMode: Text.Wrap
            Layout.fillWidth: true
        }

        ActionButton {
            Layout.fillWidth: true
            implicitHeight: Theme.compactControlHeight
            prominent: !root.isAuthenticated
            text: root.isAuthenticated
                  ? (root.accountName.length > 0 ? root.accountName : qsTr("Account"))
                  : qsTr("Sign in to interact")
            Accessible.description: root.isAuthenticated
                                    ? qsTr("Open your signed-in Farcaster account session")
                                    : qsTr("Reading remains available without signing in")
            onClicked: root.accountRequested()
        }

        Item { Layout.preferredHeight: Theme.space2 }

        NavItem {
            objectName: "sidebarAction-following"
            Layout.fillWidth: true
            text: qsTr("Home")
            selected: root.activeView === "feed" && root.activeFeed === "following"
            onClicked: {
                if (root.identityAvailable) {
                    root.followingRequested()
                } else {
                    root.identityRequested()
                }
            }
        }

        NavItem {
            objectName: "sidebarAction-trending"
            Layout.fillWidth: true
            text: qsTr("Explore")
            selected: root.activeView === "feed" && root.activeFeed === "trending"
            onClicked: root.trendingRequested()
        }

        NavItem {
            objectName: "sidebarAction-profile"
            Layout.fillWidth: true
            text: qsTr("Profile")
            selected: root.activeView === "profile"
            onClicked: {
                if (root.identityAvailable) {
                    root.profileRequested()
                } else {
                    root.identityRequested()
                }
            }
        }

        NavItem {
            objectName: "sidebarAction-followers"
            Layout.fillWidth: true
            text: qsTr("Followers")
            selected: root.activeView === "followers"
            onClicked: {
                if (root.identityAvailable) {
                    root.followersRequested()
                } else {
                    root.identityRequested()
                }
            }
        }

        NavItem {
            objectName: "sidebarAction-following-list"
            Layout.fillWidth: true
            text: qsTr("Following list")
            selected: root.activeView === "following"
            onClicked: {
                if (root.identityAvailable) {
                    root.followingListRequested()
                } else {
                    root.identityRequested()
                }
            }
        }

        Item { Layout.fillHeight: true }

        Rectangle {
            Layout.fillWidth: true
            implicitHeight: identityColumn.implicitHeight + Theme.space4 * 2
            radius: Theme.radiusLarge
            color: Theme.surfaceMuted

            ColumnLayout {
                id: identityColumn
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.top: parent.top
                anchors.margins: Theme.space4
                spacing: Theme.space2

                Label {
                    text: qsTr("Viewing")
                    color: Theme.inkMuted
                    font.pixelSize: 11
                    font.weight: Font.DemiBold
                }

                Label {
                    Layout.fillWidth: true
                    text: root.identityName.length > 0 ? root.identityName : qsTr("No identity open")
                    color: Theme.ink
                    font.pixelSize: 14
                    font.weight: Font.DemiBold
                    wrapMode: Text.Wrap
                }

                Label {
                    Layout.fillWidth: true
                    text: qsTr("Browsing identity is separate from your signed-in account.")
                    color: Theme.inkMuted
                    font.pixelSize: 11
                    lineHeight: 1.25
                    wrapMode: Text.Wrap
                }

                ActionButton {
                    Layout.fillWidth: true
                    implicitHeight: Theme.compactControlHeight
                    text: root.identityAvailable ? qsTr("Switch viewed identity") : qsTr("Browse identity")
                    onClicked: root.identityRequested()
                }
            }
        }
    }
}
