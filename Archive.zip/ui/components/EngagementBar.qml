import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

RowLayout {
    id: root

    property int replyCount: 0
    property int recastCount: 0
    property int likeCount: 0
    property bool replyInteractive: false
    property bool recastInteractive: false
    property bool likeInteractive: false
    property bool recastedByMe: false
    property bool likedByMe: false

    signal replyRequested()
    signal recastRequested(bool active)
    signal likeRequested(bool active)

    spacing: Theme.space4

    function metric(symbol, count) {
        return symbol + "  " + Number(count).toLocaleString(Qt.locale(), "f", 0)
    }

    ToolButton {
        text: root.metric("↩", root.replyCount)
        enabled: root.replyInteractive
        flat: true
        padding: 0
        font.pixelSize: 12
        Accessible.name: root.replyInteractive
                         ? qsTr("Reply · %1 replies").arg(root.replyCount)
                         : qsTr("%1 replies").arg(root.replyCount)
        contentItem: Label {
            text: parent.text
            color: parent.enabled ? Theme.primary : Theme.inkMuted
            font.pixelSize: parent.font.pixelSize
        }
        onClicked: root.replyRequested()
    }

    ToolButton {
        text: root.metric(root.recastedByMe ? "⟳" : "↻", root.recastCount)
        enabled: root.recastInteractive
        flat: true
        padding: 0
        font.pixelSize: 12
        Accessible.name: root.recastedByMe
                         ? qsTr("Undo recast · %1 recasts").arg(root.recastCount)
                         : qsTr("Recast · %1 recasts").arg(root.recastCount)
        contentItem: Label {
            text: parent.text
            color: root.recastedByMe ? Theme.primary : Theme.inkMuted
            font.pixelSize: parent.font.pixelSize
        }
        onClicked: root.recastRequested(!root.recastedByMe)
    }

    ToolButton {
        text: root.metric(root.likedByMe ? "♥" : "♡", root.likeCount)
        enabled: root.likeInteractive
        flat: true
        padding: 0
        font.pixelSize: 12
        Accessible.name: root.likedByMe
                         ? qsTr("Unlike · %1 likes").arg(root.likeCount)
                         : qsTr("Like · %1 likes").arg(root.likeCount)
        contentItem: Label {
            text: parent.text
            color: root.likedByMe ? Theme.primary : Theme.inkMuted
            font.pixelSize: parent.font.pixelSize
        }
        onClicked: root.likeRequested(!root.likedByMe)
    }

    Item { Layout.fillWidth: true }
}
