import QtQuick
import QtQuick.Controls

Button {
    id: control

    property bool prominent: false
    property bool quiet: false

    implicitHeight: Theme.controlHeight
    leftPadding: quiet ? Theme.space2 : Theme.space4
    rightPadding: quiet ? Theme.space2 : Theme.space4
    topPadding: 0
    bottomPadding: 0

    Accessible.name: text

    contentItem: Label {
        text: control.text
        color: !control.enabled
               ? Theme.inkSubtle
               : control.prominent
                 ? Theme.surface
                 : Theme.ink
        font.pixelSize: 14
        font.weight: Font.DemiBold
        horizontalAlignment: Text.AlignHCenter
        verticalAlignment: Text.AlignVCenter
        elide: Text.ElideRight
    }

    background: Rectangle {
        radius: Theme.radiusMedium
        color: {
            if (!control.enabled) {
                return Theme.surfaceMuted
            }
            if (control.prominent) {
                return control.down ? Theme.primaryPressed : Theme.primary
            }
            if (control.quiet) {
                return control.hovered || control.down ? Theme.surfaceMuted : "transparent"
            }
            return control.hovered || control.down ? Theme.surfaceHover : Theme.surface
        }
        border.width: control.quiet ? 0 : 1
        border.color: control.activeFocus ? Theme.focus : control.prominent ? Theme.primary : Theme.border
    }
}
