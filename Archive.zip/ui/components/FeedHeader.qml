import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Item {
    id: root

    property string activeFeed: "following"
    property bool identityAvailable: false
    property bool compact: false
    property bool busy: false
    property bool feedStarted: false

    signal trendingRequested()
    signal followingRequested()
    signal identityRequested()
    signal channelRequested(string channelId)
    signal refreshRequested()

    implicitHeight: headerColumn.implicitHeight

    ColumnLayout {
        id: headerColumn
        anchors.left: parent.left
        anchors.right: parent.right
        spacing: Theme.space3

        RowLayout {
            Layout.fillWidth: true
            spacing: Theme.space3

            ColumnLayout {
                Layout.fillWidth: true
                spacing: Theme.space1

                Label {
                    text: root.activeFeed === "channel" ? qsTr("Channel")
                          : root.activeFeed === "trending" ? qsTr("Explore")
                          : qsTr("Home")
                    color: Theme.ink
                    font.pixelSize: root.compact ? 24 : 28
                    font.weight: Font.Bold
                }

                Label {
                    Layout.fillWidth: true
                    text: !root.feedStarted
                          ? qsTr("Open an identity for your Home feed, or browse Explore")
                          : root.activeFeed === "channel"
                            ? qsTr("Casts scoped to the channel you opened")
                            : root.activeFeed === "following"
                              ? qsTr("Recent casts from the people this identity follows")
                              : qsTr("A network-wide view from the selected live source")
                    color: Theme.inkMuted
                    font.pixelSize: 13
                    wrapMode: Text.Wrap
                }
            }

            ActionButton {
                visible: root.feedStarted
                text: root.busy ? qsTr("Refreshing…") : qsTr("Refresh")
                quiet: true
                enabled: !root.busy
                onClicked: root.refreshRequested()
            }
        }

        RowLayout {
            Layout.fillWidth: true
            spacing: Theme.space2

            ActionButton {
                text: qsTr("Home")
                enabled: !root.busy || root.activeFeed !== "following"
                prominent: root.feedStarted && root.activeFeed === "following"
                onClicked: {
                    if (root.identityAvailable) {
                        root.followingRequested()
                    } else {
                        root.identityRequested()
                    }
                }
            }

            ActionButton {
                text: qsTr("Explore")
                prominent: root.feedStarted && root.activeFeed === "trending"
                enabled: !root.busy || root.activeFeed !== "trending"
                onClicked: root.trendingRequested()
            }

            Item { Layout.fillWidth: true }
        }

        RowLayout {
            Layout.fillWidth: true
            spacing: Theme.space2

            TextField {
                id: channelInput
                Layout.fillWidth: true
                implicitHeight: Theme.controlHeight
                placeholderText: qsTr("Open a channel")
                Accessible.name: qsTr("Channel id")
                selectByMouse: true
                leftPadding: Theme.space3
                rightPadding: Theme.space3
                background: Rectangle {
                    radius: Theme.radiusMedium
                    color: Theme.surface
                    border.width: 1
                    border.color: channelInput.activeFocus ? Theme.focus : Theme.border
                }
                onAccepted: {
                    const value = text.trim()
                    if (value.length > 0) {
                        root.channelRequested(value)
                    }
                }
            }

            ActionButton {
                text: qsTr("Open")
                enabled: !root.busy && channelInput.text.trim().length > 0
                onClicked: root.channelRequested(channelInput.text.trim())
            }
        }
    }
}
