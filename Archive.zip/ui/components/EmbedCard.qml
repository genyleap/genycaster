import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Rectangle {
    id: root
    property var embed
    signal openRequested(string url)

    Layout.fillWidth: true
    implicitHeight: content.implicitHeight + Theme.space3 * 2
    radius: Theme.radiusMedium
    color: hover.hovered ? Theme.surfaceHover : Theme.surfaceMuted
    border.width: 1
    border.color: Theme.border

    ColumnLayout {
        id: content
        anchors.fill: parent
        anchors.margins: Theme.space3
        spacing: Theme.space1
        Label { text: root.embed.kind === "media" ? qsTr("Media") : qsTr("External link"); color: Theme.inkSubtle; font.pixelSize: 10; font.weight: Font.DemiBold }
        Label { Layout.fillWidth: true; text: root.embed.url || ""; color: Theme.ink; font.pixelSize: 12; elide: Text.ElideMiddle }
        Label { text: qsTr("Open safely in your default app  ↗"); color: Theme.primary; font.pixelSize: 11; font.weight: Font.DemiBold }
    }
    HoverHandler { id: hover }
    TapHandler { onTapped: root.openRequested(root.embed.url || "") }
    Accessible.role: Accessible.Link
    Accessible.name: (root.embed.kind === "media" ? qsTr("Media embed") : qsTr("External link")) + ": " + (root.embed.url || "")
}
