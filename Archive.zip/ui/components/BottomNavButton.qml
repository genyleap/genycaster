import QtQuick
import QtQuick.Controls

Button {
    id: control

    property bool selected: false

    implicitHeight: 58
    flat: true
    Accessible.name: text

    contentItem: Column {
        anchors.centerIn: parent
        spacing: Theme.space1

        Rectangle {
            anchors.horizontalCenter: parent.horizontalCenter
            width: control.selected ? 28 : 6
            height: 3
            radius: 2
            color: control.selected ? Theme.primary : "transparent"

            Behavior on width {
                NumberAnimation { duration: 140 }
            }
        }

        Label {
            anchors.horizontalCenter: parent.horizontalCenter
            text: control.text
            color: control.enabled
                   ? control.selected ? Theme.primary : Theme.inkMuted
                   : Theme.inkSubtle
            font.pixelSize: 12
            font.weight: control.selected ? Font.DemiBold : Font.Medium
        }
    }

    background: Rectangle {
        color: control.hovered || control.down ? Theme.surfaceMuted : "transparent"
    }
}
