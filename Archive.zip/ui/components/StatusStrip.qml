import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Rectangle {
    id: root

    property string statusText: ""
    property string errorText: ""
    property string diagnosticText: ""
    property bool diagnosticsEnabled: false
    property bool runtimeReady: false
    property bool offline: false
    property bool sourceUnavailable: false
    property bool networkKnown: false
    property bool stale: false
    property bool busy: false
    property bool readStarted: false
    property bool detailsExpanded: false

    signal retryRequested()

    readonly property bool hasReadError: root.errorText.length > 0
    readonly property bool setupFailure: !root.runtimeReady && root.hasReadError
    readonly property bool warningState: root.setupFailure || root.offline || root.hasReadError
    readonly property string stateLabel: root.setupFailure
                                         ? qsTr("Setup issue")
                                         : root.runtimeReady && !root.readStarted
                                           ? qsTr("Ready")
                                         : root.offline
                                           ? qsTr("Offline")
                                           : root.hasReadError
                                           ? (root.sourceUnavailable ? qsTr("Source issue") : qsTr("Data issue"))
                                           : root.busy
                                             ? qsTr("Syncing")
                                             : root.stale
                                               ? qsTr("Saved")
                                               : qsTr("Live")
    readonly property color stateColor: root.warningState
                                         ? Theme.warning
                                         : root.busy || root.stale
                                           ? Theme.primary
                                           : Theme.success
    readonly property color stateSurface: root.warningState
                                           ? Theme.warningSurface
                                           : root.busy || root.stale
                                             ? Theme.primarySurface
                                             : Theme.successSurface
    readonly property string primaryMessage: root.setupFailure
                                              ? root.errorText
                                              : root.offline
                                                ? qsTr("No network connection · showing saved data when available")
                                                : root.errorText.length > 0
                                                ? root.errorText
                                                : root.statusText
    readonly property string networkState: !root.networkKnown
                                            ? qsTr("Unknown")
                                            : root.offline
                                              ? qsTr("Disconnected")
                                              : qsTr("Reachable")

    color: root.warningState ? Theme.warningSurface : Theme.surface
    implicitHeight: content.implicitHeight + Theme.space3 * 2

    ColumnLayout {
        id: content
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.top: parent.top
        anchors.margins: Theme.space3
        spacing: Theme.space2

        RowLayout {
            Layout.fillWidth: true
            spacing: Theme.space3

            Rectangle {
                implicitWidth: stateLabel.implicitWidth + Theme.space3 * 2
                implicitHeight: 28
                radius: Theme.radiusMedium
                color: root.stateSurface
                border.width: 1
                border.color: root.stateColor

                Label {
                    id: stateLabel
                    anchors.centerIn: parent
                    text: root.stateLabel
                    color: root.stateColor
                    font.pixelSize: 11
                    font.weight: Font.DemiBold
                }
            }

            ColumnLayout {
                Layout.fillWidth: true
                spacing: 1

                Label {
                    Layout.fillWidth: true
                    text: root.primaryMessage
                    color: Theme.ink
                    font.pixelSize: 12
                    font.weight: Font.Medium
                    elide: Text.ElideRight
                }

                Label {
                    visible: root.errorText.length > 0
                             && root.statusText.length > 0
                             && root.statusText !== root.errorText
                    Layout.fillWidth: true
                    text: root.statusText
                    color: Theme.inkMuted
                    font.pixelSize: 10
                    elide: Text.ElideRight
                }
            }

            BusyIndicator {
                visible: root.busy
                running: visible
                Layout.preferredWidth: 22
                Layout.preferredHeight: 22
            }

            ActionButton {
                visible: root.diagnosticsEnabled && root.diagnosticText.length > 0
                implicitHeight: Theme.compactControlHeight
                quiet: true
                text: root.detailsExpanded ? qsTr("Hide details") : qsTr("Details")
                onClicked: root.detailsExpanded = !root.detailsExpanded
            }

            ActionButton {
                visible: root.runtimeReady && (root.hasReadError || root.sourceUnavailable)
                implicitHeight: Theme.compactControlHeight
                quiet: true
                text: qsTr("Retry")
                enabled: !root.busy
                onClicked: root.retryRequested()
            }
        }

        Rectangle {
            visible: root.diagnosticsEnabled && root.detailsExpanded && root.diagnosticText.length > 0
            Layout.fillWidth: true
            implicitHeight: diagnosticColumn.implicitHeight + Theme.space3 * 2
            radius: Theme.radiusMedium
            color: Theme.surface
            border.width: 1
            border.color: Theme.border

            ColumnLayout {
                id: diagnosticColumn
                anchors.fill: parent
                anchors.margins: Theme.space3
                spacing: Theme.space2

                RowLayout {
                    Layout.fillWidth: true
                    spacing: Theme.space4

                    Label {
                        text: qsTr("Network: %1").arg(root.networkState)
                        color: Theme.inkMuted
                        font.pixelSize: 11
                        font.weight: Font.DemiBold
                    }

                    Label {
                        text: !root.runtimeReady ? qsTr("Read runtime: unavailable")
                                                 : root.sourceUnavailable ? qsTr("Live source: unavailable")
                                                                          : qsTr("Live source: responded")
                        color: Theme.inkMuted
                        font.pixelSize: 11
                    }
                }

                Label {
                    Layout.fillWidth: true
                    text: root.diagnosticText
                    color: Theme.ink
                    font.pixelSize: 11
                    wrapMode: Text.WrapAnywhere
                    textFormat: Text.PlainText
                }
            }
        }
    }
}
