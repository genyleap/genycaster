import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Rectangle {
    id: root

    property string identityName: ""
    property string accountName: ""
    property bool isAuthenticated: false
    property bool writeReady: false
    property bool writeBusy: false
    property bool compact: false
    property bool showBrand: true

    signal identityRequested()
    signal accountRequested()
    signal publishRequested()

    implicitHeight: compact ? 58 : 64
    color: Theme.surface

    RowLayout {
        anchors.fill: parent
        anchors.leftMargin: root.compact ? Theme.mobileGutter : Theme.contentGutter
        anchors.rightMargin: root.compact ? Theme.mobileGutter : Theme.contentGutter
        spacing: Theme.space2

        Label {
            visible: root.showBrand
            text: qsTr("Genycaster")
            color: Theme.ink
            font.pixelSize: root.compact ? 19 : 21
            font.weight: Font.Bold
            font.letterSpacing: -0.2
        }

        Item { Layout.fillWidth: true }

        ActionButton {
            implicitHeight: Theme.compactControlHeight
            quiet: true
            text: root.compact
                  ? (root.identityName.length > 0 ? root.identityName : qsTr("Browse"))
                  : (root.identityName.length > 0 ? root.identityName : qsTr("Browse identity"))
            Accessible.description: qsTr("Change the Farcaster identity being viewed. This does not sign you in.")
            onClicked: root.identityRequested()
        }


        ActionButton {
            implicitHeight: Theme.compactControlHeight
            prominent: root.writeReady
            text: root.writeBusy ? qsTr("Publishing…") : qsTr("New cast")
            enabled: !root.writeBusy
            Accessible.description: root.writeReady
                                    ? qsTr("Compose and publish a Farcaster cast")
                                    : qsTr("Sign in and enable interactions before publishing")
            onClicked: root.publishRequested()
        }

        ActionButton {
            implicitHeight: Theme.compactControlHeight
            prominent: !root.isAuthenticated
            text: root.isAuthenticated
                  ? (root.accountName.length > 0 ? root.accountName : qsTr("Account"))
                  : qsTr("Sign in")
            Accessible.description: root.isAuthenticated
                                    ? qsTr("Open your signed-in account session")
                                    : qsTr("Sign in to interact on Farcaster")
            onClicked: root.accountRequested()
        }
    }

    Rectangle {
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        height: 1
        color: Theme.border
    }
}
