import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Flickable {
    id: root

    property string activeView: ""
    property var detail
    property bool compact: false
    property bool busy: false
    property bool interactionsAvailable: false
    property double accountFid: 0

    signal backRequested()
    signal followersRequested()
    signal followingRequested()
    signal refreshRequested()
    signal replyRequested(var cast)
    signal reactionRequested(string kind, var cast, bool active)
    signal followingMutationRequested(double targetFid, bool following)
    signal removeCastRequested(var cast)
    signal externalRequested(string url)

    clip: true
    contentWidth: width
    contentHeight: detailColumn.implicitHeight + Theme.space6 * 2
    boundsBehavior: Flickable.StopAtBounds

    ScrollBar.vertical: ScrollBar { }

    ColumnLayout {
        id: detailColumn
        width: Math.min(root.width - (root.compact ? Theme.mobileGutter * 2 : Theme.contentGutter * 2), Theme.readingWidth)
        x: Math.max(root.compact ? Theme.mobileGutter : Theme.contentGutter, (root.width - width) / 2)
        y: Theme.space5
        spacing: Theme.space4

        RowLayout {
            Layout.fillWidth: true

            ActionButton {
                implicitHeight: Theme.compactControlHeight
                quiet: true
                text: qsTr("← Back to feed")
                onClicked: root.backRequested()
            }

            Item { Layout.fillWidth: true }

            ActionButton {
                implicitHeight: Theme.compactControlHeight
                quiet: true
                text: root.busy ? qsTr("Refreshing…") : qsTr("Refresh")
                enabled: !root.busy
                onClicked: root.refreshRequested()
            }
        }

        Rectangle {
            Layout.fillWidth: true
            implicitHeight: cardColumn.implicitHeight + Theme.space5 * 2
            radius: Theme.radiusLarge
            color: Theme.surface
            border.width: 1
            border.color: Theme.border

            ColumnLayout {
                id: cardColumn
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.top: parent.top
                anchors.margins: Theme.space5
                spacing: Theme.space3

                RowLayout {
                    Layout.fillWidth: true
                    spacing: Theme.space3

                    Avatar {
                        avatarSize: root.activeView === "profile" ? 72 : 48
                        sourceUrl: root.detail.avatarUrl || ""
                        displayName: root.detail.displayName || root.detail.author || ""
                    }

                    ColumnLayout {
                        Layout.fillWidth: true
                        spacing: 2

                        Label {
                            Layout.fillWidth: true
                            text: root.detail.displayName || root.detail.author || qsTr("Canonical detail")
                            color: Theme.ink
                            font.pixelSize: root.activeView === "profile" ? 23 : 17
                            font.weight: Font.Bold
                            wrapMode: Text.Wrap
                        }

                        Label {
                            visible: text.length > 0
                            Layout.fillWidth: true
                            text: root.detail.username ? "@" + root.detail.username : ""
                            color: Theme.inkMuted
                            font.pixelSize: 13
                            elide: Text.ElideRight
                        }

                        Label {
                            visible: root.activeView === "cast" && Boolean(root.detail.time)
                            text: root.detail.time || ""
                            color: Theme.inkSubtle
                            font.pixelSize: 11
                        }

                        Label {
                            visible: root.activeView === "profile" && Number(root.detail.fid || 0) > 0
                            text: qsTr("FID %1").arg(root.detail.fid)
                            color: Theme.inkSubtle
                            font.pixelSize: 11
                        }
                    }
                }

                Label {
                    visible: root.activeView === "cast" && Boolean(root.detail.parentUrl)
                    Layout.fillWidth: true
                    text: qsTr("Parent context") + "  ·  " + root.detail.parentUrl
                    color: Theme.primary
                    font.pixelSize: 11
                    elide: Text.ElideRight
                }

                Label {
                    Layout.fillWidth: true
                    text: root.detail.text || root.detail.bio || qsTr("No detail cached yet.")
                    color: Theme.ink
                    font.pixelSize: root.activeView === "cast" ? 18 : 15
                    lineHeight: 1.4
                    wrapMode: Text.Wrap
                }

                Repeater {
                    model: root.activeView === "cast" ? (root.detail.embeds || []) : []
                    delegate: EmbedCard {
                        required property var modelData
                        embed: modelData
                        onOpenRequested: url => root.externalRequested(url)
                    }
                }

                EngagementBar {
                    visible: root.activeView === "cast"
                    Layout.fillWidth: true
                    replyCount: Number(root.detail.replyCount || 0)
                    recastCount: Number(root.detail.recastCount || 0)
                    likeCount: Number(root.detail.likeCount || 0)
                    replyInteractive: root.interactionsAvailable && Boolean(root.detail.castId)
                    recastInteractive: replyInteractive
                    likeInteractive: replyInteractive
                    recastedByMe: Boolean(root.detail.recastedByMe || false)
                    likedByMe: Boolean(root.detail.likedByMe || false)
                    onReplyRequested: root.replyRequested(root.detail)
                    onRecastRequested: active => root.reactionRequested("recast", root.detail, active)
                    onLikeRequested: active => root.reactionRequested("like", root.detail, active)
                }

                RowLayout {
                    visible: root.activeView === "cast"
                             && root.interactionsAvailable
                             && Number(root.detail.authorFid || 0) === Number(root.accountFid)
                             && Boolean(root.detail.castId)
                    Layout.fillWidth: true

                    Item { Layout.fillWidth: true }

                    ActionButton {
                        quiet: true
                        text: qsTr("Delete cast")
                        onClicked: root.removeCastRequested(root.detail)
                    }
                }

                RowLayout {
                    visible: root.activeView === "profile"
                    spacing: Theme.space2

                    ActionButton {
                        visible: root.interactionsAvailable
                                 && Number(root.detail.fid || 0) > 0
                                 && Number(root.detail.fid || 0) !== Number(root.accountFid)
                        text: Boolean(root.detail.followingByMe) ? qsTr("Unfollow") : qsTr("Follow")
                        prominent: !Boolean(root.detail.followingByMe)
                        onClicked: root.followingMutationRequested(
                            Number(root.detail.fid), !Boolean(root.detail.followingByMe))
                    }

                    ActionButton {
                        text: qsTr("Followers")
                        onClicked: root.followersRequested()
                    }

                    ActionButton {
                        text: qsTr("Following")
                        onClicked: root.followingRequested()
                    }

                    Item { Layout.fillWidth: true }
                }
            }
        }
    }
}
