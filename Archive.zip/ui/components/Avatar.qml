import QtQuick
import QtQuick.Controls

Item {
    id: root

    property string sourceUrl: ""
    property string displayName: ""
    property int avatarSize: 44

    readonly property string initial: displayName.length > 0
                                      ? displayName.substring(0, 1).toUpperCase()
                                      : "?"
    readonly property bool hasLocalImageSource: sourceUrl.startsWith("image://")
                                                 || sourceUrl.startsWith("qrc:/")

    implicitWidth: avatarSize
    implicitHeight: avatarSize

    Rectangle {
        anchors.fill: parent
        radius: width / 2
        color: Theme.primarySurface
        border.width: 1
        border.color: Theme.border
        clip: true

        Label {
            anchors.centerIn: parent
            text: root.initial
            color: Theme.primary
            font.pixelSize: Math.max(13, Math.round(root.avatarSize * 0.34))
            font.weight: Font.Bold
        }

        Image {
            id: image
            anchors.fill: parent
            // Provider media URLs stay presentation data until the C++ media
            // cache owns fetching. QML must never start remote network I/O.
            source: root.hasLocalImageSource ? root.sourceUrl : ""
            visible: status === Image.Ready
            fillMode: Image.PreserveAspectCrop
            asynchronous: true
            cache: true
        }
    }
}
