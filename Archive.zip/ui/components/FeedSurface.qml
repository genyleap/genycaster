import QtQuick
import QtQuick.Controls

Item {
    id: root

    property var rows
    property bool runtimeReady: false
    property bool socialMode: false
    property bool busy: false
    property bool canLoadMore: false
    property bool offline: false
    property bool sourceUnavailable: false
    property string errorText: ""
    property string activeFeed: "following"
    property bool identityAvailable: false
    property bool feedStarted: false
    property bool interactionsAvailable: false
    property double accountFid: 0

    signal castRequested(string castId)
    signal replyRequested(var cast)
    signal reactionRequested(string kind, var cast, bool active)
    signal removeCastRequested(var cast)
    signal loadMoreRequested()
    signal refreshRequested()
    signal externalRequested(string url)
    signal retryRequested()
    signal identityRequested()
    signal followingRequested()
    signal trendingRequested()

    ListView {
        id: readList
        objectName: "readList"
        anchors.fill: parent
        clip: true
        model: root.rows
        spacing: 0
        boundsBehavior: Flickable.DragOverBounds

        onMovementEnded: {
            if (contentY < -72 && !root.busy) root.refreshRequested()
        }
        onContentYChanged: {
            if (!moving || root.busy || !root.canLoadMore || count === 0) return
            if (contentY + height >= contentHeight - 320) root.loadMoreRequested()
        }
        reuseItems: true

        delegate: Item {
            id: rowDelegate
            required property var modelData
            width: readList.width
            height: root.socialMode ? profileRow.implicitHeight : castRow.implicitHeight

            CastItem {
                id: castRow
                anchors.left: parent.left
                anchors.right: parent.right
                visible: !root.socialMode
                modelData: rowDelegate.modelData
                interactionsAvailable: root.interactionsAvailable
                accountFid: root.accountFid
                onOpenRequested: castId => root.castRequested(castId)
                onReplyRequested: cast => root.replyRequested(cast)
                onReactionRequested: (kind, cast, active) => root.reactionRequested(kind, cast, active)
                onRemoveRequested: cast => root.removeCastRequested(cast)
                onExternalRequested: url => root.externalRequested(url)
            }

            ProfileListItem {
                id: profileRow
                anchors.left: parent.left
                anchors.right: parent.right
                visible: root.socialMode
                modelData: rowDelegate.modelData
            }
        }

        footer: Item {
            width: readList.width
            height: root.canLoadMore ? 56 : 24
            BusyIndicator { anchors.centerIn: parent; visible: root.busy && root.rows.length > 0; running: visible; Accessible.name: qsTr("Loading more casts") }
        }
    }

    Label {
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.top: parent.top
        anchors.topMargin: Theme.space2
        z: 2
        visible: readList.contentY < -16 && root.rows.length > 0
        text: readList.contentY < -72 ? qsTr("Release to refresh") : qsTr("Pull to refresh")
        color: Theme.inkMuted
        font.pixelSize: 11
    }

    Column {
        anchors.fill: parent
        visible: root.rows.length === 0 && root.busy && root.runtimeReady
        Repeater { model: 4; delegate: CastSkeleton { width: root.width } }
    }

    EmptyState {
        anchors.fill: parent
        visible: root.rows.length === 0
        runtimeReady: root.runtimeReady
        busy: root.busy
        offline: root.offline
        sourceUnavailable: root.sourceUnavailable
        errorText: root.errorText
        activeFeed: root.activeFeed
        identityAvailable: root.identityAvailable
        feedStarted: root.feedStarted
        onRetryRequested: root.retryRequested()
        onIdentityRequested: root.identityRequested()
        onFollowingRequested: root.followingRequested()
        onTrendingRequested: root.trendingRequested()
    }
}
