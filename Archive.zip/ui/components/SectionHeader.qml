import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Item {
    id: root

    property string title: ""
    property string subtitle: ""
    property bool compact: false

    signal backRequested()

    implicitHeight: column.implicitHeight

    ColumnLayout {
        id: column
        anchors.left: parent.left
        anchors.right: parent.right
        spacing: Theme.space3

        ActionButton {
            implicitHeight: Theme.compactControlHeight
            quiet: true
            text: qsTr("← Back to feed")
            onClicked: root.backRequested()
        }

        Label {
            text: root.title
            color: Theme.ink
            font.pixelSize: root.compact ? 24 : 28
            font.weight: Font.Bold
        }

        Label {
            visible: root.subtitle.length > 0
            Layout.fillWidth: true
            text: root.subtitle
            color: Theme.inkMuted
            font.pixelSize: 13
            wrapMode: Text.Wrap
        }
    }
}
