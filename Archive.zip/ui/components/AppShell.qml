import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Item {
    id: root
    objectName: "appShell"

    readonly property bool isReady: presentationBridge.architectureState.length > 0
    readonly property bool wide: width >= 1000
    readonly property bool compact: width < 600
    readonly property bool identityAvailable: presentationBridge.identityFid > 0
    readonly property bool listViewActive: presentationBridge.activeView === "feed"
                                           || presentationBridge.activeView === "followers"
                                           || presentationBridge.activeView === "following"
    property var composerParent: null

    function openIdentityPicker() {
        identityPopup.open()
        identityInput.forceActiveFocus()
    }

    function openAccountPopup() {
        accountPopup.open()
    }

    function openComposer(parentCast) {
        if (!presentationBridge.isAuthenticated || !presentationBridge.writeReady) {
            accountPopup.open()
            return
        }
        presentationBridge.beginComposer()
        if (parentCast !== undefined && parentCast !== null) {
            if (!parentCast.castId || !presentationBridge.prepareReply(String(parentCast.castId)))
                return
            composerParent = {
                "castId": String(parentCast.castId),
                "author": String(parentCast.author || parentCast.username || ""),
                "displayName": String(parentCast.displayName || parentCast.author || ""),
                "text": String(parentCast.text || "")
            }
        } else {
            composerParent = null
        }
        composerInput.text = ""
        composerPopup.open()
        composerInput.forceActiveFocus()
    }

    Rectangle {
        anchors.fill: parent
        color: Theme.background
    }

    RowLayout {
        anchors.fill: parent
        spacing: 0

        SideNavigation {
            visible: root.wide
            Layout.fillHeight: true
            Layout.preferredWidth: Theme.navigationWidth
            activeView: presentationBridge.activeView
            activeFeed: presentationBridge.activeFeed
            identityName: presentationBridge.identityName
            identityAvailable: root.identityAvailable
            accountName: presentationBridge.accountName
            isAuthenticated: presentationBridge.isAuthenticated
            onTrendingRequested: presentationBridge.selectFeed("trending")
            onFollowingRequested: presentationBridge.selectFeed("following")
            onProfileRequested: presentationBridge.openProfile()
            onFollowersRequested: presentationBridge.openFollowers()
            onFollowingListRequested: presentationBridge.openFollowing()
            onIdentityRequested: root.openIdentityPicker()
            onAccountRequested: root.openAccountPopup()
        }

        Item {
            Layout.fillWidth: true
            Layout.fillHeight: true

            ColumnLayout {
                anchors.fill: parent
                spacing: 0

                AppHeader {
                    Layout.fillWidth: true
                    compact: root.compact
                    showBrand: !root.wide
                    identityName: presentationBridge.identityName
                    accountName: presentationBridge.accountName
                    isAuthenticated: presentationBridge.isAuthenticated
                    writeReady: presentationBridge.writeReady
                    writeBusy: presentationBridge.writeBusy
                    onIdentityRequested: root.openIdentityPicker()
                    onAccountRequested: root.openAccountPopup()
                    onPublishRequested: root.openComposer(null)
                }

                StatusStrip {
                    Layout.fillWidth: true
                    statusText: presentationBridge.statusText
                    errorText: presentationBridge.errorText
                    diagnosticText: presentationBridge.diagnosticText
                    diagnosticsEnabled: presentationBridge.diagnosticsEnabled
                    runtimeReady: presentationBridge.runtimeReady
                    offline: presentationBridge.isOffline
                    sourceUnavailable: presentationBridge.sourceUnavailable
                    networkKnown: presentationBridge.networkReachabilityKnown
                    stale: presentationBridge.isStale
                    busy: presentationBridge.isBusy
                    readStarted: presentationBridge.hasReadActivity
                    onRetryRequested: presentationBridge.retry()
                }

                Item {
                    Layout.fillWidth: true
                    Layout.fillHeight: true

                    ColumnLayout {
                        anchors.fill: parent
                        anchors.leftMargin: root.compact ? 0 : Theme.contentGutter
                        anchors.rightMargin: root.compact ? 0 : Theme.contentGutter
                        anchors.topMargin: Theme.space4
                        spacing: Theme.space4

                        FeedHeader {
                            visible: presentationBridge.activeView === "feed"
                            Layout.fillWidth: true
                            Layout.maximumWidth: Theme.readingWidth
                            Layout.alignment: Qt.AlignHCenter
                            Layout.leftMargin: root.compact ? Theme.mobileGutter : 0
                            Layout.rightMargin: root.compact ? Theme.mobileGutter : 0
                            activeFeed: presentationBridge.activeFeed
                            identityAvailable: root.identityAvailable
                            compact: root.compact
                            busy: presentationBridge.isBusy
                            feedStarted: presentationBridge.feedStarted
                            onTrendingRequested: presentationBridge.selectFeed("trending")
                            onFollowingRequested: presentationBridge.selectFeed("following")
                            onIdentityRequested: root.openIdentityPicker()
                            onChannelRequested: channelId => presentationBridge.openChannel(channelId)
                            onRefreshRequested: presentationBridge.retry()
                        }

                        SectionHeader {
                            visible: presentationBridge.activeView === "followers"
                                     || presentationBridge.activeView === "following"
                            Layout.fillWidth: true
                            Layout.maximumWidth: Theme.readingWidth
                            Layout.alignment: Qt.AlignHCenter
                            Layout.leftMargin: root.compact ? Theme.mobileGutter : 0
                            Layout.rightMargin: root.compact ? Theme.mobileGutter : 0
                            compact: root.compact
                            title: presentationBridge.activeView === "followers"
                                   ? qsTr("Followers") : qsTr("Following")
                            subtitle: qsTr("Saved locally first, then refreshed from the network")
                            onBackRequested: presentationBridge.showFeed()
                        }

                        FeedSurface {
                            visible: root.listViewActive
                            Layout.fillWidth: true
                            Layout.fillHeight: true
                            Layout.maximumWidth: Theme.readingWidth
                            Layout.alignment: Qt.AlignHCenter
                            rows: presentationBridge.rows
                            runtimeReady: presentationBridge.runtimeReady
                            socialMode: presentationBridge.activeView !== "feed"
                            busy: presentationBridge.isBusy
                            canLoadMore: presentationBridge.canLoadMore
                            offline: presentationBridge.isOffline
                            sourceUnavailable: presentationBridge.sourceUnavailable
                            errorText: presentationBridge.errorText
                            activeFeed: presentationBridge.activeFeed
                            identityAvailable: root.identityAvailable
                            feedStarted: presentationBridge.feedStarted
                            interactionsAvailable: presentationBridge.isAuthenticated
                                                   && presentationBridge.writeReady
                                                   && !presentationBridge.writeBusy
                            accountFid: presentationBridge.accountFid
                            onCastRequested: castId => presentationBridge.openCast(castId)
                            onReplyRequested: cast => root.openComposer(cast)
                            onReactionRequested: (kind, cast, active) =>
                                presentationBridge.setReaction(
                                    kind, Number(cast.authorFid || 0), String(cast.castId || ""), active)
                            onRemoveCastRequested: cast =>
                                presentationBridge.removeCast(
                                    Number(cast.authorFid || 0), String(cast.castId || ""))
                            onLoadMoreRequested: presentationBridge.loadMore()
                            onRefreshRequested: presentationBridge.retry()
                            onExternalRequested: url => presentationBridge.openExternalUrl(url)
                            onRetryRequested: presentationBridge.retry()
                            onIdentityRequested: root.openIdentityPicker()
                            onFollowingRequested: presentationBridge.selectFeed("following")
                            onTrendingRequested: presentationBridge.selectFeed("trending")
                        }

                        DetailSurface {
                            visible: presentationBridge.activeView === "profile"
                                     || presentationBridge.activeView === "cast"
                            Layout.fillWidth: true
                            Layout.fillHeight: true
                            activeView: presentationBridge.activeView
                            detail: presentationBridge.detail
                            compact: root.compact
                            busy: presentationBridge.isBusy
                            interactionsAvailable: presentationBridge.isAuthenticated
                                                   && presentationBridge.writeReady
                                                   && !presentationBridge.writeBusy
                            accountFid: presentationBridge.accountFid
                            onBackRequested: presentationBridge.showFeed()
                            onFollowersRequested: presentationBridge.openFollowers()
                            onFollowingRequested: presentationBridge.openFollowing()
                            onRefreshRequested: presentationBridge.retry()
                            onReplyRequested: cast => root.openComposer(cast)
                            onReactionRequested: (kind, cast, active) =>
                                presentationBridge.setReaction(
                                    kind, Number(cast.authorFid || 0), String(cast.castId || ""), active)
                            onFollowingMutationRequested: (targetFid, following) =>
                                presentationBridge.setFollowing(targetFid, following)
                            onRemoveCastRequested: cast =>
                                presentationBridge.removeCast(
                                    Number(cast.authorFid || 0), String(cast.castId || ""))
                            onExternalRequested: url => presentationBridge.openExternalUrl(url)
                        }
                    }
                }

                BottomNavigation {
                    visible: !root.wide
                    Layout.fillWidth: true
                    activeView: presentationBridge.activeView
                    activeFeed: presentationBridge.activeFeed
                    identityAvailable: root.identityAvailable
                    onTrendingRequested: presentationBridge.selectFeed("trending")
                    onFollowingRequested: presentationBridge.selectFeed("following")
                    onProfileRequested: presentationBridge.openProfile()
                    onIdentityRequested: root.openIdentityPicker()
                }
            }
        }
    }

    Popup {
        id: identityPopup
        parent: Overlay.overlay
        width: Math.min(420, parent.width - Theme.mobileGutter * 2)
        x: Math.round((parent.width - width) / 2)
        y: Math.max(Theme.space4, Math.round((parent.height - height) / 2))
        modal: true
        focus: true
        padding: Theme.space5
        closePolicy: Popup.CloseOnEscape | Popup.CloseOnPressOutside

        Overlay.modal: Rectangle { color: Theme.overlay }

        background: Rectangle {
            radius: Theme.radiusXLarge
            color: Theme.surface
            border.width: 1
            border.color: Theme.border
        }

        contentItem: ColumnLayout {
            spacing: Theme.space3

            Label {
                Layout.fillWidth: true
                text: qsTr("Browse a Farcaster identity")
                color: Theme.ink
                font.pixelSize: 21
                font.weight: Font.Bold
                wrapMode: Text.Wrap
            }

            Label {
                Layout.fillWidth: true
                text: qsTr("Use a username to load public data and personalize Following. This changes what you are viewing; it does not sign you in.")
                color: Theme.inkMuted
                font.pixelSize: 13
                lineHeight: 1.35
                wrapMode: Text.Wrap
            }

            TextField {
                id: identityInput
                Layout.fillWidth: true
                implicitHeight: Theme.controlHeight
                placeholderText: qsTr("username")
                Accessible.name: qsTr("Farcaster username")
                selectByMouse: true
                leftPadding: Theme.space3
                rightPadding: Theme.space3
                background: Rectangle {
                    radius: Theme.radiusMedium
                    color: Theme.surface
                    border.width: 1
                    border.color: identityInput.activeFocus ? Theme.focus : Theme.border
                }
                onAccepted: {
                    const value = text.trim()
                    if (value.length > 0) {
                        presentationBridge.openIdentity(value)
                    }
                }
            }

            Label {
                visible: identityPopup.opened && presentationBridge.errorText.length > 0
                Layout.fillWidth: true
                text: presentationBridge.errorText
                color: Theme.warning
                font.pixelSize: 12
                wrapMode: Text.Wrap
            }

            RowLayout {
                Layout.fillWidth: true
                spacing: Theme.space2

                Item { Layout.fillWidth: true }

                ActionButton {
                    text: qsTr("Cancel")
                    quiet: true
                    onClicked: identityPopup.close()
                }

                ActionButton {
                    text: qsTr("Browse")
                    prominent: true
                    enabled: presentationBridge.runtimeReady
                             && !presentationBridge.isBusy
                             && identityInput.text.trim().length > 0
                    onClicked: presentationBridge.openIdentity(identityInput.text.trim())
                }
            }
        }
    }

    Popup {
        id: composerPopup
        anchors.centerIn: parent
        width: Math.min(root.width - Theme.mobileGutter * 2, 560)
        modal: true
        focus: true
        padding: Theme.space5
        closePolicy: presentationBridge.writeBusy
                     ? Popup.NoAutoClose
                     : Popup.CloseOnEscape | Popup.CloseOnPressOutside
        onClosed: {
            if (!presentationBridge.writeBusy) {
                composerInput.clear()
                presentationBridge.clearReplyTarget()
                root.composerParent = null
            }
        }

        background: Rectangle {
            color: Theme.surface
            radius: Theme.radiusLarge
            border.color: Theme.border
        }

        ColumnLayout {
            width: parent.width
            spacing: Theme.space3

            Label {
                Layout.fillWidth: true
                text: root.composerParent ? qsTr("Reply") : qsTr("New cast")
                color: Theme.ink
                font.pixelSize: 20
                font.weight: Font.Bold
            }

            Label {
                Layout.fillWidth: true
                text: root.composerParent
                      ? qsTr("Replying with your verified Farcaster signer. The reply is saved locally before network submission and can recover after restart.")
                      : qsTr("Published with your verified Farcaster signer. The cast is saved locally before network submission and can recover after restart.")
                color: Theme.inkMuted
                font.pixelSize: 12
                lineHeight: 1.3
                wrapMode: Text.Wrap
            }

            Rectangle {
                visible: root.composerParent !== null
                Layout.fillWidth: true
                implicitHeight: parentContext.implicitHeight + Theme.space3 * 2
                radius: Theme.radiusMedium
                color: Theme.surfaceHover
                border.width: 1
                border.color: Theme.border

                ColumnLayout {
                    id: parentContext
                    anchors.left: parent.left
                    anchors.right: parent.right
                    anchors.top: parent.top
                    anchors.margins: Theme.space3
                    spacing: Theme.space1

                    Label {
                        Layout.fillWidth: true
                        text: root.composerParent
                              ? qsTr("Replying to %1").arg(root.composerParent.displayName || root.composerParent.author || qsTr("this cast"))
                              : ""
                        color: Theme.primary
                        font.pixelSize: 12
                        font.weight: Font.DemiBold
                        elide: Text.ElideRight
                    }

                    Label {
                        Layout.fillWidth: true
                        text: root.composerParent ? root.composerParent.text : ""
                        color: Theme.inkMuted
                        font.pixelSize: 12
                        maximumLineCount: 3
                        elide: Text.ElideRight
                        wrapMode: Text.Wrap
                    }
                }
            }

            TextArea {
                id: composerInput
                objectName: "composerInput"
                Layout.fillWidth: true
                Layout.preferredHeight: 150
                placeholderText: root.composerParent ? qsTr("Write a reply…") : qsTr("What’s happening?")
                wrapMode: TextEdit.Wrap
                selectByMouse: true
                enabled: !presentationBridge.writeBusy
            }

            Label {
                Layout.fillWidth: true
                visible: presentationBridge.writeStatusText.length > 0
                text: presentationBridge.writeStatusText
                color: presentationBridge.writePhase === "confirmed" ? Theme.success : Theme.inkMuted
                font.pixelSize: 12
                wrapMode: Text.Wrap
            }

            Label {
                Layout.fillWidth: true
                visible: presentationBridge.writeErrorText.length > 0
                text: presentationBridge.writeErrorText
                color: Theme.warning
                font.pixelSize: 12
                lineHeight: 1.3
                wrapMode: Text.Wrap
            }

            RowLayout {
                Layout.fillWidth: true
                spacing: Theme.space2

                Item { Layout.fillWidth: true }

                ActionButton {
                    text: qsTr("Cancel")
                    quiet: true
                    enabled: !presentationBridge.writeBusy
                    onClicked: composerPopup.close()
                }

                ActionButton {
                    text: presentationBridge.writeBusy
                          ? (root.composerParent ? qsTr("Replying…") : qsTr("Publishing…"))
                          : (root.composerParent ? qsTr("Reply") : qsTr("Publish"))
                    prominent: true
                    enabled: !presentationBridge.writeBusy && composerInput.text.trim().length > 0
                    onClicked: {
                        if (root.composerParent)
                            presentationBridge.publishReply(composerInput.text)
                        else
                            presentationBridge.publishCast(composerInput.text)
                    }
                }
            }
        }
    }

    Popup {
        id: accountPopup
        parent: Overlay.overlay
        width: Math.min(480, parent.width - Theme.mobileGutter * 2)
        x: Math.round((parent.width - width) / 2)
        y: Math.max(Theme.space4, Math.round((parent.height - height) / 2))
        modal: true
        focus: true
        padding: Theme.space5
        closePolicy: Popup.CloseOnEscape | Popup.CloseOnPressOutside

        Overlay.modal: Rectangle { color: Theme.overlay }

        background: Rectangle {
            radius: Theme.radiusXLarge
            color: Theme.surface
            border.width: 1
            border.color: Theme.border
        }

        contentItem: ColumnLayout {
            spacing: Theme.space3

            Label {
                Layout.fillWidth: true
                text: presentationBridge.isAuthenticated
                      ? qsTr("Your Farcaster account")
                      : presentationBridge.authenticationPhase === "awaiting-approval"
                        ? qsTr("Approve sign in")
                        : qsTr("Sign in to interact")
                color: Theme.ink
                font.pixelSize: 21
                font.weight: Font.Bold
                wrapMode: Text.Wrap
            }

            Label {
                Layout.fillWidth: true
                text: presentationBridge.isAuthenticated
                      ? qsTr("This verified session identifies your account. Protocol writes remain locked until Genycaster has a valid Farcaster signer for this FID.")
                      : qsTr("You can keep reading Genycaster as a guest. Sign in is required before Like, Recast, Reply, Follow, or Publish; protocol signing is a separate security step.")
                color: Theme.inkMuted
                font.pixelSize: 13
                lineHeight: 1.35
                wrapMode: Text.Wrap
            }

            Rectangle {
                visible: presentationBridge.isAuthenticated
                Layout.fillWidth: true
                implicitHeight: accountSummary.implicitHeight + Theme.space4 * 2
                radius: Theme.radiusLarge
                color: Theme.surfaceMuted

                ColumnLayout {
                    id: accountSummary
                    anchors.left: parent.left
                    anchors.right: parent.right
                    anchors.top: parent.top
                    anchors.margins: Theme.space4
                    spacing: Theme.space1

                    Label {
                        Layout.fillWidth: true
                        text: presentationBridge.accountName.length > 0
                              ? presentationBridge.accountName : qsTr("Signed-in account")
                        color: Theme.ink
                        font.pixelSize: 16
                        font.weight: Font.DemiBold
                        wrapMode: Text.Wrap
                    }

                    Label {
                        Layout.fillWidth: true
                        text: (presentationBridge.accountUsername.length > 0
                               ? "@" + presentationBridge.accountUsername + " · " : "")
                              + qsTr("FID %1").arg(presentationBridge.accountFid)
                        color: Theme.inkMuted
                        font.pixelSize: 12
                        wrapMode: Text.Wrap
                    }

                    Label {
                        Layout.fillWidth: true
                        text: presentationBridge.signerStatusText
                        color: presentationBridge.writeReady ? Theme.success : Theme.inkMuted
                        font.pixelSize: 12
                        wrapMode: Text.Wrap
                    }

                    Label {
                        visible: presentationBridge.signerErrorText.length > 0
                        Layout.fillWidth: true
                        text: presentationBridge.signerErrorText
                        color: Theme.warning
                        font.pixelSize: 11
                        lineHeight: 1.3
                        wrapMode: Text.Wrap
                    }
                }
            }

            Rectangle {
                visible: !presentationBridge.isAuthenticated
                         && !presentationBridge.authenticationAvailable
                Layout.fillWidth: true
                implicitHeight: unavailableText.implicitHeight + Theme.space4 * 2
                radius: Theme.radiusMedium
                color: Theme.warningSurface

                Label {
                    id: unavailableText
                    anchors.left: parent.left
                    anchors.right: parent.right
                    anchors.top: parent.top
                    anchors.margins: Theme.space4
                    text: qsTr("Sign in is not configured in this build. Guest reading remains fully available.")
                    color: Theme.warning
                    font.pixelSize: 12
                    lineHeight: 1.3
                    wrapMode: Text.Wrap
                }
            }

            Label {
                visible: presentationBridge.authenticationPhase === "starting"
                Layout.fillWidth: true
                text: qsTr("Creating a secure Farcaster sign-in request…")
                color: Theme.inkMuted
                font.pixelSize: 13
                wrapMode: Text.Wrap
            }

            ColumnLayout {
                visible: presentationBridge.authenticationPhase === "awaiting-approval"
                Layout.fillWidth: true
                spacing: Theme.space2

                Label {
                    Layout.fillWidth: true
                    text: qsTr("Approve the request in a Farcaster-compatible client, then return here. Genycaster verifies the signed identity proof before creating a local session.")
                    color: Theme.inkMuted
                    font.pixelSize: 13
                    lineHeight: 1.35
                    wrapMode: Text.Wrap
                }

                Label {
                    Layout.fillWidth: true
                    text: qsTr("The approval link is kept transient and opens through your system browser or Farcaster client. It is not stored in local session data.")
                    color: Theme.inkSubtle
                    font.pixelSize: 11
                    lineHeight: 1.3
                    wrapMode: Text.Wrap
                }
            }

            Label {
                visible: presentationBridge.authenticationErrorText.length > 0
                Layout.fillWidth: true
                text: presentationBridge.authenticationErrorText
                color: Theme.warning
                font.pixelSize: 12
                lineHeight: 1.3
                wrapMode: Text.Wrap
            }

            RowLayout {
                Layout.fillWidth: true
                spacing: Theme.space2

                Item { Layout.fillWidth: true }

                ActionButton {
                    visible: presentationBridge.authenticationPhase === "awaiting-approval"
                    text: qsTr("Cancel")
                    quiet: true
                    onClicked: {
                        presentationBridge.cancelSignIn()
                        accountPopup.close()
                    }
                }

                ActionButton {
                    visible: !presentationBridge.isAuthenticated
                             && presentationBridge.authenticationPhase !== "starting"
                             && presentationBridge.authenticationPhase !== "awaiting-approval"
                    text: presentationBridge.authenticationPhase === "failed" ? qsTr("Try again") : qsTr("Sign in with Farcaster")
                    prominent: true
                    enabled: presentationBridge.runtimeReady && presentationBridge.authenticationAvailable
                    onClicked: presentationBridge.beginSignIn()
                }

                ActionButton {
                    visible: presentationBridge.authenticationPhase === "awaiting-approval"
                    text: qsTr("Open Farcaster")
                    prominent: true
                    enabled: presentationBridge.authenticationApprovalAvailable
                    onClicked: presentationBridge.openAuthenticationApproval()
                }

                ActionButton {
                    visible: presentationBridge.isAuthenticated && !presentationBridge.writeReady
                    text: presentationBridge.signerBusy ? qsTr("Enabling…") : qsTr("Enable interactions")
                    prominent: true
                    enabled: !presentationBridge.signerBusy
                    onClicked: presentationBridge.provisionSigner()
                }

                ActionButton {
                    visible: presentationBridge.isAuthenticated && presentationBridge.writeReady
                    text: presentationBridge.signerBusy ? qsTr("Revoking…") : qsTr("Revoke signer")
                    enabled: !presentationBridge.signerBusy
                    onClicked: presentationBridge.revokeSigner()
                }

                ActionButton {
                    visible: presentationBridge.isAuthenticated
                    text: qsTr("Sign out")
                    onClicked: presentationBridge.signOut()
                }

                ActionButton {
                    text: qsTr("Close")
                    quiet: true
                    onClicked: accountPopup.close()
                }
            }
        }
    }

    Connections {
        target: presentationBridge

        function onIdentityOpened() {
            if (identityPopup.opened) {
                identityPopup.close()
                identityInput.clear()
            }
        }

        function onStateChanged() {
            if (composerPopup.opened && presentationBridge.writePhase === "confirmed") {
                composerPopup.close()
            }
        }
    }
}
