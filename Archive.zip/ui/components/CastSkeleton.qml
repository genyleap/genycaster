import QtQuick
import QtQuick.Layouts

Rectangle {
    implicitHeight: 152
    color: Theme.surface
    ColumnLayout {
        anchors.fill: parent; anchors.margins: Theme.space4; spacing: Theme.space3
        RowLayout { spacing: Theme.space3
            Rectangle { width: 44; height: 44; radius: 22; color: Theme.surfaceMuted }
            ColumnLayout { spacing: Theme.space2
                Rectangle { width: 132; height: 12; radius: 6; color: Theme.surfaceMuted }
                Rectangle { width: 88; height: 10; radius: 5; color: Theme.surfaceMuted }
            }
        }
        Rectangle { Layout.fillWidth: true; height: 12; radius: 6; color: Theme.surfaceMuted }
        Rectangle { Layout.preferredWidth: parent.width * 0.72; height: 12; radius: 6; color: Theme.surfaceMuted }
    }
    Rectangle { anchors.bottom: parent.bottom; width: parent.width; height: 1; color: Theme.border }
}
