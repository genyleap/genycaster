import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Item {
    id: root

    property bool runtimeReady: false
    property bool busy: false
    property bool offline: false
    property bool sourceUnavailable: false
    property string errorText: ""
    property string activeFeed: "following"
    property bool identityAvailable: false
    property bool feedStarted: false

    signal retryRequested()
    signal identityRequested()
    signal followingRequested()
    signal trendingRequested()

    readonly property bool setupFailure: !root.runtimeReady && root.errorText.length > 0
    readonly property bool idleHome: root.runtimeReady
                                     && !root.feedStarted
                                     && !root.busy
                                     && root.errorText.length === 0
    readonly property bool recoverableSourceFailure: root.runtimeReady && root.sourceUnavailable && !root.offline && !root.busy
    readonly property bool trendingUnavailable: root.recoverableSourceFailure && root.activeFeed === "trending"

    ColumnLayout {
        anchors.centerIn: parent
        width: Math.min(parent.width - Theme.space6, 460)
        spacing: Theme.space3

        BusyIndicator {
            visible: root.busy
            running: visible
            Layout.alignment: Qt.AlignHCenter
            Layout.preferredWidth: 30
            Layout.preferredHeight: 30
        }

        Label {
            Layout.fillWidth: true
            text: root.setupFailure
                  ? qsTr("Live reading is not configured")
                  : root.busy
                    ? qsTr("Loading your reading surface…")
                    : root.idleHome
                      ? qsTr("Open your Farcaster home")
                    : root.offline
                      ? qsTr("No saved posts for offline reading")
                    : root.sourceUnavailable
                      ? (root.activeFeed === "trending"
                         ? qsTr("Trending is unavailable from this source")
                         : qsTr("The live source did not return this feed"))
                      : root.errorText.length > 0
                        ? qsTr("This feed could not be loaded")
                        : qsTr("Nothing here yet")
            color: Theme.ink
            font.pixelSize: 19
            font.weight: Font.DemiBold
            horizontalAlignment: Text.AlignHCenter
            wrapMode: Text.Wrap
        }

        Label {
            Layout.fillWidth: true
            text: root.setupFailure
                  ? root.errorText
                  : root.busy
                    ? qsTr("Genycaster checks local state first, then refreshes from the selected source.")
                    : root.idleHome
                      ? (root.identityAvailable
                         ? qsTr("Open Home for this identity, or use Explore when you want network-wide discovery.")
                         : qsTr("Open an identity for your Home feed, or use Explore for network-wide discovery."))
                    : root.offline
                      ? qsTr("Reconnect and refresh once to populate the local cache.")
                    : root.trendingUnavailable
                      ? (root.identityAvailable
                         ? qsTr("Explore is temporarily unavailable. Your Home feed remains independent while discovery recovers.")
                         : qsTr("Explore is temporarily unavailable. Open an identity for Home, or retry discovery later."))
                      : root.errorText.length > 0
                        ? root.errorText
                        : root.sourceUnavailable
                          ? qsTr("Your device may still be online. Retry or use another available reading surface.")
                          : qsTr("Open an identity, choose another feed, or refresh this surface.")
            color: Theme.inkMuted
            font.pixelSize: 13
            lineHeight: 1.35
            horizontalAlignment: Text.AlignHCenter
            wrapMode: Text.Wrap
        }

        RowLayout {
            visible: root.runtimeReady && !root.busy
                     && (root.idleHome || root.sourceUnavailable || root.offline || root.errorText.length > 0)
            Layout.alignment: Qt.AlignHCenter
            spacing: Theme.space2

            ActionButton {
                visible: root.idleHome || root.trendingUnavailable
                text: root.identityAvailable ? qsTr("Open Home") : qsTr("Open identity")
                prominent: true
                onClicked: {
                    if (root.identityAvailable) {
                        root.followingRequested()
                    } else {
                        root.identityRequested()
                    }
                }
            }

            ActionButton {
                visible: root.idleHome
                text: qsTr("Browse Explore")
                quiet: true
                onClicked: root.trendingRequested()
            }

            ActionButton {
                visible: !root.idleHome
                text: root.offline ? qsTr("Try again") : qsTr("Retry")
                quiet: root.trendingUnavailable
                onClicked: root.retryRequested()
            }
        }
    }
}
