import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Rectangle {
    id: root

    property var modelData

    implicitHeight: 72
    color: Theme.surface

    RowLayout {
        anchors.fill: parent
        anchors.leftMargin: Theme.space4
        anchors.rightMargin: Theme.space4
        spacing: Theme.space3

        Avatar {
            avatarSize: 42
            sourceUrl: root.modelData.avatarUrl || ""
            displayName: root.modelData.displayName || root.modelData.author || ""
        }

        ColumnLayout {
            Layout.fillWidth: true
            spacing: 1

            Label {
                Layout.fillWidth: true
                text: root.modelData.displayName || root.modelData.author || qsTr("Unknown")
                color: Theme.ink
                font.pixelSize: 14
                font.weight: Font.DemiBold
                elide: Text.ElideRight
            }

            Label {
                Layout.fillWidth: true
                text: root.modelData.author ? "@" + root.modelData.author : ""
                color: Theme.inkMuted
                font.pixelSize: 12
                elide: Text.ElideRight
            }
        }
    }

    Rectangle {
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        height: 1
        color: Theme.border
    }
}
