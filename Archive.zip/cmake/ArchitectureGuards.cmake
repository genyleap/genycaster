function(farcaster_register_architecture_guard)
    if(NOT BUILD_TESTING)
        return()
    endif()

    find_package(Python3 COMPONENTS Interpreter REQUIRED)

    add_test(
        NAME architecture_guard
        COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/check_architecture.py" "${CMAKE_CURRENT_SOURCE_DIR}"
    )
    set_tests_properties(architecture_guard PROPERTIES LABELS "architecture")
endfunction()
