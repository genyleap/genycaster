# Codex Continuation Prompt — Phase 5F Write Hardening

Read `AGENTS.md`, `docs/23-phase5-write-feature-gate.md`,
`docs/37-phase5e-social-writes-app-fid.md`, `PHASE_5E_REVIEW.md`, and
`PHASE_5E_VERIFICATION.md` before editing.

Phase 5E is implementation-final in source. The next task is **Phase 5F — Write hardening**.
Do not add a second mutation architecture. Harden the existing session → verified scoped signer →
canonical protobuf → exact signed envelope → SQLite outbox → reconcile/submit/reconcile pipeline.

Required work:

1. Run the full macOS Clang + Qt 6.11.x clean build and all CTest/qmllint/smoke gates.
2. Exercise a deployed App-FID attestation endpoint and prove the user wallet signs only the final
   gasless `KEY_ADD`; the App-FID custody private key must remain server-side.
3. Live-test Cast, Reply, Delete, Like, Unlike, Recast, Undo Recast, Follow and Unfollow.
4. Prove restart durability and duplicate suppression with exact-envelope retry.
5. Prove offline → online recovery with bounded retry/backoff.
6. Prove signer replacement, expiry and revocation fail closed without disabling guest/public reads.
7. Verify sliding TTL behavior from authoritative Snapchain state and local `lastUsedAt` refresh.
8. Test ambiguous submit outcomes: timeout after merge, duplicate/conflict, delayed indexing and
   authoritative absence for remove operations.
9. Preserve provider-neutral Application/Domain boundaries; Hypersnap remains a read-provider policy,
   not the owner of writes.
10. Keep QML presentation-only: no protobuf construction, signing, storage or provider calls in QML.

Do not claim Phase 5F complete without exact platform build/test/runtime evidence.
