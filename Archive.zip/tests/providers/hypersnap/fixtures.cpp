module;

#include <cassert>
#include <chrono>
#include <filesystem>
#include <string>
#include <string_view>
#include <system_error>

module farcaster.test.hypersnap.fixtures;

namespace farcaster::test::hypersnap::fixtures {
namespace {

const std::string kUserResponse = R"json({
  "user": {
    "object": "user",
    "fid": 42,
    "username": "alice",
    "display_name": "Alice",
    "custody_address": "0x1234",
    "pfp_url": "https://cdn.test/alice.png",
    "registered_at": "2026-08-27T00:00:00.000Z",
    "profile": {"bio": {"text": "hello from hypersnap"}},
    "follower_count": 12,
    "following_count": 8,
    "verifications": [],
    "auth_addresses": [],
    "verified_addresses": {"eth_addresses": [], "sol_addresses": [], "primary": {}},
    "verified_accounts": []
  }
})json";

const std::string kCastObject = R"json({
  "object": "cast",
  "hash": "0xabc123",
  "parent_hash": "0xparent",
  "parent_author": {"fid": 7},
  "author": {
    "fid": 42,
    "username": "alice",
    "display_name": "Alice",
    "custody_address": "0x1234",
    "pfp_url": "https://cdn.test/alice.png",
    "registered_at": "2026-08-27T00:00:00.000Z",
    "profile": {"bio": {"text": "hello from hypersnap"}},
    "follower_count": 12,
    "following_count": 8,
    "verifications": [],
    "auth_addresses": [],
    "verified_addresses": {"eth_addresses": [], "sol_addresses": [], "primary": {}},
    "verified_accounts": []
  },
  "text": "hello native",
  "timestamp": "2026-08-27T12:34:56.789Z",
  "embeds": [
    {"url": "https://example.test/post"},
    {"cast_id": {"fid": 7, "hash": "0xquoted"}}
  ],
  "type": "cast-reply",
  "reactions": {"likes_count": 2, "recasts_count": 1, "likes": [], "recasts": []},
  "replies": {"count": 3},
  "mentioned_profiles": [],
  "mentioned_profiles_ranges": [],
  "mentioned_channels": [],
  "mentioned_channels_ranges": []
})json";

}

TemporaryDatabase::TemporaryDatabase()
{
    const auto unique = std::chrono::steady_clock::now().time_since_epoch().count();
    m_path = (std::filesystem::temp_directory_path()
        / ("farcaster-hypersnap-contract-" + std::to_string(unique) + ".sqlite3"))
                 .string();
}

TemporaryDatabase::~TemporaryDatabase()
{
    std::error_code error{};
    std::filesystem::remove(m_path, error);
    std::filesystem::remove(m_path + "-wal", error);
    std::filesystem::remove(m_path + "-shm", error);
}

const std::string& TemporaryDatabase::path() const noexcept
{
    return m_path;
}

const std::string& userResponse()
{
    return kUserResponse;
}

std::string castResponse()
{
    return std::string{"{\"cast\":"} + kCastObject + "}";
}

std::string feedResponse(const std::string_view cursor)
{
    std::string result{"{\"casts\":["};
    result += kCastObject;
    result += "],\"next\":{\"cursor\":";
    if (cursor.empty()) {
        result += "null";
    } else {
        result += "\"";
        result += cursor;
        result += "\"";
    }
    result += "}}";
    return result;
}

std::string channelFeedResponse()
{
    std::string castJson{kCastObject};
    const std::string parentHash{R"json("parent_hash": "0xparent",)json"};
    const std::string parentUrl{R"json("parent_url": "https://farcaster.group/dev/chat",)json"};
    const auto position = castJson.find(parentHash);
    assert(position != std::string::npos);
    castJson.replace(position, parentHash.size(), parentUrl);
    return "{\"casts\":[" + castJson + "],\"next\":{\"cursor\":null}}";
}

std::string socialResponse(const std::uint64_t fid, const std::string_view username)
{
    return "{\"users\":[{\"fid\":" + std::to_string(fid) +
        ",\"username\":\"" + std::string{username} +
        "\",\"profile\":{\"bio\":{\"text\":\"\"}}}],\"next\":{\"cursor\":null}}";
}

}
