#include <algorithm>
#include <cassert>
#include <chrono>
#include <optional>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

import farcaster.capability.catalog;
import farcaster.capability.model;
import farcaster.capability.pagination;
import farcaster.domain.cast;
import farcaster.domain.channel;
import farcaster.domain.identity;
import farcaster.domain.social;
import farcaster.foundation.error;
import farcaster.foundation.result;
import farcaster.provider.hypersnap.cast;
import farcaster.provider.hypersnap.codec;
import farcaster.provider.hypersnap.config;
import farcaster.provider.hypersnap.feed;
import farcaster.provider.hypersnap.identity;
import farcaster.provider.hypersnap.profile;
import farcaster.provider.hypersnap.registration;
import farcaster.provider.hypersnap.social;
import farcaster.provider.model;
import farcaster.storage.continuation;
import farcaster.transport.http;
import farcaster.transport.curl;
import farcaster.test.hypersnap.transport;
import farcaster.test.hypersnap.fixtures;

namespace {

using namespace farcaster;

[[nodiscard]] provider::hypersnap::config::Config testConfig()
{
    return provider::hypersnap::config::Config{
        .baseUrl = "https://node.test///",
        .provider = provider::model::ProviderDescriptor{
            .id = provider::model::ProviderId{"hypersnap-test"},
            .displayName = "Hypersnap Contract Node",
            .deployment = provider::model::ProviderDeployment::SelfHosted,
            .privacy = provider::model::ProviderPrivacy::Private,
            .priority = 10,
        },
    };
}

void testCanonicalCodec()
{
    auto user = provider::hypersnap::codec::decodeUser(test::hypersnap::fixtures::userResponse());
    assert(user);
    assert(user->fid.value == 42);
    assert(user->username && user->username->value == "alice");
    assert(user->displayName && user->displayName->value == "Alice");
    assert(user->bio == "hello from hypersnap");
    assert(user->avatarUrl && *user->avatarUrl == "https://cdn.test/alice.png");

    auto cast = provider::hypersnap::codec::decodeCast(test::hypersnap::fixtures::castResponse());
    assert(cast);
    assert(cast->id.value == "0xabc123");
    assert(cast->author.value == 42);
    assert(cast->parent && cast->parent->value == "0xparent");
    assert(cast->embeds.size() == 2);
    assert(cast->embeds[0].kind == domain::cast::EmbedKind::Url);
    assert(cast->embeds[0].value == "https://example.test/post");
    assert(cast->embeds[1].kind == domain::cast::EmbedKind::CastReference);
    assert(cast->embeds[1].value == "0xquoted");
    assert(cast->embeds[1].referencedAuthor);
    assert(cast->embeds[1].referencedAuthor->value == 7);
    assert(cast->engagement.likes == 2);
    assert(cast->engagement.recasts == 1);
    assert(cast->engagement.replies == 3);

    const auto expectedTime = std::chrono::sys_days{std::chrono::year{2026}/8/27} +
        std::chrono::hours{12} + std::chrono::minutes{34} +
        std::chrono::seconds{56} + std::chrono::milliseconds{789};
    assert(cast->createdAt.time_since_epoch() ==
        std::chrono::duration_cast<std::chrono::milliseconds>(expectedTime.time_since_epoch()));

    auto malformed = provider::hypersnap::codec::decodeFeed("{not-json");
    assert(!malformed);
    assert(malformed.error().code == foundation::error::ErrorCode::ProtocolFailure);
}

void testProfileCastAndIdentityEndpoints()
{
    test::hypersnap::transport::FakeTransport transport{};
    const auto config = testConfig();

    transport.enqueue(200, test::hypersnap::fixtures::userResponse());
    provider::hypersnap::profile::ProfileSource profiles{transport, config};
    auto profile = profiles.get(domain::identity::Fid{42});
    assert(profile && profile->fid.value == 42);
    assert(transport.urls().back() == "https://node.test/v2/farcaster/user?fid=42");

    transport.enqueue(200, test::hypersnap::fixtures::userResponse());
    provider::hypersnap::identity::IdentityResolver identities{transport, config};
    auto fid = identities.resolveUsername("alice bob");
    assert(fid && fid->value == 42);
    assert(transport.urls().back() ==
        "https://node.test/v2/farcaster/user/by-username?username=alice%20bob");

    transport.enqueue(200, test::hypersnap::fixtures::castResponse());
    provider::hypersnap::cast::CastSource casts{transport, config};
    auto cast = casts.get(domain::cast::CastId{"0xabc/def?"});
    assert(cast && cast->id.value == "0xabc123");
    assert(transport.urls().back() ==
        "https://node.test/v2/farcaster/cast?identifier=0xabc%2Fdef%3F&type=hash");

    auto emptyCast = casts.get(domain::cast::CastId{});
    assert(!emptyCast);
    assert(emptyCast.error().code == foundation::error::ErrorCode::InvalidArgument);

    auto emptyUsername = identities.resolveUsername("");
    assert(!emptyUsername);
    assert(emptyUsername.error().code == foundation::error::ErrorCode::InvalidArgument);
}

void testHttpErrorMappingAndConfigValidation()
{
    test::hypersnap::transport::FakeTransport transport{};
    auto config = testConfig();
    provider::hypersnap::profile::ProfileSource profiles{transport, config};

    transport.enqueue(429, "{}");
    auto rateLimited = profiles.get(domain::identity::Fid{42});
    assert(!rateLimited);
    assert(rateLimited.error().code == foundation::error::ErrorCode::RateLimited);
    assert(rateLimited.error().message.find("Endpoint: /v2/farcaster/user") != std::string::npos);
    assert(rateLimited.error().message.find("Limit: n/a") != std::string::npos);
    assert(rateLimited.error().message.find("Deadline: 15000ms") != std::string::npos);

    transport.enqueue(503, R"({"error":"Feed service not available"})");
    auto unavailable = profiles.get(domain::identity::Fid{42});
    assert(!unavailable);
    assert(unavailable.error().code == foundation::error::ErrorCode::Unavailable);
    assert(unavailable.error().message.find("Endpoint: /v2/farcaster/user") != std::string::npos);
    assert(unavailable.error().message.find("status 503") != std::string::npos);
    assert(unavailable.error().message.find("Feed service not available") != std::string::npos);

    config.baseUrl.clear();
    provider::hypersnap::profile::ProfileSource invalid{transport, config};
    auto invalidResult = invalid.get(domain::identity::Fid{42});
    assert(!invalidResult);
    assert(invalidResult.error().code == foundation::error::ErrorCode::InvalidArgument);
}

void testFeedPaginationAffinity()
{
    test::hypersnap::fixtures::TemporaryDatabase database{};
    auto storeResult = storage::continuation::openContinuationStore(database.path());
    assert(storeResult);
    auto store = std::move(*storeResult);

    test::hypersnap::transport::FakeTransport transport{};
    transport.enqueue(200, test::hypersnap::fixtures::feedResponse("raw-feed-cursor+/="));
    provider::hypersnap::feed::FeedSource feeds{transport, store, testConfig()};

    auto first = feeds.following(
        domain::identity::Fid{42},
        capability::pagination::PageRequest{.limit = 2});
    assert(first);
    assert(first->casts.size() == 1);
    assert(first->profiles.size() == 1);
    assert(first->entries.size() == 1);
    assert(first->next);
    assert(first->next->value.find("raw-feed-cursor") == std::string::npos);
    assert(transport.urls().back() ==
        "https://node.test/v2/farcaster/feed/following?fid=42&limit=2");

    assert(transport.requests().back().timeout == std::chrono::milliseconds{12'000});

    auto binding = store.resolve(*first->next);
    assert(binding);
    assert(binding->providerCursor == "raw-feed-cursor+/=");
    assert(binding->providerId.value == "hypersnap-test");
    assert(binding->capabilityId.value == capability::catalog::feedFollowingRead().value);

    transport.enqueue(200, test::hypersnap::fixtures::feedResponse(""));
    auto second = feeds.following(
        domain::identity::Fid{42},
        capability::pagination::PageRequest{
            .limit = 2,
            .continuation = first->next,
        });
    assert(second);
    assert(!second->next);
    assert(transport.urls().back() ==
        "https://node.test/v2/farcaster/feed/following?fid=42&limit=2&cursor=raw-feed-cursor%2B%2F%3D");

    const auto requestCount = transport.urls().size();
    auto wrongCapability = feeds.trending(capability::pagination::PageRequest{
        .limit = 2,
        .continuation = first->next,
    });
    assert(!wrongCapability);
    assert(wrongCapability.error().code == foundation::error::ErrorCode::Conflict);
    assert(transport.urls().size() == requestCount);

    auto invalidLimit = feeds.trending(capability::pagination::PageRequest{.limit = 101});
    assert(!invalidLimit);
    assert(invalidLimit.error().code == foundation::error::ErrorCode::InvalidArgument);

    transport.enqueue(503, R"({"error":"Trending timeout substitute"})");
    auto trendingUnavailable = feeds.trending(
        capability::pagination::PageRequest{.limit = 10});
    assert(!trendingUnavailable);
    assert(trendingUnavailable.error().code == foundation::error::ErrorCode::Unavailable);
    assert(trendingUnavailable.error().message.find(
        "Endpoint: /v2/farcaster/feed/trending") != std::string::npos);
    assert(trendingUnavailable.error().message.find("Limit: 10") != std::string::npos);
    assert(trendingUnavailable.error().message.find("Deadline: 12000ms") != std::string::npos);

    transport.enqueue(200, test::hypersnap::fixtures::channelFeedResponse());
    auto channel = feeds.channel(
        domain::channel::ChannelId{"dev/chat"},
        capability::pagination::PageRequest{.limit = 5});
    assert(channel);
    assert(channel->casts.size() == 1);
    assert(channel->casts.front().parentUrl ==
        std::optional<std::string>{"https://farcaster.group/dev/chat"});
    assert(transport.urls().back() ==
        "https://node.test/v2/farcaster/feed/channels?channel_ids=dev%2Fchat&limit=5");
}

void testSocialGraphSemantics()
{
    test::hypersnap::fixtures::TemporaryDatabase database{};
    auto storeResult = storage::continuation::openContinuationStore(database.path());
    assert(storeResult);
    auto store = std::move(*storeResult);

    test::hypersnap::transport::FakeTransport transport{};
    provider::hypersnap::social::SocialGraphSource graph{transport, store, testConfig()};

    transport.enqueue(200, test::hypersnap::fixtures::socialResponse(7, "bob"));
    auto followers = graph.followers(
        domain::identity::Fid{42},
        capability::pagination::PageRequest{.limit = 10});
    assert(followers && followers->relations.size() == 1);
    assert(followers->relations.front().source.value == 7);
    assert(followers->relations.front().target.value == 42);
    assert(followers->relations.front().kind == domain::social::SocialRelationKind::Follows);
    assert(transport.urls().back() ==
        "https://node.test/v2/farcaster/user/followers?fid=42&limit=10");

    transport.enqueue(200, test::hypersnap::fixtures::socialResponse(9, "carol"));
    auto following = graph.following(
        domain::identity::Fid{42},
        capability::pagination::PageRequest{.limit = 10});
    assert(following && following->relations.size() == 1);
    assert(following->relations.front().source.value == 42);
    assert(following->relations.front().target.value == 9);
}

void testCurlTransportConstruction()
{
    auto transport = farcaster::transport::curl::makeTransport();
    assert(transport);
    assert(*transport != nullptr);
}

void testCapabilityRegistration()
{
    const auto capabilities = provider::hypersnap::registration::capabilities();
    assert(capabilities.size() == 8);

    const auto has = [&](const capability::model::CapabilityId& id) {
        return std::ranges::any_of(capabilities, [&](const auto& item) {
            return item.id.value == id.value;
        });
    };

    assert(has(capability::catalog::identityFidResolve()));
    assert(has(capability::catalog::profileRead()));
    assert(has(capability::catalog::castRead()));
    assert(has(capability::catalog::graphFollowersRead()));
    assert(has(capability::catalog::graphFollowingRead()));
    assert(has(capability::catalog::feedFollowingRead()));
    assert(has(capability::catalog::feedTrendingRead()));
    assert(has(capability::catalog::feedChannelRead()));
    assert(!has(capability::catalog::feedForYouRead()));

    for (const auto& item : capabilities) {
        assert(item.isSelfHostable);
        assert(item.quality == capability::model::CapabilityQuality::Native);
    }
}

}

int main()
{
    testCanonicalCodec();
    testProfileCastAndIdentityEndpoints();
    testHttpErrorMappingAndConfigValidation();
    testFeedPaginationAffinity();
    testSocialGraphSemantics();
    testCapabilityRegistration();
    testCurlTransportConstruction();
    return 0;
}
