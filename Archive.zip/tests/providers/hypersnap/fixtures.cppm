module;

#include <cstdint>
#include <string>
#include <string_view>

export module farcaster.test.hypersnap.fixtures;

export namespace farcaster::test::hypersnap::fixtures {

/** @brief Owns a unique temporary SQLite database path for provider contract tests. */
class TemporaryDatabase final {
public:
    /** @brief Creates a unique path in the system temporary directory. */
    TemporaryDatabase();

    /** @brief Removes the database and SQLite sidecar files. */
    ~TemporaryDatabase();

    TemporaryDatabase(const TemporaryDatabase&) = delete;
    auto operator=(const TemporaryDatabase&) -> TemporaryDatabase& = delete;
    TemporaryDatabase(TemporaryDatabase&&) = delete;
    auto operator=(TemporaryDatabase&&) -> TemporaryDatabase& = delete;

    /** @brief Returns the database path text. */
    [[nodiscard]] const std::string& path() const noexcept;

private:
    std::string m_path{};
};

/** @brief Returns a representative Hypersnap v2 user response fixture. */
[[nodiscard]] const std::string& userResponse();

/** @brief Returns a representative Hypersnap v2 cast response fixture. */
[[nodiscard]] std::string castResponse();

/** @brief Returns a representative Hypersnap v2 feed response fixture. */
[[nodiscard]] std::string feedResponse(std::string_view cursor);

/** @brief Returns a representative Hypersnap v2 channel feed response fixture. */
[[nodiscard]] std::string channelFeedResponse();

/** @brief Returns a representative Hypersnap v2 social graph response fixture. */
[[nodiscard]] std::string socialResponse(std::uint64_t fid, std::string_view username);

}
