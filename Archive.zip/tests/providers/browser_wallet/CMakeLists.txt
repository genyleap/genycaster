find_package(Boost 1.75 REQUIRED)

add_executable(farcaster_provider_browser_wallet_contract_tests contract_tests.cpp)

target_link_libraries(farcaster_provider_browser_wallet_contract_tests
    PRIVATE
        farcaster::provider_compatibility_browser_wallet
        farcaster::capabilities
        farcaster::domain
        farcaster::foundation
        farcaster::protocol
        Boost::headers
)

target_compile_features(farcaster_provider_browser_wallet_contract_tests PRIVATE cxx_std_26)
farcaster_enable_warnings(farcaster_provider_browser_wallet_contract_tests)

add_test(NAME provider.browser_wallet.contract COMMAND farcaster_provider_browser_wallet_contract_tests)
set_tests_properties(provider.browser_wallet.contract PROPERTIES LABELS "provider;contract;signer;wallet")
