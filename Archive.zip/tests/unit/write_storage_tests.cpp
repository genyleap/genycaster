#include <cassert>
#include <chrono>
#include <cstdint>
#include <filesystem>
#include <optional>
#include <string>
#include <system_error>

import farcaster.domain.cast;
import farcaster.domain.identity;
import farcaster.domain.signer;
import farcaster.domain.write;
import farcaster.foundation.error;
import farcaster.foundation.time;
import farcaster.storage.write;

namespace {

namespace domain = farcaster::domain;
namespace foundation = farcaster::foundation;
namespace storage = farcaster::storage;

struct DatabaseFixture final {
    DatabaseFixture()
    {
        const auto unique = std::chrono::steady_clock::now().time_since_epoch().count();
        path = std::filesystem::temp_directory_path() /
            ("genycaster-write-outbox-" + std::to_string(unique) + ".sqlite3");
    }

    ~DatabaseFixture()
    {
        std::error_code error{};
        std::filesystem::remove(path, error);
        std::filesystem::remove(path.string() + "-wal", error);
        std::filesystem::remove(path.string() + "-shm", error);
    }

    std::filesystem::path path{};
};

[[nodiscard]] foundation::time::Timestamp timestamp(const std::int64_t milliseconds)
{
    return foundation::time::Timestamp{std::chrono::milliseconds{milliseconds}};
}

[[nodiscard]] domain::write::SignedOperation operation()
{
    constexpr auto castId = "0x00112233445566778899aabbccddeeff00112233";
    return domain::write::SignedOperation{
        .kind = domain::write::OperationKind::PublishCast,
        .idempotencyKey = domain::write::IdempotencyKey{castId},
        .author = domain::identity::Fid{42U},
        .optimisticCast = domain::cast::Cast{
            .id = domain::cast::CastId{castId},
            .author = domain::identity::Fid{42U},
            .text = "durable hello",
            .embeds = {
                domain::cast::Embed{
                    .kind = domain::cast::EmbedKind::Url,
                    .value = "https://example.com",
                },
                domain::cast::Embed{
                    .kind = domain::cast::EmbedKind::CastReference,
                    .value = "0x102132435465768798a9bacbdcedfe0f10213243",
                    .referencedAuthor = domain::identity::Fid{7U},
                },
            },
            .createdAt = timestamp(1'700'000'000'000LL),
        },
        .signerPublicKey = domain::signer::PublicKey{
            "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f"},
        .messageBytes = std::string{"\x00\x01signed\x00protobuf", 17U},
        .signedAt = timestamp(1'700'000'000'100LL),
    };
}

void durableRoundTripAndDuplicateIdempotency()
{
    DatabaseFixture database{};
    const auto original = operation();
    {
        auto store = storage::write::openOutboxStore(database.path);
        assert(store);
        auto queued = (*store)->enqueue(original, timestamp(1'700'000'000'200LL));
        assert(queued);
        assert(queued->status == domain::write::OutboxStatus::Pending);
        assert(queued->attemptCount == 0U);
        assert(queued->operation.messageBytes == original.messageBytes);
        assert(queued->operation.optimisticCast->embeds.size() == 2U);

        auto attempted = (*store)->beginAttempt(
            original.idempotencyKey,
            timestamp(1'700'000'000'300LL));
        assert(attempted && attempted->attemptCount == 1U);

        auto duplicate = (*store)->enqueue(original, timestamp(1'700'000'000'400LL));
        assert(duplicate);
        assert(duplicate->attemptCount == 1U);
        assert(duplicate->enqueuedAt == timestamp(1'700'000'000'200LL));
    }

    auto reopened = storage::write::openOutboxStore(database.path);
    assert(reopened);
    auto record = (*reopened)->find(original.idempotencyKey);
    assert(record && *record);
    assert((*record)->operation.optimisticCast->id.value == original.optimisticCast->id.value);
    assert((*record)->operation.optimisticCast->text == original.optimisticCast->text);
    assert((*record)->operation.optimisticCast->embeds.size() == 2U);
    assert((*record)->operation.messageBytes == original.messageBytes);
    assert((*record)->attemptCount == 1U);
}


void socialTargetsSurviveStoreReopen()
{
    DatabaseFixture database{};
    auto store = storage::write::openOutboxStore(database.path);
    assert(store);

    const domain::write::SignedOperation like{
        .kind = domain::write::OperationKind::Like,
        .idempotencyKey = domain::write::IdempotencyKey{
            "0x1111222233334444555566667777888899990000"},
        .author = domain::identity::Fid{42U},
        .target = domain::write::OperationTarget{
            .cast = domain::cast::CastReference{
                .author = domain::identity::Fid{7U},
                .id = domain::cast::CastId{
                    "0x000102030405060708090a0b0c0d0e0f10111213"},
            },
        },
        .signerPublicKey = domain::signer::PublicKey{
            "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f"},
        .messageBytes = "signed-like-envelope",
        .signedAt = timestamp(1'700'000'000'100LL),
    };
    const domain::write::SignedOperation follow{
        .kind = domain::write::OperationKind::Follow,
        .idempotencyKey = domain::write::IdempotencyKey{
            "0xaaaabbbbccccddddeeeeffff0000111122223333"},
        .author = domain::identity::Fid{42U},
        .target = domain::write::OperationTarget{
            .fid = domain::identity::Fid{99U},
        },
        .signerPublicKey = like.signerPublicKey,
        .messageBytes = "signed-follow-envelope",
        .signedAt = timestamp(1'700'000'000'200LL),
    };

    assert((*store)->enqueue(like, timestamp(1'000)));
    assert((*store)->enqueue(follow, timestamp(1'001)));
    (*store).reset();

    auto reopened = storage::write::openOutboxStore(database.path);
    assert(reopened);
    auto storedLike = (*reopened)->find(like.idempotencyKey);
    assert(storedLike && *storedLike);
    assert((*storedLike)->operation.kind == domain::write::OperationKind::Like);
    assert((*storedLike)->operation.author.value == 42U);
    assert((*storedLike)->operation.target.cast);
    assert((*storedLike)->operation.target.cast->author.value == 7U);
    assert((*storedLike)->operation.target.cast->id.value ==
        "0x000102030405060708090a0b0c0d0e0f10111213");
    assert(!(*storedLike)->operation.optimisticCast);

    auto storedFollow = (*reopened)->find(follow.idempotencyKey);
    assert(storedFollow && *storedFollow);
    assert((*storedFollow)->operation.kind == domain::write::OperationKind::Follow);
    assert((*storedFollow)->operation.target.fid);
    assert((*storedFollow)->operation.target.fid->value == 99U);
    assert(!(*storedFollow)->operation.optimisticCast);
}

void replyParentSurvivesStoreReopen()
{
    DatabaseFixture database{};
    auto reply = operation();
    reply.idempotencyKey.value = "0xabcdefabcdefabcdefabcdefabcdefabcdefabcd";
    reply.optimisticCast->id.value = reply.idempotencyKey.value;
    reply.optimisticCast->text = "durable reply";
    reply.optimisticCast->parent = domain::cast::CastId{
        "0x000102030405060708090a0b0c0d0e0f10111213"};

    {
        auto store = storage::write::openOutboxStore(database.path);
        assert(store);
        assert((*store)->enqueue(reply, timestamp(1'000)));
    }

    auto reopened = storage::write::openOutboxStore(database.path);
    assert(reopened);
    auto record = (*reopened)->find(reply.idempotencyKey);
    assert(record && *record);
    assert((*record)->operation.optimisticCast->parent);
    assert((*record)->operation.optimisticCast->parent->value ==
        "0x000102030405060708090a0b0c0d0e0f10111213");
}

void retrySchedulingIsDurableAndDueOrdered()
{
    DatabaseFixture database{};
    auto store = storage::write::openOutboxStore(database.path);
    assert(store);
    const auto original = operation();
    assert((*store)->enqueue(original, timestamp(1'000)));
    assert((*store)->beginAttempt(original.idempotencyKey, timestamp(1'100)));
    assert((*store)->markRetry(
        original.idempotencyKey,
        domain::write::OutboxFailure{
            .kind = domain::write::FailureKind::Unavailable,
            .message = "Protocol write endpoint is temporarily unavailable.",
        },
        timestamp(2'000)));

    auto tooEarly = (*store)->listReady(domain::identity::Fid{42U}, timestamp(1'999), 8U);
    assert(tooEarly && tooEarly->empty());
    auto due = (*store)->listReady(domain::identity::Fid{42U}, timestamp(2'000), 8U);
    assert(due && due->size() == 1U);
    assert(due->front().attemptCount == 1U);
    assert(due->front().lastFailure);
    assert(due->front().lastFailure->kind == domain::write::FailureKind::Unavailable);
}


void readyListIsAccountScoped()
{
    DatabaseFixture database{};
    auto store = storage::write::openOutboxStore(database.path);
    assert(store);

    const auto first = operation();
    auto second = operation();
    constexpr auto secondCastId = "0xffeeddccbbaa99887766554433221100ffeeddcc";
    second.idempotencyKey.value = secondCastId;
    second.optimisticCast->id.value = secondCastId;
    second.author = domain::identity::Fid{99U};
    second.optimisticCast->author = domain::identity::Fid{99U};

    assert((*store)->enqueue(first, timestamp(1'000)));
    assert((*store)->enqueue(second, timestamp(1'001)));

    auto firstReady = (*store)->listReady(domain::identity::Fid{42U}, timestamp(2'000), 8U);
    assert(firstReady && firstReady->size() == 1U);
    assert(firstReady->front().operation.optimisticCast->author.value == 42U);
    assert(firstReady->front().operation.idempotencyKey.value == first.idempotencyKey.value);

    auto secondReady = (*store)->listReady(domain::identity::Fid{99U}, timestamp(2'000), 8U);
    assert(secondReady && secondReady->size() == 1U);
    assert(secondReady->front().operation.optimisticCast->author.value == 99U);
    assert(secondReady->front().operation.idempotencyKey.value == second.idempotencyKey.value);

    auto invalid = (*store)->listReady(domain::identity::Fid{}, timestamp(2'000), 8U);
    assert(!invalid);
    assert(invalid.error().code == foundation::error::ErrorCode::InvalidArgument);
}

void terminalFailureRetainsOptimisticProjection()
{
    DatabaseFixture database{};
    const auto original = operation();
    {
        auto store = storage::write::openOutboxStore(database.path);
        assert(store);
        assert((*store)->enqueue(original, timestamp(1'000)));
        assert((*store)->markFailed(
            original.idempotencyKey,
            domain::write::OutboxFailure{
                .kind = domain::write::FailureKind::ProtocolRejected,
                .message = "Canonical protocol write was rejected or malformed.",
            },
            timestamp(1'100)));
    }

    auto reopened = storage::write::openOutboxStore(database.path);
    assert(reopened);
    auto record = (*reopened)->find(original.idempotencyKey);
    assert(record && *record);
    assert((*record)->status == domain::write::OutboxStatus::Failed);
    assert((*record)->operation.optimisticCast->text == "durable hello");
    assert((*record)->lastFailure);
    assert((*record)->lastFailure->kind == domain::write::FailureKind::ProtocolRejected);
}

void confirmationClearsFailureAndPersists()
{
    DatabaseFixture database{};
    const auto original = operation();
    auto store = storage::write::openOutboxStore(database.path);
    assert(store);
    assert((*store)->enqueue(original, timestamp(1'000)));
    assert((*store)->beginAttempt(original.idempotencyKey, timestamp(1'050)));
    assert((*store)->markRetry(
        original.idempotencyKey,
        domain::write::OutboxFailure{
            .kind = domain::write::FailureKind::Unavailable,
            .message = "Protocol write endpoint is temporarily unavailable.",
        },
        timestamp(1'100)));
    assert((*store)->markConfirmed(original.idempotencyKey, timestamp(1'200)));
    auto confirmed = (*store)->find(original.idempotencyKey);
    assert(confirmed && *confirmed);
    assert((*confirmed)->status == domain::write::OutboxStatus::Confirmed);
    assert(!(*confirmed)->lastFailure);
    assert((*confirmed)->confirmedAt == timestamp(1'200));
}

void invalidIdentityNeverEnqueues()
{
    DatabaseFixture database{};
    auto store = storage::write::openOutboxStore(database.path);
    assert(store);
    auto invalid = operation();
    invalid.idempotencyKey.value = "0xdeadbeef";
    auto result = (*store)->enqueue(invalid, timestamp(1'000));
    assert(!result);
    assert(result.error().code == foundation::error::ErrorCode::InvalidArgument);
    auto absent = (*store)->find(invalid.idempotencyKey);
    assert(absent && !*absent);
}

} // namespace

int main()
{
    durableRoundTripAndDuplicateIdempotency();
    socialTargetsSurviveStoreReopen();
    replyParentSurvivesStoreReopen();
    retrySchedulingIsDurableAndDueOrdered();
    readyListIsAccountScoped();
    terminalFailureRetainsOptimisticProjection();
    confirmationClearsFailureAndPersists();
    invalidIdentityNeverEnqueues();
    return 0;
}
