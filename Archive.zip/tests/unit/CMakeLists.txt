add_executable(farcaster_core_tests
    core_tests.cpp
)
target_link_libraries(farcaster_core_tests
    PRIVATE
        farcaster::application
        farcaster::routing
        farcaster::sync
)
target_compile_features(farcaster_core_tests PRIVATE cxx_std_26)
set_property(TARGET farcaster_core_tests PROPERTY CXX_SCAN_FOR_MODULES ON)
farcaster_enable_warnings(farcaster_core_tests)
add_test(NAME core.behavior COMMAND farcaster_core_tests)
set_tests_properties(core.behavior PROPERTIES
    LABELS "unit"
    ENVIRONMENT
        "FARCASTER_EXPECT_SOCIAL=${FARCASTER_ENABLE_SOCIAL};FARCASTER_EXPECT_FEED=${FARCASTER_ENABLE_FEED};FARCASTER_EXPECT_CHANNELS=${FARCASTER_ENABLE_CHANNELS};FARCASTER_EXPECT_MINIAPPS=${FARCASTER_ENABLE_MINIAPPS};FARCASTER_EXPECT_CHAT=${FARCASTER_ENABLE_CHAT};FARCASTER_EXPECT_SEARCH=${FARCASTER_ENABLE_SEARCH};FARCASTER_EXPECT_NOTIFICATIONS=${FARCASTER_ENABLE_NOTIFICATIONS};FARCASTER_EXPECT_WALLET=${FARCASTER_ENABLE_WALLET};FARCASTER_EXPECT_SELF_HOSTED_ONLY=${FARCASTER_SELF_HOSTED_ONLY};FARCASTER_EXPECT_SIWF_DOMAIN=${FARCASTER_DEFAULT_SIWF_DOMAIN};FARCASTER_EXPECT_SIWF_URI=${FARCASTER_DEFAULT_SIWF_URI};FARCASTER_EXPECT_SNAPCHAIN_BASE_URL=${FARCASTER_DEFAULT_SNAPCHAIN_BASE_URL}"
)

add_executable(farcaster_storage_tests
    storage_tests.cpp
)
target_sources(farcaster_storage_tests
    PRIVATE
        storage_behavior.cpp
        temp_database.cpp
)
target_sources(farcaster_storage_tests
    PRIVATE
        FILE_SET CXX_MODULES
        FILES
            storage_behavior.cppm
            temp_database.cppm
)
target_link_libraries(farcaster_storage_tests
    PRIVATE
        farcaster::storage
)
target_compile_features(farcaster_storage_tests PRIVATE cxx_std_26)
set_property(TARGET farcaster_storage_tests PROPERTY CXX_SCAN_FOR_MODULES ON)
farcaster_enable_warnings(farcaster_storage_tests)
add_test(NAME storage.local COMMAND farcaster_storage_tests)
set_tests_properties(storage.local PROPERTIES LABELS "integration")

add_executable(farcaster_read_pipeline_tests read_pipeline_tests.cpp)
target_link_libraries(farcaster_read_pipeline_tests
    PRIVATE
        farcaster::application
        farcaster::storage
        farcaster::execution
)
target_compile_features(farcaster_read_pipeline_tests PRIVATE cxx_std_26)
set_property(TARGET farcaster_read_pipeline_tests PROPERTY CXX_SCAN_FOR_MODULES ON)
farcaster_enable_warnings(farcaster_read_pipeline_tests)
add_test(NAME application.local_first_read COMMAND farcaster_read_pipeline_tests)
set_tests_properties(application.local_first_read PROPERTIES LABELS "unit;integration")

add_executable(farcaster_session_tests session_tests.cpp)
target_link_libraries(farcaster_session_tests
    PRIVATE
        farcaster::application
        farcaster::storage
)
target_compile_features(farcaster_session_tests PRIVATE cxx_std_26)
set_property(TARGET farcaster_session_tests PROPERTY CXX_SCAN_FOR_MODULES ON)
farcaster_enable_warnings(farcaster_session_tests)
add_test(NAME application.guest_auth_session COMMAND farcaster_session_tests)
set_tests_properties(application.guest_auth_session PROPERTIES LABELS "unit;integration")

add_executable(farcaster_signer_tests signer_tests.cpp)
target_link_libraries(farcaster_signer_tests
    PRIVATE
        farcaster::application
        farcaster::storage
)
target_compile_features(farcaster_signer_tests PRIVATE cxx_std_26)
set_property(TARGET farcaster_signer_tests PROPERTY CXX_SCAN_FOR_MODULES ON)
farcaster_enable_warnings(farcaster_signer_tests)
add_test(NAME application.protocol_signer_readiness COMMAND farcaster_signer_tests)
set_tests_properties(application.protocol_signer_readiness PROPERTIES LABELS "unit;integration;security")

add_executable(farcaster_write_storage_tests write_storage_tests.cpp)
target_link_libraries(farcaster_write_storage_tests PRIVATE farcaster::storage_write)
target_compile_features(farcaster_write_storage_tests PRIVATE cxx_std_26)
set_property(TARGET farcaster_write_storage_tests PROPERTY CXX_SCAN_FOR_MODULES ON)
farcaster_enable_warnings(farcaster_write_storage_tests)
add_test(NAME storage.durable_write_outbox COMMAND farcaster_write_storage_tests)
set_tests_properties(storage.durable_write_outbox PROPERTIES LABELS "integration;write;outbox")

add_executable(farcaster_write_service_tests write_service_tests.cpp)
target_link_libraries(farcaster_write_service_tests
    PRIVATE
        farcaster::application_write
        farcaster::protocol_write
        farcaster::storage_write
)
target_compile_features(farcaster_write_service_tests PRIVATE cxx_std_26)
set_property(TARGET farcaster_write_service_tests PROPERTY CXX_SCAN_FOR_MODULES ON)
farcaster_enable_warnings(farcaster_write_service_tests)
add_test(NAME application.publish_cast_outbox COMMAND farcaster_write_service_tests)
set_tests_properties(application.publish_cast_outbox PROPERTIES LABELS "unit;integration;write;outbox;security")
