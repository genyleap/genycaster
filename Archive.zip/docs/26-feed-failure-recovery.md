# Feed Failure Recovery and Identity Continuity

Status: implemented checkpoint for the production read UI.

## Problem observed on the real UI

The default Home surface can select the network-wide Trending feed before an
identity is open. A public Hypersnap node may remain reachable at `/v1/info`
while a metrics-backed feed endpoint returns an HTTP 5xx response. Treating
that condition as a dead-end leaves the application visually functional but
without a useful path to content.

The provider adapter already maps HTTP 5xx responses to `Unavailable`; this
checkpoint keeps that semantic distinction and improves recovery around it.

## Changes

### Provider diagnostics

Non-2xx Hypersnap responses now retain a bounded, whitespace-normalized excerpt
of the provider response body in the internal error message. User-facing copy
remains provider-neutral; debug diagnostics can now reveal whether the node
reported a disabled feed service, missing metrics indexer, or another server
condition instead of exposing only the numeric HTTP status.

Provider contract coverage asserts that HTTP 503 remains `Unavailable` and the
bounded provider message reaches diagnostics.

### No dead-end Trending failure

When Trending fails without cached rows, the empty state now offers a concrete
recovery path:

- if an identity is open, continue to Following;
- otherwise, open the identity picker and switch to Following after successful
  resolution;
- Retry remains available for the original feed.

This does not silently substitute one feed for another. The user chooses the
recovery action and the active feed remains explicit.

### Identity continuity

The last successfully resolved username is stored in `QSettings`. On the next
normal launch, Genycaster restores that identity and opens Following first.
This avoids making a fragile global feed endpoint a mandatory startup
dependency after onboarding.

Test/visual fixture modes do not consume the persisted identity.

### Navigation remains interactive before identity selection

Following/Profile/navigation entries are no longer inert disabled controls.
When no identity is open, selecting an identity-scoped surface opens the
identity picker. This preserves discoverability and removes dead controls from
the production shell.

## Architectural boundaries

- QML still performs no network or storage work.
- Provider response bodies terminate in the Hypersnap adapter and debug error
  metadata; provider-specific semantics are not introduced into Domain or
  Application.
- Persisted identity preference is UI composition state, not protocol data.
- Feed switching is an explicit presentation intent and does not rewrite the
  underlying read contract.

## Verification in the container

Verified:

- architecture guard passes;
- `provider-hypersnap` configures cleanly;
- the build progresses through the changed provider dependency scan and stops
  at the existing GCC 14.2 C++ modules ICE in `farcaster.storage.read` before
  compiling the provider target;
- QML files have balanced structural delimiters and remain registered through
  the existing UI target.

Not verified in this container:

- Qt `qmllint`;
- macOS/Clang 22 `ui-debug` build;
- live provider response body from the user's Mac.

The next Mac run should expand **Details** on any remaining Source issue. The
new diagnostic should include the server's bounded response body, which is the
next authoritative clue if Trending remains unavailable.
